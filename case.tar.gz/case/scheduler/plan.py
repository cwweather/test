
import datetime
import time
import types
from threading import Lock

class PlanTimeQueue(object):
    def __init__(self):
        self._queue={}
        self._lock=Lock()

    def add(self,plan_time):
        with self._lock:
            self._queue[plan_time.id]=plan_time

    def remove(self,plan_time_id):
        with self._lock:
            if plan_time_id in self._queue:
                q=self._queue[plan_time_id]
                del self._queue[plan_time_id]
                return q
            return None

    def __iter__(self):
        for q in self._queue:
            yield self._queue[q]
        raise StopIteration

    def __len__(self):
        return len(self._queue)

    def __str__(self):
        return str(self._queue)

    def clear(self):
        with self._lock:
            self._queue={}

class PlanQueue(object):
    def __init__(self):
        self._queue={}
        self._lock=Lock()

    def add(self,plan):
        with self._lock:
            self._queue[plan.id()]=plan

    def remove(self,plan_id):
        with self._lock:
            if plan_id in self._queue:
                q=self._queue[plan_id]
                del self._queue[plan_id]
                return q
            return None

    def __iter__(self):
        for q in self._queue:
            yield self._queue[q]
        raise StopIteration

    def __len__(self):
        return len(self._queue)

    def __repr__(self):
        return self.__str__()

    def clear(self):
        with self._lock:
            self._queue={}

class PlanTime(object):
    def __init__(self,seconds,interval=False,years=None,months=None,days=None,hours=None,minutes=None,weeks=None):
        self.years=years
        self.months=months
        self.days=days
        self.hours=hours
        self.minutes=minutes
        self.seconds=seconds
        self.weeks=weeks
        self.interval=interval
        self._last_time=None
        self.id=id(self)

    def __cmp__(self, other):
        return cmp(self.years,other.years) or \
            cmp(self.months,other.months) or \
            cmp(self.days,other.days) or \
            cmp(self.hours,other.hours) or \
            cmp(self.minutes,other.minutes) or \
            cmp(self.seconds,other.seconds) or \
            cmp(self.weeks,other.weeks) or \
            cmp(self.interval,other.interval)

    def __eq__(self, other):
        return self.__cmp__(other)

    def check_time(self,time):
        return time.strftime("%Y-%m-%d %H:%M:%S")==datetime.datetime(
            year=self.years if self.years==0 or self.years else time.year,
            month=self.months  if self.months==0 or self.months else time.month,
            day=self.days if self.days==0 or self.days else time.day,
            hour=self.hours if self.hours==0 or self.hours else time.hour,
            minute=self.minutes if self.minutes==0 or self.minutes else time.minute,
            second=self.seconds if self.seconds==0 or self.seconds else time.second
        ).strftime("%Y-%m-%d %H:%M:%S") and (time.weekday()==(self.weeks-1) if self.weeks else True)

    def check_interval_time(self,sch_time):
        return time.mktime(sch_time.timetuple())-time.mktime(self._last_time.timetuple())>=(((self.weeks*7+self.days)*24+self.hours)*60+self.minutes)*60+self.seconds

    def check(self,sch_time):
        if self._last_time is None:
            self._last_time=sch_time
            return False
        if self.interval:
            result=self.check_interval_time(sch_time)
        else:
            result=self.check_time(sch_time)
        if result:
            self._last_time=sch_time
        return result

    def __str__(self):
        return "%s:years=%s,months=%s,days=%s,hours=%s,minutes=%s,seconds=%s,weeks=%s,intervalid=%s,id=%s" % (super(PlanTime,self).__str__(),self.years,self.months,self.days,self.hours,self.minutes,self.seconds,self.weeks,self.interval,self.id)

    def __repr__(self):
        return "%s:years=%s,months=%s,days=%s,hours=%s,minutes=%s,seconds=%s,weeks=%s,intervalid=%s,id=%s" % (super(PlanTime,self).__repr__(),self.years,self.months,self.days,self.hours,self.minutes,self.seconds,self.weeks,self.interval,self.id)

class Plan(object):
    def __init__(self,seconds,callback,args=(),kwargs={},interval=False,years=None,months=None,days=None,hours=None,minutes=None,weeks=None):
        if type(callback) == types.MethodType:
            self.instance=callback.im_self
            self.callback=callback.__name__
        else:
            self.callback=callback
        self.args=args
        self.kwargs=kwargs
        self.plan_time=PlanTime(seconds,interval,years,months,days,hours,minutes,weeks)

    def id(self):
        return self.plan_time.id

    def run(self,time):
        if callable(self.callback):
            return self.callback(time,*self.args,**self.kwargs)
        else:
            return getattr(self.instance,self.callback)(time,*self.args,**self.kwargs)

    def __cmp__(self, other):
        return self.callback==other.callback \
        and self.args==other.args \
        and self.kwargs==other.kwargs \
        and self.instance==other.instance \
        and self.plan_time==other.plan_time

    def __str__(self):
        if callable(self.callback):
            return "%s:callback=%s:%s,args=%s,kwargs=%s,plan_time=%s" % (super(Plan,self).__str__(),self.callback,self.args,self.kwargs,self.plan_time)
        else:
            return "%s:callback=%s.%s,args=%s,kwargs=%s,plan_time=%s" % (super(Plan,self).__str__(),self.instance,self.callback,self.args,self.kwargs,self.plan_time)

    @staticmethod
    def make_plan(callback,args=(),kwargs={},year=None,month=None,day=None,hour=None,minute=None,second=None,week=None):
        return Plan(second,callback,args,kwargs,False,year,month,day,hour,minute,week)

    @staticmethod
    def make_interval_plan(callback,args=(),kwargs={},seconds=0,minutes=0,hours=0,days=0,weeks=0):
        return Plan(seconds,callback,args,kwargs,True,days=days,hours=hours,minutes=minutes,weeks=weeks)
