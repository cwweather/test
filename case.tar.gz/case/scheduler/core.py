
import threading
import timer
from base.pipe import Pipe

class PlanTimeServer():
    def __init__(self):
        self._pp,self._sp=Pipe()
        self._thread=threading.Thread(target=self.run)

        self._thread.setDaemon(True)

    def run(self):
        while True:
            method,id,plan_time=self._pp.recv()
            if method=="register":
                space_manager.get_space_times()[id].register(plan_time)
            elif method=="unregister":
                space_manager.get_space_times()[id].unregister(plan_time)

    def get_sp(self):
        return self._sp

    def start(self):
        self._thread.start()

server=PlanTimeServer()
space_manager=None
current_queue=[]

def find_next_queue(time):
    global current_queue
    current_queue=[]
    for id,space_time in space_manager.get_space_times().items():
        ids=[]
        for plan_time in space_time.get_plan_times():
            if plan_time.check(time):
                ids.append(plan_time.id)
        if ids:
            current_queue.append((space_time,ids))

def time_out(time):
    global current_queue
    for cq in current_queue:
        cq[0].active(time,cq[1])
    find_next_queue(time)


def add_plan(id,plan_time):
    server.get_sp().send(("register",id,plan_time))

def remove_plan(id,plan_time):
    server.get_sp().send(("unregister",id,plan_time))

def init(sm):
    global space_manager
    space_manager=sm

def start():
    server.start()
    timer.start_timer(time_out)
    timer.loop()
