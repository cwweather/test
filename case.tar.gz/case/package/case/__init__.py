# -*- coding: utf-8 -*-
#13-12-4

from processor import Processor
import settings

try:
    disable=settings.case.disable
except:pass

def start():
    p=Processor()
    p.register()
