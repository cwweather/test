# -*- coding: utf-8 -*-

from ..case import register_case,Case
import datetime
from utils import Enum
from cache.risk import RiskRestrict
from cache.user import Profile
from base.geo import get_distance

@register_case
class TempParamTrade(Case):
    '''
    临调内商户信用卡单笔交易交易额大于商户信用卡单笔限额。
    参数：
    备注：txamt 交易额
    '''
    has_syssn = True

    def get_tmp_param(self):
        sql = "select userid from risk_restrict_tmp_param where end_time>='%s' group by userid" % self.get_this_today()
        return [user["userid"] for user in self.risk2_db.query(sql)]

    def get_tradesum(self, users):
        sql = "select userid,txamt,syssn from record_@1 where SYSDTM>='%s' and SYSDTM<'%s' and userid in (%s) and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null)" % (self.get_this_start_time(),self.get_this_end_time(), ",".join([str(user) for user in users]))
        trades={}
        for trade in self.trade_db.query(sql):
            if trade["userid"] not in trades:
                trades[trade["userid"]]=[]
            trades[trade["userid"]].append({"txamt":trade["txamt"],"syssn":trade["syssn"]})
        return trades

    def get_riskrestrict(self, users):
        return {user["userid"]:user["amt_per_credit"] for user in RiskRestrict() if user["userid"] in users}

    def search(self,sql=''):
        users = self.get_tmp_param()
        trades=self.get_tradesum(users)
        restricts=self.get_riskrestrict(users)
        datas=[]
        for user in users:
            if user in trades and user in restricts:
                for trade in trades[user]:
                    if trade["txamt"]>restricts[user]:
                        datas.append({"userid":user,"txamt":trade["txamt"],"syssn":trade["syssn"]})
        return datas

@register_case
class DebitSteal(Case):
    '''
    商户借记卡刷卡交易额小于(txamt)且卡数大于(card_count)。
    参数：txamt 交易额;card_count 卡数
    备注：carcd 卡号
    '''

    def __init__(self,*args,**kwargs):
        super(DebitSteal,self).__init__(*args,**kwargs)

        self.txamt=int(self.txamt)*100
        self.card_count=int(self.card_count)

    def get_users(self):
        sql="select userid from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and txamt<=%s and (cardtp='01' or cardtp='04') group by userid" % (self.get_this_start_time(),self.get_this_end_time(),self.txamt)
        return self.trade_db.query(sql)

    def search(self,sql=''):
        users=self.get_users()
        if not users:return []
        sql = "select userid,cardcd from record_@1 where userid in (%s) and sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and txamt<=%s and (cardtp='01' or cardtp='04') group by userid,cardcd" % (",".join([str(user["userid"]) for user in users]),self.get_this_today(),self.get_this_end_time(),self.txamt)
        trades = self.trade_db.query(sql)

        cards = {}
        for _t in trades:
            if _t['userid'] in cards:
                cards[_t['userid']].append(_t['cardcd'])
            else:
                cards[_t['userid']] = [_t['cardcd']]

        return [{"userid":user,"cardcd":', '.join(set(cards[user]))} for user in cards if len(set(cards[user]))>=self.card_count]

@register_case
class DebitForge(Case):
    '''
    商户借记卡交易额大于(txamt)且同卡每(count)次交易时间差小于(time)秒。
    参数：txamt 交易额;card_count 交易数;time_diff_ 时间差
    备注：carcd 卡号
    '''

    def __init__(self,*args,**kwargs):
        super(DebitForge,self).__init__(*args,**kwargs)

        self.txamt=int(self.txamt)
        self.count=int(self.count)
        self.time_diff=int(self.time_diff)

    def get_users(self):
        sql="select userid from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and txamt>=%s and (cardtp='01' or cardtp='04') group by userid" % (self.get_this_start_time(),self.get_this_end_time(),self.txamt)
        return self.trade_db.query(sql)

    def get_trades(self):
        users=self.get_users()
        if not users:return []
        sql = "select userid,cardcd,sysdtm from record_@1 where userid in (%s) and sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and txamt>=%s and (cardtp='01' or cardtp='04') order by sysdtm" % (",".join([str(user["userid"]) for user in users]),self.get_this_today(),self.get_this_end_time(),self.txamt)
        all_trade = self.trade_db.query(sql)

        trades = {}
        for trade in all_trade:
            time=datetime.datetime.strptime(trade["sysdtm"],'%Y-%m-%d %H:%M:%S')
            if trade['userid'] not in trades:
                trades[trade['userid']]={}
            if trade['cardcd'] not in trades[trade['userid']]:
                trades[trade['userid']][trade['cardcd']]=[]
            trades[trade['userid']][trade['cardcd']].append(time)
        return trades

    def search(self,sql=''):
        trades = self.get_trades()
        datas=[]
        for u in trades:
            for c in trades[u]:
                if len(trades[u][c]) >= 3 and self.limit(trades[u][c]):
                    datas.append({"userid":u,"cardcd":c})
        return datas

    def limit(self,times):
        cnt = self.count
        times.sort()
        for i in xrange(len(times) - cnt + 1):
            if (times[i+cnt-1]-times[i]) <= datetime.timedelta(seconds=self.time_diff):
                return True
        return False

@register_case
class CardAmountOver(Case):
    '''
    商户(card_type)同卡(days)天交易总额大于(abov_amt)。
    参数：card_type 卡类型;days 天数;abov_amt 总交易额
    备注：cardcd 卡号;txamt 交易总额
    '''

    CARD_TYPE=Enum(
        ALL=(0,u'所有卡类型'),
        DEBIT=(1,u'借记卡'),
        CREDIT=(2,u'信用卡'),
    )

    def __init__(self,*args,**kwargs):
        super(CardAmountOver,self).__init__(*args,**kwargs)

        self.card_type=int(self.card_type)
        self.days=int(self.days)
        self.abov_amt=int(self.abov_amt)*100

    def get_card_type(self):
        if self.card_type==self.CARD_TYPE.ALL:
            return ''
        elif self.card_type==self.CARD_TYPE.DEBIT:
            return "and cardtp='01'"
        elif self.card_type==self.CARD_TYPE.CREDIT:
            return "and cardtp='02'"
        return ''

    def get_cards(self):
        sql="select cardcd,userid,sysdtm from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 %s order by sysdtm" % (self.get_this_start_time(),self.get_this_end_time(),self.get_card_type())
        return {trade["cardcd"]:trade["userid"] for trade in self.trade_db.query(sql)}

    def search(self,sql=''):
        cards=self.get_cards()
        if not cards:return []
        sql = "select cardcd,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and busicd='000000' and retcd='0000' and cancel=0 %s and cardcd in (%s) group by cardcd having sumamt>%s" % ((self.time.get_start() - datetime.timedelta(days=self.days)).strftime('%Y-%m-%d 00:00:00'),self.get_card_type(),",".join(["'"+card+"'" for card in cards]),self.abov_amt)
        trades = self.trade_db.query(sql)

        return [{"userid":cards[trade['cardcd']],'cardcd': trade['cardcd'], 'sumamt': trade['sumamt']} for trade in trades]

@register_case
class UserAmountOver(Case):
    '''
    商户(card_type)当月交易总额大于(abov_amt)。
    参数：card_type 卡类型;abov_amt 总交易额
    备注：txamt 交易总额
    '''

    CARD_TYPE=Enum(
        ALL=(0,u'所有卡类型'),
        DEBIT=(1,u'借记卡'),
        CREDIT=(2,u'信用卡'),
    )

    def __init__(self,*args,**kwargs):
        super(UserAmountOver,self).__init__(*args,**kwargs)

        self.card_type=int(self.card_type)
        self.abov_amt=int(self.abov_amt)*100

    def get_card_type(self):
        if self.card_type==self.CARD_TYPE.ALL:
            return ''
        elif self.card_type==self.CARD_TYPE.DEBIT:
            return "and cardtp='01'"
        elif self.card_type==self.CARD_TYPE.CREDIT:
            return "and cardtp='02'"
        return ''

    def get_users(self):
        sql="select userid from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 %s group by userid" % (self.get_this_start_time(),self.get_this_end_time(),self.get_card_type())
        return self.trade_db.query(sql)

    def search(self,sql=''):
        users=self.get_users()
        if not users:return []
        sql = "select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 %s and userid in (%s) group by userid having sumamt>=%s" % (self.get_this_today(),self.get_this_end_time(),self.get_card_type(),",".join([str(user["userid"]) for user in users]),self.abov_amt)
        users = self.trade_db.query(sql)
        return [{"userid":user["userid"],'txamt': user['sumamt']} for user in users]

@register_case
class RiskToCase(Case):
    '''
    交易包含特定返回码或特定风控触发规则集
    参数：payresp 交易返回码;hitedrules 风控触发规则集
    备注：hitedrules 规则集
    '''
    has_syssn = True

    def __init__(self,*args,**kwargs):
        super(RiskToCase,self).__init__(*args,**kwargs)

        self.txamt=int(self.txamt)*100
        self.sumamt=int(self.sumamt)*100
        self.cardtp=str(self.cardtp).strip()
        self.payresp=str(self.payresp)
        self.hitedrules=str(self.hitedrules).strip().split(",")
        self.riskret=str(self.riskret).strip().split(",")
        self.bussinesstrade_distance=int(self.bussinesstrade_distance)

    def get_cardtp(self):
        if self.cardtp:
            return "and cardtp='%s'" % self.cardtp
        else:
            return ""

    def get_payresp(self):
        if self.payresp:
            return "and payresp='%s'" % self.payresp
        return ''

    def get_hitedrules(self):
        if not self.hitedrules or self.hitedrules==['']:return ''
        hitedrules=""
        if self.hitedrules[0][0]=='-':
            self.hitedrules[0]=self.hitedrules[0][1:]
            for h in self.hitedrules:
                hitedrules+="hitedrules not like '%"+str(h)+"%' and "
        else:
            for h in self.hitedrules:
                hitedrules+="hitedrules like '%"+str(h)+"%'  or "

        hitedrules=hitedrules.strip()
        if hitedrules:
            hitedrules="and ("+hitedrules[:-3]+")"
        return hitedrules

    def get_riskret(self):
        if not self.riskret or self.riskret==['']:return ''
        riskret=""
        if self.riskret[0][0]=='-':
            self.riskret[0]=self.riskret[0][1:]
            for r in self.riskret:
                riskret+="riskret not like '%"+str(r)+"%' and "
        else:
            for r in self.riskret:
                riskret+="riskret like '%"+str(r)+"%'  or "

        riskret=riskret.strip()
        if riskret:
            riskret="and ("+riskret[:-3]+")"
        return riskret

    def get_txamt(self):
        if self.txamt<0:return ''
        return 'and txamt>=%s' % self.txamt

    def check_sumamt(self,datas):
        sql="select userid,sum(txamt) as sumamt from record_@1 where userid in (%s) and sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 group by userid order by userid" % (",".join(set([str(data["userid"]) for data in datas])),self.get_today(),self.get_this_end_time())
        sumamts={sumamt["userid"]:sumamt["sumamt"] for sumamt in self.trade_db.query(sql)}
        results=[]
        for data in datas:
            if data["userid"] in sumamts and sumamts[data["userid"]]>=self.sumamt:
                data.update({"sumamt":sumamts[data["userid"]]})
                results.append(data)
        return results

    def check_bussinesstrade_distance(self,datas):
        sql="select userid,syssn,longtitude,latitude from trade_record where syssn in (%s)" % ",".join(["'"+str(data["syssn"])+"'" for data in datas])
        trades={trade["syssn"]:trade for trade in self.risk2_db.query(sql)}

        profile=Profile()
        results=[]
        for data in datas:
            trade=trades[data["syssn"]]
            user=profile[data["userid"]]
            if trade and user:
                distance=get_distance(trade["latitude"],trade["longtitude"],user["latitude"],user["longitude"]) if trade["latitude"] and trade["longtitude"] and user["latitude"] and user["longitude"] else 0
                if not distance or distance>=self.bussinesstrade_distance:
                    data.update({"distance":"%.3f" % distance,"trade_position":"%s,%s" % (trade['latitude'],trade['longtitude'])})
                    results.append(data)
        return results

    def search(self,sql=''):
        sql = "select userid,syssn,hitedrules,riskret,cardcd,txamt from trade_record where sysdtm>='%s' and sysdtm<'%s' %s %s %s %s %s" % (self.get_this_start_time(),self.get_this_end_time(),self.get_cardtp(),self.get_payresp(),self.get_hitedrules(),self.get_riskret(),self.get_txamt())
        datas=self.risk2_db.query(sql)

        if not datas:return datas
        if self.sumamt>=0:
            datas=self.check_sumamt(datas)

        if not datas:return datas
        if self.bussinesstrade_distance>=0:
            datas=self.check_bussinesstrade_distance(datas)
        return datas

@register_case
class RiskToCaseEx(Case):
    '''
    根据风控标记和其他条件生成案件
    与RiskToCase区别：忽略指定时间内出现指定 的次数
    参数：
        txamtMin：单笔金额范围小值
        txamtMax：单笔金额范围大值（当两值相同忽略该条件）
        sumamtMin：总额金额范围小值
        sumamtMax：总额金额范围大值（当两值相同忽略该条件）
        cardtp：卡片类型，1－借记卡；2－信用卡；3－忽略卡类型
        payresp：返回码（成功交易或者拒绝的交易）
        hitedrules：警告集
        riskret：拒绝集
    备注：
        cnt：命中次数
        sumamt：命中总金额
        hitedrules 规则集
    '''
    has_syssn = True

    def __init__(self, *args, **kwargs):
        super(RiskToCaseEx, self).__init__(*args, **kwargs)

        self.txamtMin = int(self.txamtMin)*100
        self.txamtMax = int(self.txamtMax)*100
        self.sumamtMin = int(self.sumamtMin)*100
        self.sumamtMax = int(self.sumamtMax)*100
        self.cardtp = str(self.cardtp).strip()
        self.payresp = str(self.payresp)
        self.hitedrules = str(self.hitedrules).strip().split(",")
        self.riskret = str(self.riskret).strip().split(",")

    def get_cardtp(self):
        if self.cardtp or self.cardtp == "3":
            return "and cardtp='%s'" % self.cardtp
        else:
            return ""

    def get_payresp(self):
        if self.payresp:
            return "and payresp='%s'" % self.payresp
        return ''

    def get_hitedrules(self):
        if not self.hitedrules or self.hitedrules == ['']:
            return ''
        hitedrules = ""
        if self.hitedrules[0][0] == '-':
            self.hitedrules[0] = self.hitedrules[0][1:]
            for h in self.hitedrules:
                hitedrules += "hitedrules not like '%"+str(h)+"%' and "
        else:
            for h in self.hitedrules:
                hitedrules += "hitedrules like '%"+str(h)+"%'  or "

        hitedrules = hitedrules.strip()
        if hitedrules:
            hitedrules = "and ("+hitedrules[:-3]+")"
        return hitedrules

    def get_riskret(self):
        if not self.riskret or self.riskret==['']:return ''
        riskret=""
        if self.riskret[0][0]=='-':
            self.riskret[0]=self.riskret[0][1:]
            for r in self.riskret:
                riskret+="riskret not like '%"+str(r)+"%' and "
        else:
            for r in self.riskret:
                riskret+="riskret like '%"+str(r)+"%'  or "

        riskret=riskret.strip()
        if riskret:
            riskret="and ("+riskret[:-3]+")"
        return riskret

    def get_txamt(self):
        if self.txamtMin < 0 or self.txamtMax < 0 or self.txamtMin == self.txamtMax:
            return ""
        return "and txamt>=%s and txamt<=%s" % (self.txamtMin, self.txamtMax)

    def check_sumamt(self,datas):
        results=[]
        for data in datas:
            if data["sumamt"] >= self.sumamtMin and data["sumamt"] <= self.sumamtMax:
                results.append(data)
        return results

    def search(self,sql=''):
        sql = "select userid, count(1) as cnt, sum(txamt) as sumamt from trade_record where sysdtm>='%s' and sysdtm<'%s' %s %s %s %s %s group by userid" % (self.get_this_start_time(),self.get_this_end_time(),self.get_cardtp(),self.get_payresp(),self.get_hitedrules(),self.get_riskret(),self.get_txamt())
        datas = self.risk2_db.query(sql)

        if not datas:
            return datas
        if self.sumamtMax > 0 and self.sumamtMax != self.sumamtMin:
            datas = self.check_sumamt(datas)

        return datas
