# -*- coding: utf-8 -*-

import json
from ..case import register_case,Case
import datetime
import settings
from core.oceandriver import Driver
from cache.user import Profile
from base.geometry import check_point_in_polygon
from ..casecache.trade import NinetyDayActivityUser

@register_case
class SamePosition(Case):
    '''
    商户信用卡交易金额不低于（max_amt），且该交易的GPS信息，保留小数点后(bits)位，与其他(days)天内有交易的商户的入网交易信息一致。
    参数：max_amt 交易金额;bits 小数位数;days 天数
    备注：txamt 交易额;carcd 卡号;alluser 相同商户
    '''

    def __init__(self,*args,**kwargs):
        super(SamePosition,self).__init__(*args,**kwargs)

        self.core_db=Driver(settings.db.core)

        self.max_amt=int(self.max_amt)*100
        self.bits=int(self.bits)
        self.days=int(self.days)

    def search(self,sql=''):
        sql = "SELECT userid,LONGITUDE,LATITUDE,cardcd,txamt from record_@1 WHERE SYSDTM>='%s' and SYSDTM<'%s' and busicd='000000' and retcd='0000' and cancel=0 and txamt>=%s AND LONGITUDE!=0 AND LATITUDE!=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) GROUP BY USERID,LONGITUDE,LATITUDE,CARDCD,TXAMT ORDER BY USERID" % (self.get_this_start_time(),self.get_this_end_time(), self.max_amt)
        trades = self.trade_db.query(sql)
        users={t["userid"]:(t["txamt"],t["cardcd"]) for t in trades}
        positions=["%.3f,%.3f" % (t['latitude'], t['longitude']) for t in trades]

        ret = {pos["userid"]:"%.3f,%.3f" % (pos['latitude'], pos['longitude']) for pos in Profile() if pos['latitude'] and pos['longitude']}

        active_users=NinetyDayActivityUser()
        user_position = {}
        for _r in ret:
            if ret[_r] not in positions or _r not in active_users:
                continue
            if ret[_r] not in user_position:
                user_position[ret[_r]]=[]
            user_position[ret[_r]].append(_r)

        trade_pos = {}
        for _t in trades:
            _pos = "%.3f,%.3f" % (_t['latitude'], _t['longitude'])
            if _pos in user_position and user_position[_pos] != [_t['userid'],]:
                if _pos in trade_pos:
                    if _t['userid'] not in trade_pos[_pos]:
                        trade_pos[_pos].append(_t['userid'])
                else:
                    trade_pos[_pos] = [_t['userid'],]
                    trade_pos[_pos].extend(user_position[_pos])

        return [{"userid":trade_pos[tp][0],'txamt': users[trade_pos[tp][0]][0], 'cardcd': users[trade_pos[tp][0]][1], 'alluser': trade_pos[tp][1:]} for tp in trade_pos if len(trade_pos[tp])>=2]

@register_case
class RiskTradePosition(Case):
    def __init__(self,*args,**kwargs):
        super(RiskTradePosition,self).__init__(*args,**kwargs)

        self.city=json.loads(str(self.city))

    def search(self,sql=''):
        sql = "select userid,longitude,latitude from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and longitude!=0 and latitude!=0 order by userid" % (self.get_this_start_time(),self.get_this_end_time())
        trades=self.trade_db.query(sql)
        return [trade for trade in trades if check_point_in_polygon((trade["longitude"],trade["latitude"]),self.city)]