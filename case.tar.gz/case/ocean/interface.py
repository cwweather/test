# -*- coding: utf-8 -*-
#13-11-27
from base import vtraceback as traceback
import copy
import time
import threading
import multiprocessing
from base.pipe import Pipe
from config import log
import config

class InterfaceData(object):
    def __init__(self,request,interface):
        self._request=request
        self._interface=interface
        self._data=None
        self._is_recv=False
        self.protocol=None

        self._interface.lock()

    def get_result(self):
        if not self._is_recv:
            self._data=self._interface._sp.recv()
            self._interface.unlock()
            self._is_recv=True
        if isinstance(self._data,Exception):
            raise self._data
        return self._data

    def __del__(self):
        if not self._is_recv:
            self._data=self._interface._sp.recv()
            self._interface.unlock()
            self._is_recv=True

class Interface(object):
    def __init__(self):
        self._pp,self._sp=Pipe()
        self._lock=multiprocessing.Lock()
        self._active=multiprocessing.Value("i",0)
        self._active_lock=multiprocessing.Lock()
        self._id=str(id(self))
        self._busy=multiprocessing.Value("i",0)
        self._current_request=None
        self._run_time=0
        self._sleep_time=0
        self._totle_time=0
        self._totle_count=0
        self._info=None

    def request(self,request):
        with self._lock:
            self._sp.send(request)
            if not request.sync:
                result=self._sp.recv()
                if isinstance(result,Exception):
                    raise result
            else:
                result=InterfaceData(request,self)
        return result

    def __hash__(self):
        return str(id(self))

    def loop(self):
        self._current_request=self._pp.recv()
        self._busy.value=1
        self._run_time=time.time()

        try:
            result=self._current_request.run()
            log.debug("ocean request:%s,ret=%s,time=%.3fms",self._current_request,type(result),(time.time()-self._run_time)*1000)
        except Exception,e:
            log.error("ocean request error:%s\n%s",self._current_request,traceback.format_exc())
            result=e

        try:
            self._pp.send(result)
        except:
            log.error("ocean request send result error:result=%s\n%s",result,traceback.format_exc())
            self._pp.send(None)

        self._current_request=None
        self._busy.value=0
        self._sleep_time=time.time()
        self._totle_time+=self._sleep_time-self._run_time
        self._totle_count+=1

    def nop(self):
        self._pp.send(None)

    def get_id(self):
        return self._id

    def is_busy(self):
        with self._lock:
            return bool(self._busy.value)

    def set_active(self,state=True):
        with self._active_lock:
            if state:
                if self._active.value:return False
                self._active.value=1
            else:
                if not self._active.value:return False
                self._active.value=0
            return True

    def update_info(self,info):
        self._info=info

    def lock(self):
        self._info.lock()

    def unlock(self):
        self._info.unlock()

    def state(self):
        return {
            "pid":multiprocessing.current_process().pid,
            "id":self._id,
            "busy":bool(self._busy.value),
            "current_request":self._current_request,
            "run_time":self._run_time,
            "sleep_time":self._sleep_time,
            "totle_time":self._totle_time,
            "totle_count":self._totle_count,
        }

class InterfaceInfo(object):
    def __init__(self,data):
        self._data=copy.weakref.ref(data)
        self._space=None
        self._interface=None
        self._time=0
        self._ocean=self.get_ocean()
        self._lock=threading.Lock()
        self._lock_count=0

    def get_ocean(self):
        import ocean
        return ocean.get_ocean()

    def destory(self):
        with self._lock:
            if self._interface:
                self.release()
            InterfaceManager.obj.remove(self)

    def acquire(self,hash):
        if not self._interface:
            self._space=self.get_space(hash)
            self._interface=self._space.get_interfaces().acquire(self)
            self._interface.update_info(self)
            self._time=time.time()

    def release(self):
        if self._interface:
            self._interface.update_info(None)
            self._space.get_interfaces().release(self._interface)
            self._interface=None
            self._space=None

    def get_space(self,hash):
        return self._ocean.get_spaces().select(hash)

    def get_interface(self,hash):
        with self._lock:
            if not self._interface:
                self.acquire(hash)
            self._time=time.time()
            return self._interface

    def update(self):
        with self._lock:
            if self._lock_count==0 and self._interface:
                if not self._interface.is_busy() and time.time()-self._time>=config.get("interface_release_timeout",0.1):
                    self.release()

    def lock(self):
        self._lock_count+=1

    def unlock(self):
        if self._lock_count>0:
            self._lock_count-=1

class InterfaceManager(object):
    obj=None
    def __init__(self):
        self._infos=[]
        self._thread=threading.Thread(target=self.run)
        self._stop=False

        self._thread.setDaemon(True)
        self._thread.start()

    def run(self):
        while not self._stop:
            for info in self._infos:
                info.update()
            time.sleep(config.get("interface_release_timeout",0.1))

    def remove(self,info):
        self._infos.remove(info)

    def add(self,info):
        self._infos.append(info)

    @staticmethod
    def register(data):
        if not InterfaceManager.obj:
            InterfaceManager.obj=InterfaceManager()
        info=InterfaceInfo(data)
        InterfaceManager.obj.add(info)
        return info