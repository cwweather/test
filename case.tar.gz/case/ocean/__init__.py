from utils import Enum
from queue import SpaceQueue
from worker import Worker
from space import Space
import config
from config import log

OCEAN_STATE=Enum(
    UNINIT=0,
    INITED=1,
    LOADED=2,
    OPENED=3,
    CLOSED=4
)

class OceanAlreadyInitError(Exception):pass
class OceanAlreadyOpenError(Exception):pass
class OceanAlreadyLoadError(Exception):pass
class OceanNotOpenedError(Exception):pass

class Ocean(object):
    def __init__(self):
        self._space_queue=SpaceQueue()
        self._state=OCEAN_STATE.UNINIT

    def init(self):
        if self._state!=OCEAN_STATE.UNINIT and self._state!=OCEAN_STATE.CLOSED:
            raise OceanAlreadyInitError
        self.init_spcae()
        self._state=OCEAN_STATE.INITED

    def init_spcae(self):
        for i in range(config.get("space_count",2)):
            space=Space()
            self._space_queue.add(space)
            space.init()

    def load(self):
        if self._state!=OCEAN_STATE.INITED:
            raise OceanAlreadyLoadError
        for space in self._space_queue:
            space.load()
        self._state=OCEAN_STATE.LOADED

    def open(self):
        if self._state!=OCEAN_STATE.LOADED:
            raise OceanAlreadyOpenError
        for space in self._space_queue:
            space.open()
        self._state=OCEAN_STATE.OPENED

    def close(self):
        if self._state!=OCEAN_STATE.OPENED:
            raise OceanNotOpenedError
        for space in self._space_queue:
            space.close()
        self._state=OCEAN_STATE.CLOSED

    def get_spaces(self):
        return self._space_queue

    def request(self,request):
        space=self._space_queue.select(request.__hash__())
        interface=space.get_interfaces().acquire()
        result=interface.request(request)
        space.get_interfaces().release(interface)
        return result

_ocean=Ocean()

def init():
    _ocean.init()

def load():
    _ocean.load()

def open():
    _ocean.open()

def close():
    state=get_state()
    _ocean.close()
    log.info("ocean state:%s",state)

def get_ocean():
    return _ocean

def request(request):
    return _ocean.request(request)

def set_config(c):
    config.update(c)

def get_state():
    states=[]
    totle_time,totle_count,mem_size=0,0,0

    for space in _ocean._space_queue:
        state=space.option().state()
        totle_time+=state["totle_time"]
        totle_count+=state["totle_count"]
        mem_size+=state["mem_size"]
        states.append(state)

    return {
        "totle_time":totle_time,
        "totle_count":totle_count,
        "mem_size":mem_size,
        "space_states":states,
    }

