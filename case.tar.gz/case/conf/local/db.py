# -*- coding: utf-8 -*-

from base import get_trade_table_names

risk2={
    "driver":"db",
    "db_type":"mysql",
    "user":"qf",
    "passwd":"123456",
    "port":3306,
    "db":"qf_risk_2",
    "master":{
        "host":"172.100.101.150",
    },
    "slavers":[{
        "host":"172.100.101.150",
    }],
    "timeout":120,
    "charset":"utf8",
}

core={
    "driver":"db",
    "db_type":"mysql",
    "master":{
        "host":"172.100.101.150",
    },
    "slavers":[{
        "host":"172.100.101.150",
    }],
    "user":"qf",
    "passwd":"123456",
    "port":3306,
    "db":"qf_core",
    "timeout":120,
    "charset":"utf8",
}

master_mis={
    "driver":"db",
    "db_type":"mysql",
    "master":{
        "host":"172.100.101.150",
    },
    "slavers":[{
        "host":"172.100.101.150",
    }],
    "user":"qf",
    "passwd":"123456",
    "port":3306,
    "db":"qf_mis",
    "timeout":120,
    "charset":"utf8",
}

mis={
    "driver":"db",
    "db_type":"mysql",
    "master":{
        "host":"172.100.101.150",
    },
    "slavers":[{
        "host":"172.100.101.150",
    }],
    "user":"qf",
    "passwd":"123456",
    "port":3306,
    "db":"qf_mis",
    "timeout":120,
    "charset":"utf8",
}

settle={
    "driver":"db",
    "db_type":"mysql",
    "master":{
        "host":"172.100.101.150",
    },
    "slavers":[{
        "host":"172.100.101.150",
    }],
    "user":"qf",
    "passwd":"123456",
    "port":3306,
    "db":"qf_settle",
    "timeout":120,
    "charset":"utf8",
}


trade={
    "driver":"multable_db",
    "db_type":"mysql",
    "user":"qf",
    "passwd":"123456",
    "port":3306,
    "db":"qf_trade",
    "timeout":120,
    "charset":"utf8",
    "master":{
        "host":"172.100.101.150",
    },
    "slavers":[{
        "host":"172.100.101.150",
    }],
    "split_name":"sysdtm",
    "split_type":"datetime",
    "split_all":get_trade_table_names,
    "split_all_format":"%Y%m",
    "split_format":"'%Y-%m-%d %H:%M:%S'",
    "sync":True,
    }

oracle={
    "driver":"db",
    "db_type":"oracle",
    "dsn":"qfora",
    "user":"qfbi",
    "passwd":"qfpay2013!",
    }

fengxiang={
    "driver":"fengxiang",
    "api_id":"51c3d207166a41599299b510",
    "app_key":"6909101c3fed4d3a92b95509b3d4f791",
    }

