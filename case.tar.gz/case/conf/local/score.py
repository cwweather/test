# -*- coding: utf-8 -*-
#13-11-27
disable=True

today_rules=(
    {
        "name":"credit_sumamt",
        "weights":[
            {"start":0,"end":1000,"weight":-1.8484},
            {"start":1000,"end":2000,"weight":-0.6778},
            {"start":2000,"end":5000,"weight":-0.0403},
            {"start":5000,"end":10000,"weight":-0.1777},
            {"start":10000,"end":20000,"weight":0.6109},
            {"start":20000,"end":50000,"weight":1.8331},
            {"start":50000,"end":None,"weight":4.5355},
            ]
    },
)

history_cases=(
    "ASST005",
    "ASST006",
    "ASST007",
    "ASST008",
    "ASST009",
)