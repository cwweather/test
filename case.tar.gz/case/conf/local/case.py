# -*- coding: utf-8 -*-
#14-1-16

factor={}#"CumulativeCredit":"CumulativeCredit",}

case_scope=2

data={
    "1":"db",
    "2":"log",
    "3":"file",
    "4":"mail",
}

data_file={
    "default": "/home/caiwenwen/case/tmp/",
    "case":{}
}

data_mail={
    "default":['sujian@qfpay.com'],
    "case":{}
}