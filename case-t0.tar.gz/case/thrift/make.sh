thrift -gen py tyfoon.thrift
rm -rf ../ityfoon
mv gen-py/ityfoon ..
rm -rf gen-py