namespace py ityfoon

// 处置结果码
enum QFRET{
    OK          = 0000,   //成功
    PARTLYOK    = 0001,   //部分成功
    FAILURE     = 0002,   //操作失败
    PARAM       = 2100,   //参数错误
    DBERR       = 2000,   //数据库查询错误
    NODATA      = 2300,   //无数据
    DATAEXIST   = 2301,   //数据已存在
    UNKOWNERR   = 2400,   //未知错误
}

// 对象类型
enum CriminalType{
    MERCHANT = 1, // 商户
    CARD = 2, // 卡
    TRADE = 3, // 交易
    CHANNEL = 4 // 渠道
}

// 处置类型
enum Penalty{
    BLACKLISTING = 1, //拉黑处理
    RISKPARAM = 2, // 更改风控参数
    LISTING = 3, // 无具体操作处置
    UPDATEUSERSTATE = 4, // 修改商户状态
}

// 被处置的对象
struct Punishment{
    1: required string criminalid, // 对象id，userid或者cardcd
    2: required CriminalType criminaltype, // 对象类型，商户或者卡
    3: required string operator, // 操作者
    4: required Penalty penalty, // 处置方式，拉黑卡，拉黑商户
    5: required string param, // 处置参数，
    6: required string reason, //处置原因
}

//  单个处置记录
struct Record{
    1: required i32 respcd, //成功或者失败
    2: required string respmsg, // 处置结果
    3: required Punishment punishment, // 处置对象
}

// 处置记录
struct PunishmentRecord{
    1: required i32 respcd, // 返回码
    2: required string respmsg, // 处置结果
    3: optional list<Record> records, // 返回的数据结果，可为空
}

// 处置执行结果
struct Result{
    1: required QFRET respcd, //成功或者失败
    2: required string resperr, // 返回代码解释
    3: required string respmsg, // 返回结果解释
    4: optional list<Punishment> data, // 返回数据
}

// 执行平台
service Tyfoon{
    bool checkparam(1: Punishment punishment), //检查格式
    Result execute(1: list<Punishment> punishments), // 执行
    string getList(1: string criminalid, 2: CriminalType criminaltype, 3: string starttime, 4: string endtime, 5: string operator), //  获取名单
    void ping()//ping
}