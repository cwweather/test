# -*- coding: utf-8 -*-
#13-12-4

import threading
import multiprocessing
import types
from base.pipe import Pipe
from scheduler import Plan as BasePlan,register as base_register,unregister as base_unregister,register_space,open_space,init,load,start as base_start,stop,set_config
import processor
from processor import Task

class Info(object):
    def __init__(self,callback,args,kwargs):
        if type(callback) == types.MethodType:
            self.instance=callback.im_self
            self.callback=callback.__name__
        else:
            self.callback=callback
        self.args=args
        self.kwargs=kwargs

    def run(self,time):
        if callable(self.callback):
            task=Task(self.callback,time,*self.args,**self.kwargs)
        else:
            task=Task(getattr(self.instance,self.callback),time,*self.args,**self.kwargs)
        processor.add_task(task)
        return True

class Plan(object):
    @staticmethod
    def make_plan(callback,args=(),kwargs={},year=None,month=None,day=None,hour=None,minute=None,second=None,week=None):
        info=Info(callback,args,kwargs)
        return BasePlan.make_plan(info.run,(),{},year,month,day,hour,minute,second,week)

    @staticmethod
    def make_interval_plan(callback,args=(),kwargs={},seconds=0,minutes=0,hours=0,days=0,weeks=0):
        info=Info(callback,args,kwargs)
        return BasePlan.make_interval_plan(info.run,(),{},seconds,minutes,hours,days,weeks)

class Server(object):
    def __init__(self):
        self._pp,self._sp=Pipe()
        self._lock=multiprocessing.Lock()
        self._thread=threading.Thread(target=self.run)
        self._process=multiprocessing.current_process()

        self._thread.setDaemon(True)
        self._thread.start()

    def run(self):
        while True:
            method,plan=self._pp.recv()
            if method=="register":
                ret=base_register(plan)
            elif method=="unregister":
                ret=base_unregister(plan)
            self._pp.send(ret)

    def register(self,plan):
        if self._process.pid==multiprocessing.current_process().pid:
            return base_register(plan)
        else:
            with self._lock:
                self._sp.send(("register",plan))
                return self._sp.recv()

    def unregister(self,plan):
        if self._process.pid==multiprocessing.current_process().pid:
            return base_unregister(plan)
        else:
            with self._lock:
                self._sp.send(("unregister",plan))
                return self._sp.recv()

_server=None

def start():
    global _server
    if not _server:
        _server=Server()
    base_start()

def register(plan):
    return _server.register(plan)

def unregister(plan):
    return _server.unregister(plan)