# -*- coding: utf-8 -*-
#13-12-6

from driver import Driver as DataDriver
from ocean.data import Data,DataHandler,DataRequest,SyncData,SyncDataHandler

class DriverCache(object):
    _cache={}

    @staticmethod
    def get_driver(driver_id):
        driver=DriverCache._cache.get(driver_id)
        if driver:
            del DriverCache._cache[driver_id]
        return driver

    @staticmethod
    def cache_driver(driver_id,driver):
        DriverCache._cache[driver_id]=driver

    @staticmethod
    def check_driver(driver_id):
        return driver_id in DriverCache._cache

class DriverProxy(object):
    def __init__(self,driver_id,driver):
        self._driver_id=driver_id
        self._driver=driver

    def __getattr__(self, name):
        return getattr(self._driver,name)

    def __del__(self):
        if not DriverCache.check_driver(self._driver_id):
            DriverCache.cache_driver(self._driver_id,DriverProxy(self._driver_id,self._driver))

class DriverHandler(DataHandler):
    def __init__(self,config):
        self._config=config

    def handle(self,name,*args,**kwargs):
        db=DataDriver(self._config)
        return getattr(db,name)(*args,**kwargs)

class Driver(Data):
    Handler = DriverHandler

    def __new__(cls, config):
        driver_id=str(str(config).__hash__())
        driver=DriverCache.get_driver(driver_id)
        if driver:
            return driver
        driver=Data.__new__(cls,config)
        driver.__init__(config)
        return DriverProxy(driver_id,driver)

    def __init__(self,config):
        self._config=config
        super(Driver,self).__init__()

    def get_handler(self):
        return self.Handler(self._config)

    def __getattr__(self, name):
        if name.startswith("__"):
            return super(Driver,self).__getattribute__(name)
        def _f(*args,**kwargs):
            return self.request(name,*args,**kwargs)
        return _f

class SyncDriverHandler(SyncDataHandler):
    def __init__(self,config):
        self._config=config

    def handle(self,name,*args,**kwargs):
        db=DataDriver(self._config)
        return getattr(db,name)(*args,**kwargs)

class SyncDriver(SyncData):
    Handler = SyncDriverHandler

    def __new__(cls, config):
        driver_id=str(str(config).__hash__())
        driver=DriverCache.get_driver(driver_id)
        if driver:
            return driver
        driver=SyncData.__new__(cls,config)
        driver.__init__(config)
        return DriverProxy(driver_id,driver)

    def __init__(self,config):
        self._config=config
        super(SyncDriver,self).__init__()

    def get_handler(self):
        return self.Handler(self._config)

    def __getattr__(self, name):
        if name.startswith("__"):
            return super(SyncDriver,self).__getattribute__(name)
        def _f(*args,**kwargs):
            return self.request(name,*args,**kwargs)
        return _f
