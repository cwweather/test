# -*- coding: utf-8 -*-
#13-12-4

import os
import sys
import time
import signal
from base import vtraceback as traceback
import settings
from logger import log
from session import server
import schprocessor
import processor
import ocean
from processor import Task
import command
from command import admin

def empt_fun(*args, **kwargs):
    pass

def init():
    log.info("init...")
    signal.signal(signal.SIGHUP, empt_fun)
    signal.signal(signal.SIGINT, empt_fun)
    signal.signal(signal.SIGTERM, empt_fun)
    schprocessor.init()
    processor.init()
    ocean.init()
    server.open()

    schprocessor.load()
    processor.load()
    ocean.load()

    schprocessor.start()
    processor.start()
    ocean.open()
    log.info("inited")

def init_app(package,app):
    package=__import__(package,globals(),locals(),[app])
    app=getattr(package,app)
    try:
        if callable(app.disable):
            if app.disable():return
        else:
            if app.disable:return
    except:pass
    try:app.init()
    except AttributeError:pass
    except:log.error(traceback.format_exc())
    try:app.start()
    except AttributeError:pass
    except:log.error(traceback.format_exc())

def get_apps(package):
    return [m for m in os.listdir(settings.BASE_PATH+package) if os.path.isdir(settings.BASE_PATH+package+os.sep+m)]

def register_cmd():
    admin.register()

def start():
    log.info("starting...")
    packages=settings.packages
    if isinstance(packages,str):
        packages=[packages]
    for package in packages:
        for app in get_apps(package):
            task=Task(init_app,package,app)
            processor.add_task(task)
    log.info("started")

    register_cmd()

def stop():
    log.info("stoping...")
    packages=settings.packages
    if isinstance(packages,str):
        packages=[packages]
    for package in packages:
        apps=get_apps(package)
        try:
            package=__import__(package,globals(),locals(),apps)
        except:continue
        for app in apps:
            app=getattr(package,app)
            try:app.stop()
            except AttributeError:pass
            except:log.error(traceback.format_exc())
    log.info("stoped")

def exit_handler(signum,frame):
    global is_stop
    stop()
    schprocessor.stop()
    processor.stop()
    ocean.close()
    server.close()
    is_stop=True

is_stop=False
def loop():
    signal.signal(signal.SIGHUP,exit_handler)
    signal.signal(signal.SIGINT,exit_handler)
    signal.signal(signal.SIGTERM,exit_handler)
    while not is_stop:
        try:
            command.loop()
        except:
            log.error(traceback.format_exc())