# -*- coding: utf-8 -*-
#13-12-4

import logging
from hashlib import md5
import server
import settings

log=logging.getLogger(settings.session.get("logger"))

class Session(object):
    def __init__(self,name):
        self._name=name
        self._id=md5(self._name).hexdigest().upper()

    def __getitem__(self, name):
        return server.get_data(self._id,name)

    def __setitem__(self, name, value):
        server.set_data(self._id,name,value)

    def __iter__(self):
        raise StopIteration

    def get(self,name,default=None):
        return self.__getitem__(name) or default

    def lock(self):
        server.lock_acquire()
        log.debug("session lock")

    def unlock(self):
        server.lock_release()
        log.debug("session release")
