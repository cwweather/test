# -*- coding: utf-8 -*-
#13-12-4

import logging
import os
import pickle
import settings

log=logging.getLogger(settings.session.get("logger"))

def load():
    data={}
    for session in os.listdir(settings.session.get("path")):
        with open(settings.session.get("path")+session,"r") as fp:
            data_str=fp.read()
            data[session]=pickle.loads(data_str) if data_str else {}
    log.debug("session load")
    return data

def store(id,data):
    with open(settings.session.get("path")+id,"w") as fp:
        data_str=pickle.dumps(data)
        if data_str:
            fp.write(data_str)
            return
    if os.path.exists(settings.session.get("path")+id):
        os.remove(settings.session.get("path")+id)
    log.debug("session store:id=%s,data=%s",id,data)