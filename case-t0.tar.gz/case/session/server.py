# -*- coding: utf-8 -*-
#13-12-4

import logging
import time
import multiprocessing
import threading
from base.pipe import Pipe
import store
import settings

log=logging.getLogger(settings.session.get("logger"))

pp,sp=Pipe()
lock=multiprocessing.RLock()

class Server(object):
    def __init__(self):
        self._thread=threading.Thread(target=self.run)
        self._data=store.load()
        self._changed=[]
        self._change_time=0
        self._process=multiprocessing.current_process()

        self._thread.setDaemon(True)
        self._thread.start()

    def _get(self,id,name):
        if id not in self._data:
            value=pp.send(None)
        else:
            value=self._data[id].get(name,None)

        self.flush()
        log.debug("session get:id=%s,name=%s,value=%s",id,name,value)
        return value

    def _set(self,id,name,value):
        if id not in self._data:
            self._data[id]={}
        if value is None:
            del self._data[id][name]
        else:
            self._data[id][name]=value

        self._changed.append(id)

        self.flush()
        log.debug("session set:id=%s,name=%s,value=%s",id,name,value)

    def run(self):
        while True:
            method,id,name,value=pp.recv()
            if method=="get":
                try:
                    pp.send(self._get(id,name))
                except:
                    log.error("session send value error")
                    pp.send(None)
            elif method=="set":
                self._set(id,name,value)

    def flush(self):
        if time.time()-self._change_time>=10:
            for id in set(self._changed):
                store.store(id,self._data[id])
        self._change_time=time.time()

    def flush_all(self):
        for id,data in self._data.items():
            store.store(id,data)

    def get(self,id,name):
        with lock:
            if self._process.pid==multiprocessing.current_process().pid:
                value=self._get(id,name)
            else:
                sp.send(("get",id,name,None))
                value=sp.recv()
            return value

    def set(self,id,name,value):
        with lock:
            if self._process.pid==multiprocessing.current_process().pid:
                self._set(id,name,value)
            else:
                sp.send(("set",id,name,value))

_server=None

def open():
    global _server
    if _server is None:
        _server=Server()

def close():
    if _server:
        _server.flush_all()

def get_data(id,name):
    return _server.get(id,name)

def set_data(id,name,value):
    _server.set(id,name,value)

def lock_acquire():
    lock.acquire()

def lock_release():
    lock.release()