# -*- coding: utf-8 -*-
#14-1-10

import sys
from interface import InterfaceNoneError

class StdIO(object):
    def __init__(self,interface):
        self._interface=interface

        self._stdin=sys.stdin
        self._stdout=sys.stdout
        self._stderr=sys.stderr

        sys.stdin=self
        sys.stdout=self
        sys.stderr=self

    def readline(self):
        return self.read()

    def read(self):
        try:
            data=self._interface.read()
        except InterfaceNoneError:
            return None
        return data

    def writeline(self,data):
        self.write(data)


    def write(self,data):
        if data=='\n':return
        try:
            self._interface.write(data+"\n")
        except InterfaceNoneError:
            self._stdout.write(str(data))


