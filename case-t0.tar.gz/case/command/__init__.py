# -*- coding: utf-8 -*-
#14-1-10

import pickle
import settings
from base import vtraceback as traceback
from interface import InterfaceServer,InterfaceClient
import stdio

class CommandExitException(Exception):pass

class Command(object):
    def __init__(self,name,callback,args,kwargs,help):
        self.name=name
        self.callback=callback
        self.args=args
        self.kwargs=kwargs
        self.help=help

    def __call__(self, *args):
        if callable(self.callback):
            args=list(args)+list(self.args)
            self.callback(*args,**self.kwargs)

class CommandList(object):
    def __init__(self):
        self._cmds={}

    def register(self,name=None,callback=None,args=(),kwargs={},help=""):
        if callback is None:
            cmd=CommandList()
        else:
            cmd=Command(name,callback,args,kwargs,help)
        self._cmds[name]=cmd
        return cmd

    def __getitem__(self, name):
        return self._cmds[name]

    def __setitem__(self, key, value):
        self._cmds[key]=value

    def __contains__(self, name):
        return name in self._cmds

    def __str__(self):
        return str(self._cmds)

_cmd_list=CommandList()
_stdio=None

def register(*args,**kwargs):
    return _cmd_list.register(*args,**kwargs)

def loop():
    global _stdio
    if not _stdio:
        _stdio=stdio.StdIO(InterfaceServer(settings.TMP_PATH+"command.sock"))
    if not _stdio._interface.loop():return

    try:
        cmd=pickle.loads(raw_input())
        parse(cmd)
        print (CommandExitException(),0)
    except:
        from logger import log
        log.error("command parse error:%s",traceback.format_exc())

def parse(cmd,cmd_list=None):
    if isinstance(cmd,tuple) or isinstance(cmd,list):
        cmd_list=cmd_list or _cmd_list
        name=cmd[0] if len(cmd)>=1 else None
        if name in cmd_list:
            if isinstance(cmd_list[name],CommandList):
                if not parse(cmd[1:],cmd_list[name]) and None in cmd_list[name]:
                    cmd_list[name][None](*cmd[1:])
            else:
                cmd_list[name](*cmd[1:])
            return True
        return False
    return True
