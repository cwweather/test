# -*- coding: utf-8 -*-
#14-1-10

import stat
import os
import socket
import select

class InterfaceNoneError(Exception):pass

class Interface(object):
    def __init__(self,name):
        self._name=name
        self._socket=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
        self._conn=None

    def read(self):
        if not self._conn:
            raise InterfaceNoneError
        return self._conn.recv(1024*1024)

    def write(self,data):
        if not self._conn:
            raise InterfaceNoneError
        self._conn.send(data)

    def close(self):
        self._conn.close()

class InterfaceServer(Interface):
    def __init__(self,name):
        super(InterfaceServer,self).__init__(name)

        try:
            os.remove(self._name)
        except:
            pass
        self._socket.bind(self._name)
        os.chmod(self._name,0777)
        self._socket.listen(1)

        self._addr=None

    def loop(self):
        self._conn,self._addr=None,None
        try:
            readables,writables,exceptionals  = select.select([self._socket],[],[],0.01)
        except Exception,e:
            if e.args[0]==4:
                return False
            raise e
        if readables:
            self._conn,self._addr=self._socket.accept()
        return bool(self._conn)

class InterfaceClient(Interface):
    def __init__(self,name):
        super(InterfaceClient,self).__init__(name)

        self._socket.connect(self._name)
        self._conn=self._socket