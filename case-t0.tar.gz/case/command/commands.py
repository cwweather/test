# -*- coding: utf-8 -*-
#14-1-10

import types
import json
import processor
import ocean
import scheduler

def format_json(states):
    def _format(data):
        ret={}
        for key,value in data.items():
            if isinstance(value,list):
                value=[_format(v) if isinstance(v,dict) else v for v in value]
            elif isinstance(value,dict):
                value=_format(value)
            elif isinstance(value,int) or isinstance(value,float) or isinstance(value,str) or isinstance(value,unicode):
                value=value
            else:
                value=str(value)
            ret[key]=value
        return ret
    return json.dumps(_format(states))

def processor_state(format=None):
    states=processor.get_state()
    if format=="json":
        print format_json(states)
        return
    print ""
    print 25*'*'+" processor state "+25*'*'
    print "task_queue_count:\t%s" % states["task_queue_count"]
    print "    worker_count:\t%s" % states["worker_count"]
    print "      totle_time:\t%s" % (str(round(states["totle_time"],4))+"s")
    print "     totle_count:\t%s" % states["totle_count"]
    print "        mem_size:\t%s" % (str(int(states["mem_size"]/1024/1024))+"M")
    for st in states["worker_states"]:
        print ""
        print "worker %s #<%s>" % (st["pid"],st["cmdline"])
        print "\t%12s:\t%s" % ("pid",st["pid"])
        print "\t%12s:\t%s" % ("ppid",st["ppid"])
        print "\t%12s:\t%s" % ("cmdline",st["cmdline"])
        print "\t%12s:\t%s" % ("busy",st["busy"])
        print "\t%12s:\t%s" % ("run_time",st["run_time"])
        print "\t%12s:\t%s" % ("sleep_time",st["sleep_time"])
        print "\t%12s:\t%s" % ("totle_time",st["totle_time"])
        print "\t%12s:\t%s" % ("totle_count",st["totle_count"])
        print "\t%12s:\t%s" % ("current_task",st["current_task"])
        print "\t%12s:\t%s" % ("mem_size",st["mem_size"])

def ocean_state(format=None):
    states=ocean.get_state()
    if format=="json":
        print format_json(states)
        return
    print ""
    print 25*'*'+" ocean state "+25*'*'
    print " totle_time:\t%s" % (str(round(states["totle_time"],4))+"s")
    print "totle_count:\t%s" % states["totle_count"]
    print "   mem_size:\t%s" % (str(int(states["mem_size"]/1024/1024))+"M")
    for st in states["space_states"]:
        print ""
        print "space %s #<%s>" % (st["pid"],st["cmdline"])
        print "\t%15s:\t%s" % ("pid",st["pid"])
        print "\t%15s:\t%s" % ("ppid",st["ppid"])
        print "\t%15s:\t%s" % ("cmdline",st["cmdline"])
        print "\t%15s:\t%s" % ("stop",st["stop"])
        print "\t%15s:\t%s" % ("interface_count",st["interface_count"])
        print "\t%15s:\t%s" % ("totle_time",(str(round(st["totle_time"],4))+"s"))
        print "\t%15s:\t%s" % ("totle_count",st["totle_count"])
        print "\t%15s:\t%s" % ("mem_size",(str(int(st["mem_size"]/1024/1024))+"M"))
        for it in st["interface_states"]:
            print ""
            print "\t/**** interface %s ****/" % it["id"]
            print "\t\t%15s:\t%s" % ("pid",it["pid"])
            print "\t\t%15s:\t%s" % ("id",it["id"])
            print "\t\t%15s:\t%s" % ("busy",it["busy"])
            print "\t\t%15s:\t%s" % ("current_request",it["current_request"])
            print "\t\t%15s:\t%s" % ("run_time",it["run_time"])
            print "\t\t%15s:\t%s" % ("sleep_time",it["sleep_time"])
            print "\t\t%15s:\t%s" % ("totle_time",it["totle_time"])
            print "\t\t%15s:\t%s" % ("totle_count",it["totle_count"])

def scheduler_state(format=None):
    states=scheduler.get_state()
    if format=="json":
        print format_json(states)
        return
    print ""
    print 25*'*'+" scheduler state "+25*'*'
    print "         space_count:\t%s" % states["space_count"]
    print "          plan_count:\t%s" % states["plan_count"]
    print  "current_queue_count:\t%s" % states["current_queue_count"]

def state(format=None):
    processor_state(format)
    ocean_state(format)
    scheduler_state(format)
