# -*- coding: utf-8 -*-
#14-1-16

from command import register as register_root_cmd
from commands import state,ocean_state,processor_state,scheduler_state

def register():
    state_cmd=register_root_cmd("state")

    state_cmd.register(callback=state)
    state_cmd.register("processor",processor_state)
    state_cmd.register("ocean",ocean_state)
    state_cmd.register("scheduler",scheduler_state)
