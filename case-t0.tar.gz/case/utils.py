# -*- coding: utf-8 -*-

class EnumNotFind(Exception):pass

class Enum(object):
    def __init__(self,**kwargs):
        self._enums=kwargs

    def __getattr__(self, name):
        try:
            attr=self._enums.get(name)
            if isinstance(attr,list) or isinstance(attr,tuple):
                return attr[0]
            else:
                return attr
        except KeyError:
            raise EnumNotFind("%s not in find" % name)

    def __dir__(self):
        return self._enums.keys()

    def __iter__(self):
        for e in self._enums:
            yield e
        raise StopIteration

    def __getitem__(self, name):
        return self.__getattr__(name)

    def __len__(self):
        return len(self._enums)

    def __add__(self, other):
        self._enums.update(other)

    def __cmp__(self, other):
        return cmp(self._enums,other._enums)

    def __eq__(self, other):
        return self._enums==other._enums

    def __str__(self):
        return self.values()

    def __repr__(self):
        return self._enums.__repr__()

    def values(self):
        list=[]
        for name in self:
            list.append(self[name])
        return list

    def keys(self):
        return list(self)

    def items(self):
        return zip(self.keys(),self.values())





