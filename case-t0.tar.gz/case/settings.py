#!/home/qfpay/python/bin/python
# -*- coding: utf-8 -*-
# 2013年 02月 20日 星期三 16:45:15 CST

import os
import sys
from threading import Lock
class SettingsError(Exception):pass

class Settings(object):
    _self=None
    _module=None
    _inited=False

    def __init__(self):
        Settings._self=self
        Settings._module=sys.modules[__name__]

        self._settings={}
        self._is_loaded=False

        self._lock=Lock()

    def enter_conf(self):
        self._sys_modules=sys.modules.keys()
        if CONF_PATH not in sys.path:
            sys.path.insert(0,CONF_PATH)

    def leave_conf(self):
        if CONF_PATH in sys.path:
            del sys.path[sys.path.index(CONF_PATH)]
        self._sys_modules=set(sys.modules)-set(self._sys_modules)
        for name in self._sys_modules:
            if sys.modules[name] and os.path.dirname(sys.modules[name].__file__)==os.path.abspath(CONF_PATH):
                del sys.modules[name]

    def load_conf(self):
        with self._lock:
            if Settings._inited:
                return
            Settings._inited=True

            self._settings.update(globals())
            self._settings.update(locals())
            self.enter_conf()
            execfile(CONF_PATH+"settings.py",self._settings,self._settings)
            self.leave_conf()

            self._is_loaded=True

    def __getattr__(self,name):
        if not Settings._inited:
            self.load_conf()
        try:
            return self._settings[name]
        except KeyError:
            raise SettingsError("settings is not find %s" % name)

    def __setattr__(self, key, value):
        if not Settings._inited:
            return super(Settings,self).__setattr__(key, value)
        if self._is_loaded:
            raise SettingsError("settings refuse write")
        self._settings[key]=value

sys.modules[__name__]=Settings()

HOME=os.path.abspath(os.path.abspath(os.path.dirname(__file__))+"/../")+"/"
BASE_PATH=os.path.abspath(os.path.dirname(__file__))+"/"
TMP_PATH=HOME+"tmp/"
if "CASE_CONFPATH" in os.environ:
    CONF_PATH=os.environ["CASE_CONFPATH"]
else:
    CONF_PATH=HOME+"conf/"

debug = True
