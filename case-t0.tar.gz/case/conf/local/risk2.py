# -*- coding: utf-8 -*-
#13-12-17

disable=True

model_1_condition_1={
   " argv1":"90",
   " argv2":"90",
    }

model_1_condition_1_3={
   " argv1":"80",
   }

model_1_condition_2={
   " argv1":"1.67",
   " argv2":"2",
   }

model_1_condition_3={
   " argv1":"3",
   }

model_1_condition_4={
   " argv1":"2",
   " argv2":"3",
    }

model_1_condition_5={
   " argv1":"50",
   }

model_1_condition_6_1={
   " argv1":"90",
   " argv2":"90",
   " argv3":"2 ",
   }

model_1_condition_6_2={
   " argv1":"90",
   " argv2":"90",
   " argv3":"1 ",
   }

model_1_condition_6_3={
   " argv1":"80",
   " argv2":"50",
   " argv3":"2 ",
   }

model_1_condition_7={
   " argv1":"5000",
   " argv2":"100 ",
   }

model_1_condition_8={
   " argv1":"50",
   " argv2":"50",
   }

model_1_condition_9={
   " argv1":"80",
   }

model_1_condition_10={
   " argv1":"20",
   }

model_1_condition_12={
   " argv1":"2000",
   }

model_check_1={
   " argv1":"4999",
   " argv2":"1",
   }

