# -*- coding: utf-8 -*-

LOG_PATH = "/home/caiwenwen/case/log/"
LOG_FIEL_NAME = "case.log"

log_mail_server="smtp.exmail.qq.com"
log_mail_auth=("receipt@qfpay.net","qianfang911")
log_mail_from="receipt@qfpay.net"
log_mail_to=("caiwenwen@qfpay.com")
log_mail_subject="case error(no reply)"

config={
    "version":1,
}

config["formatters"]={
    "case":{
        "format":'%(asctime)s %(process)d %(thread)d %(levelname)s %(message)s',
    }
}

config["handlers"]={
    "console":{
        'level': 'DEBUG',
        'class': 'logging.StreamHandler',
        'formatter': 'case',
    },
    "case":{
        'level': 'DEBUG',
        'class': 'logger.TimedRotatingFileHandler',
        'formatter': 'case',
        'filename':LOG_PATH+LOG_FIEL_NAME,
        "when":"MIDNIGHT"
    },
    "error":{
        'level': 'ERROR',
        'class': 'logging.FileHandler',
        'formatter': 'case',
        'filename':LOG_PATH+"error.log",
    },
    "smtp_alert":{
        'level': 'ERROR',
        'class': 'logging.handlers.SMTPHandler',
        'formatter': 'case',
        'mailhost':log_mail_server,
        "fromaddr":log_mail_from,
        "toaddrs":log_mail_to,
        "subject":log_mail_subject,
        "credentials":log_mail_auth,
    },
}

config["loggers"]={
    "":{
        'handlers': ['case','error',],
        'level': 'DEBUG'
    },
    "case":{
        'handlers': ['case','error',],
        'level': 'INFO'
    }
}

config["loggers"][""]["handlers"].append("smtp_alert")
