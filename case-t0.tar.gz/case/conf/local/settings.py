# -*- coding: utf-8 -*-

debug=True

driver={
    "parallel_thread_count":5,
    #"logger":"case",
}

scheduler={
    #"logger":"case",
}

processor={
    "worker_count":4,
}

ocean={
    "interface_count":16,
    #"logger":"case",
}

packages="package"

MAIL_SERVER={
        "name":"smtp.exmail.qq.com",
        "user":"sujian@qfpay.com",
        "passwd":"qfpay41236"
        }
MAIL_ME="sujian@qfpay.com"

#toolserver
TOOL_SERVICE_IP='172.100.101.150'
TOOL_SERVICE_PORT=4400

TYFOON_IP='172.100.101.150'
TYFOON_PORT=9293