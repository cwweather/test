#!/home/qfpay/python/bin/python
# -*- coding: utf-8 -*-
# 2013年 02月 20日 星期三 16:01:06 CST

import os
import sys

os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.UTF8'
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

import pickle
import settings

def start():
    import core
    core.init()
    core.start()
    core.loop()

if __name__ == '__main__':
    if len(sys.argv)>1:
        from command.interface import InterfaceClient
        interface=InterfaceClient(settings.TMP_PATH+"command.sock")
        interface.write(pickle.dumps(sys.argv[1:],pickle.HIGHEST_PROTOCOL))
        while True:
            data=interface.read()
            if not data:continue
            for line in str(data).split("\n")[:-1]:
                if line=="(CommandExitException(), 0)":
                    exit(0)
                print line
        interface.close()
    else:
        start()
