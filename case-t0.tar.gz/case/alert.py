# -*- coding: utf-8 -*-

import datetime
import smtplib
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE,formatdate
import settings
from driver import Driver

SERVER={
        "name":"smtp.exmail.qq.com",
        "user":"receipt@qfpay.net",
        "passwd":"qianfang911"
        }
ME_MAIL="receipt@qfpay.net"
TO_MAILS=[
        #"hechunpeng@qfpay.com",
        #"fengkong@qfpay.com"
        "caiwenwen@qfpay.com"
        ]

CASES=(
    #卡统计
    ('CARD001', u'高危卡'),
    ('CARD002', u'银行风险持卡人'),

    #金额统计
    ('AMT001',  u'40天同卡同户金额超限'),

    #辅助监控
    ('ASST001', u'收据手机号与商户相同'),
    ('ASST002', u'无密信用卡大额交易'),
    ('ASST003', u'大额交易时间异常'),
    ('ASST004', u'测试交易卡大额'),
    ('ASST005',u'前一日top30总刷卡量'),
    ('ASST006',u'前一日top30信用卡总刷卡量'),
    ('ASST007',u'前一日top30用卡数最高商户'),
    ('ASST008',u'前一日月查询数高于总交易数50%的商户'),
    ('ASST009',u'前一日top30借记卡总刷卡量'),

    #地理监控
    ('LCT001',  u'交易经纬度相同'),
    ('LCT002',  u'入网与交易位置偏差大(旧)'),

    #行为模式
    ('BP001',   u'商户同卡直接关联'),
    ('BP002',   u'商户涉嫌盗伪卡测试与交易'),
    ('BP003',   u'签名相似度高'),
    ('BP004',   u'短时间爆发交易'),
    ('BP005',   u'消费者疑似养卡'),

    #风控规则
    ('RISK001', u'商户日交易风险'),
    ('RISK002', u'临调后大额交易'),
    ('RISK003', u'涉嫌借记卡盗刷'),
    ('RISK004', u'疑似伪卡交易'),
    ('RISK005', u'反洗钱(单借记卡30天超限)'),
    ('RISK006', u'反洗钱(单商户月借记卡超限)'),
    ('RISK007', u'移机监控'),
    ('RISK008', u'风控禁止交易'),
    ('RISK009', u'系统主动临调'),

    #功能案件
    ('FUN001',  u'临调'),
    ('FUN002',  u'延迟久积商户提醒'),
    ('FUN003',  u'商户多次套现'),
    ('FUN004',  u'商户多次签字违规'),
    ('FUN005',  u'通调单'),
    ('FUN006',  u'宽调单'),
    ('FUN007',  u'快调单'),
    ('FUN008',  u'海调单'),
    ('FUN009',  u'大额凭证'),
    ('FUN010',  u'延迟超时'),

    #信用卡监控
    ('CRE001',  u'信用卡收款月限'),

    #位置监控
    ('POS001',  u'入网与经营位置偏差大'),
    ('POS002',  u'入网与交易位置偏差大'),

    ('00000',   u'其它'),
)

def get_cases():
    return {id:des for id,des in CASES}

def send_mail(server, fro, to, subject, text):
    msg = MIMEMultipart()
    msg['From'] = fro
    msg['Subject'] = Header(subject,"utf-8")
    msg['To'] = COMMASPACE.join(to)
    msg['Date'] = formatdate(localtime=True)
    content=MIMEText(text.encode("utf-8"),'html')
    content.set_charset("utf-8")
    msg.attach(content)
    smtp = smtplib.SMTP(server['name'])
    smtp.login(server['user'], server['passwd'])
    smtp.sendmail(fro, to, msg.as_string())
    smtp.close()

def get_zero_case():
    db=Driver(settings.db.case)
    sql="select case_types.casetype,count(case_cases.casetype) as cnt from (select casetype from case_cases group by casetype) case_types left join (select * from case_cases where case_cases.jointime>='%s') case_cases on case_types.casetype=case_cases.casetype group by case_types.casetype order by casetype" % (datetime.datetime.today()-datetime.timedelta(days=1)).strftime("%Y-%m-%d 00:00:00")
    return {case["casetype"]:case["cnt"] for case in db.query(sql)}

def format(cases):
    case_des=get_cases()
    text="<table>"
    for k,v in cases.items():
        text+="<tr><td>%s(%s) :</td><td> %s</td></tr>" % (case_des[k],k,v)
    return text+"</table>"

def main():
    cases=get_zero_case()
    email_content=format(cases)
    send_mail(SERVER,ME_MAIL,TO_MAILS,"案件报警：前一日生成案件数为零案件",email_content)

if __name__=="__main__":
    main()
