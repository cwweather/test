import json as simplejson
import urllib
import urllib2
import mimetypes


FENGXIANG_DOMAIN = "http://fx.qfpay.com/"


class Driver(object):
    def __init__(self, config):
        self.config=config
        self.auth_header = {"X-Feng-Xiang-Application-Id": config.get("api_id"),
                            "X-Feng-Xiang-REST-API-Key": config.get("app_key")}
        self.default_header = {"Content-Type": "application/json"}
        self.default_header.update(self.auth_header)

    def create_objects(self, table_name, objs):
        CREATE_OBJECTS_ADDRESS = "1/classes/%s" % table_name
        create_url = "%s%s" % (FENGXIANG_DOMAIN, CREATE_OBJECTS_ADDRESS)
        data = simplejson.dumps(objs)
        request = urllib2.Request(create_url, data, self.default_header)
        response = urllib2.urlopen(request)
        if response.getcode() == 201:
            res_data = response.read()
            return simplejson.loads(res_data)
        else:
            return None

    def update_object(self, table_name, object_id, change):
        UPDATE_OBJECT_ADDRESS = "1/classes/%s/%s" % (table_name, object_id)
        update_url = "%s%s" % (FENGXIANG_DOMAIN, UPDATE_OBJECT_ADDRESS)
        data = simplejson.dumps(change)
        request = urllib2.Request(update_url, data, self.default_header)
        request.get_method = lambda: "PUT"
        response = urllib2.urlopen(request)
        return response.getcode() == 200

    def delete_object(self, table_name, object_id):
        DELETE_OBJECT_ADDRESS = "1/classes/%s/%s" % (table_name, object_id)
        delete_url = "%s%s" % (FENGXIANG_DOMAIN, DELETE_OBJECT_ADDRESS)
        request = urllib2.Request(delete_url, None, self.default_header)
        request.get_method = lambda: "DELETE"
        response = urllib2.urlopen(request)
        return response.getcode() == 200

    def query_objects(self, table_name,
            where=None, limit=None, skip=None, order=None):
        QUERY_OBJECTS_ADDRESS = "1/classes/%s" % table_name
        cond = {}
        if where:
            cond.update({"where": where})
        if limit:
            cond.update({"limit": limit})
        if skip:
            cond.update({"skip": skip})
        if order:
            cond.update({"order": order})
        query_url = "%s%s?%s" % (FENGXIANG_DOMAIN, QUERY_OBJECTS_ADDRESS,
                urllib.urlencode(cond))
        request = urllib2.Request(query_url, None, self.default_header)
        response = urllib2.urlopen(request)
        if response.getcode() == 200:
            res_data = response.read()
            return simplejson.loads(res_data)
        else:
            return None

    def retrieve_object(self, table_name, object_id):
        RETRIEVE_OBJECT_ADDRESS = "1/classes/%s/%s" % (table_name, object_id)
        retrieve_url = "%s%s" % (FENGXIANG_DOMAIN, RETRIEVE_OBJECT_ADDRESS)
        request = urllib2.Request(retrieve_url, None, self.default_header)
        response = urllib2.urlopen(request)
        if response.getcode() == 200:
            res_data = response.read()
            return simplejson.loads(res_data)
        else:
            return None

    def upload_file(self, filename, data):
        if isinstance(filename, unicode):
            filename = filename.encode("utf-8")
        UPLOAD_FILE_ADDRESS = "1/files/"
        upload_url = "%s%s%s" % (FENGXIANG_DOMAIN,
                UPLOAD_FILE_ADDRESS, filename)
        file_type, _ = mimetypes.guess_type(filename)
        content_type = file_type if file_type else "text/plain"
        headers = {"Content-Type": content_type}
        headers.update(self.auth_header)
        request = urllib2.Request(upload_url, data, headers)
        response = urllib2.urlopen(request)
        return simplejson.loads(response.read()) \
                if response.getcode() == 200 else None
