# -*- coding: utf-8 -*-
# 2012年 09月 05日 星期三 13:39:04 CST

import random
import logging
import copy
import MySQLdb
from MySQLdb.converters import conversions,FIELD_TYPE
import sqlite3
try:
    import cx_Oracle
except:
    cx_Oracle=object
from DBUtils.PooledDB import PooledDB
import threading
from utils import Enum
from driver import Config

log=logging.getLogger(Config.get("logger",None))

def lazy_load(master=False):
    def _conn(fun):
        def _execute(self,*args,**kwargs):
            if kwargs.get("master",master):
                pool=self.get_pool()
            else:
                pool=self.select_slaver_pool()
                if not pool:pool=self.get_pool()
            conn=pool.connection()
            ret=fun(self,conn,*args)
            conn.close()
            return ret
        return _execute
    return _conn

class Column(object):
    '''
    数据库中的行。
    '''
    def __init__(self,keys,values):
        self._keys=keys
        self._values=values
        self._dict=dict(zip(self._keys,self._values))

    def __len__(self):
        return len(self._keys)

    def __iter__(self):
        for key in self._keys:
            yield key
        raise StopIteration

    def __getitem__(self, item):
        return self._dict[item]

    def __setitem__(self, key, value):
        self._dict[key]=value
        self._values=self._dict.values()

    def __nonzero__(self):
        return bool(self._values)

    def __contains__(self, item):
        return item in self._keys

    def __cmp__(self, other):
        if isinstance(other,Column):
            return self._dict.__cmp__(other._dict)
        else:
            return self._dict.__cmp__(other)

    def __str__(self):
        return self._dict.__str__()

    def __repr__(self):
        return self.__str__()

    def keys(self):
        return self._keys

    def values(self):
        return self._values

    def items(self):
        return self._dict.items()

    def update(self,other):
        if isinstance(other,dict):
            self._dict.update(other)
        else:
            self._dict.update(other._dict)
        self._keys=self._dict.keys()
        self._values=self._dict.values()

    def get(self,*args,**kwargs):
        return self._dict.get(*args,**kwargs)

class Query(object):
    '''
    查询到的数据集合。
    '''
    def __init__(self,keys,datas):
        self._keys=keys
        self._datas=datas

    def __len__(self):
        return len(self._datas)

    def __iter__(self):
        for data in self._datas:
            yield Column(self._keys,data)
        raise StopIteration

    def __getitem__(self, item):
        if isinstance(item,slice):
            return Query(self._keys,self._datas.__getitem__(item))
        return Column(self._keys,self._datas[item])

    def __nonzero__(self):
        return bool(self._datas)

    def __str__(self):
        s="["
        for data in self._datas:
            s+=str(Column(self._keys,data))+','
        s+="]"
        return s

    def __repr__(self):
        return self.__str__()

    def extend(self,other):
        if isinstance(self._datas,tuple):
            self._datas=list(self._datas)
        if isinstance(other,list):
            self._datas.extend(other)
        else:
            self._datas.extend(other._datas)

class DBDriverNoneTypeError(Exception):pass

DB_TYPE=Enum(
    MYSQL="mysql",
    ORACLE="oracle",
    SQLITE="sqlite"
)

class Driver(object):
    '''
    数据库访问接口，包括mysql、oracle、sqlite。
    '''
    def __new__(cls,config):
        db_type=config.get("db_type")
        if db_type==DB_TYPE.MYSQL:
            cls=MySql
        elif db_type==DB_TYPE.ORACLE:
            cls=Oracle
        elif db_type==DB_TYPE.SQLITE:
            cls=Sqlite
        return object.__new__(cls)

    def __init__(self,config):
        self.lock=threading.Lock()
        self.pool=None
        self.slaver_pools={}
        self.totle_weight=0
        self.config=copy.deepcopy(config)

        self.init_weight()

    def init_weight(self):
        if "slavers" in self.config:
            for slaver in self.config["slavers"]:
                if "weight" not in slaver:
                    if "weight" in self.config:
                        slaver["weight"]=self.config["weight"]
                    else:
                        slaver["weight"]=1.0/float(len(self.config["slavers"]))
                self.totle_weight+=slaver["weight"]

    def select_slaver(self):
        sel=random.random()*self.totle_weight
        sum=0
        for i in range(len(self.config["slavers"])):
            sum+=self.config["slavers"][i]["weight"]
            if sel-sum<=0:return i
        return 0

    def close(self):
        with self.lock:
            self.pool.close()
            for pool in self.slaver_pools:
                pool.close()
            self.pool=None
            self.slaver_pools=[]

    def map_config(self,config):
        c=copy.deepcopy(self.config)
        c.update(config)
        return c

    def get_pool(self):
        if self.pool is None:
            with self.lock:
                if self.pool is None:
                    self.pool=self.init_db(self.map_config(self.config.get("master",{})))
        return self.pool

    def select_slaver_pool(self):
        if "slavers" not in self.config:return None
        slavers=self.config["slavers"]
        if not slavers:return None
        select=0 if len(slavers)==1 else self.select_slaver()
        if select not in self.slaver_pools:
            with self.lock:
                if select not in self.slaver_pools:
                    self.slaver_pools[select]=self.init_db(self.map_config(slavers[select]))
        return self.slaver_pools[select]

    def init_db(self,config):
        raise DBDriverNoneTypeError

    def _execute(self,cursor,sql):
        ret=cursor.execute(sql)
        log.debug("%s:sql=%s,ret=%s",self,sql,ret)
        return cursor

    def _executemany(self,cursor,sql,datas):
        ret=cursor.executemany(sql,datas)
        log.debug("%s:sql=%s,datas=%s,ret=%s",self,sql,datas,ret)
        return cursor

    @lazy_load(True)
    def execute(self,conn,sql):
        cursor = conn.cursor()
        self._execute(cursor,sql)
        ret = cursor.fetchall()
        cursor.close()
        return ret

    @lazy_load(False)
    def query(self,conn, sql):
        '''
        查询。
        '''
        cursor = conn.cursor()
        self._execute(cursor,sql)
        res = cursor.fetchall()
        q=Query([ str(i[0]).lower() for i in cursor.description ],res)
        cursor.close()
        return q

    @lazy_load(True)
    def insert(self,conn, sql, datas=None):
        '''
        插入。
        '''
        cursor = conn.cursor()
        if datas:
            self._executemany(cursor,sql, datas)
        else:
            self._execute(cursor,sql)
        conn.commit()
        cursor.close()

    @lazy_load(True)
    def update(self,conn,sql,datas=None):
        '''
        更新。
        '''
        cursor = conn.cursor()
        if datas:
            self._executemany(cursor,sql, datas)
        else:
            self._execute(cursor,sql)
        conn.commit()
        cursor.close()

    @lazy_load(True)
    def delete(self,conn,sql):
        '''
        删除。
        '''
        cursor = conn.cursor()
        self._execute(cursor,sql)
        conn.commit()
        cursor.close()

class MySql(Driver):
    CONV=copy.copy(conversions)
    CONV.update({
        FIELD_TYPE.DECIMAL:long,
        FIELD_TYPE.NEWDECIMAL:long,
        FIELD_TYPE.DATETIME:str,
        FIELD_TYPE.TIMESTAMP:str,
        FIELD_TYPE.DATE:str,
        FIELD_TYPE.TIME:str,
        })

    def init_db(self,config):
        return PooledDB(
            MySQLdb,
            config.get('pool_size',4),
            config.get('pool_size',4),
            config.get('pool_size',4),
            0,
            True,
            host = config.get('host'),
            user = config.get('user'),
            passwd = config.get('passwd'),
            port = int(config.get('port')),
            db = config.get('db'),
            charset = config.get('charset'),
            conv=self.CONV
        )

class Oracle(Driver):
    def init_db(self,config):
        return PooledDB(
            cx_Oracle,
            config.get('pool_size',4),
            config.get('pool_size',4),
            config.get('pool_size',4),
            0,
            True,
            user = config.get('user'),
            password = config.get('passwd'),
            dsn = config.get('dsn')
        )

    @lazy_load
    def truncate(self, table):
        conn=self.pool.connection()
        cursor = conn.cursor()
        cursor=cursor._execute(cursor,"truncate table %s" % table)
        cursor.close()
        conn.close()

class Sqlite(Driver):
    def init_db(self,config):
        return PooledDB(
            sqlite3,
            config.get('pool_size',4),
            config.get('pool_size',4),
            config.get('pool_size',4),
            0,
            True,
            database=config.get("filename"),
            check_same_thread=False
        )

    def _executemany(self,cursor,sql,datas):
        sql=sql.replace("%s","?")
        ret=cursor.executemany(sql,datas)
        log.debug("%s:sql=%s,datas=%s,ret=%s",self,sql,datas,ret)
        return cursor