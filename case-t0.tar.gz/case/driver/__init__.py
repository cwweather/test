# -*- coding: utf-8 -*-

import threading
import settings

class Driver(object):
    '''
    访问底层数据接口，根据配置文件初始化访问，包括打开数据连接、凤翔初始话配置。
    '''
    driver={}
    lock=threading.Lock()
    def __new__(cls,config):
        return Driver.load(config)

    @staticmethod
    def load(config):
        name=config.get("driver",None)
        if not name:
            return None
        driver_id=str(str(config).__hash__())
        if driver_id not in Driver.driver:
            with Driver.lock:
                if driver_id not in Driver.driver:
                    cls=__import__(name,globals(),locals())
                    driver=cls.Driver(config)
                    setattr(driver,"name",name)
                    setattr(driver,"id",driver_id)
                    setattr(driver,"unload",Driver._unload(driver))
                    Driver.driver[driver_id]=driver
        return Driver.driver[driver_id]

    @staticmethod
    def _unload(self):
        def _():
            if hasattr(self,"close"):
                self.close()
            del Driver.driver[self.id]
        return _

    @staticmethod
    def unload():
        for driver_id in Driver.driver.keys():
            Driver.driver[driver_id].unload()

Config=settings.driver
