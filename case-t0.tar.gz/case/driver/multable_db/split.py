# -*- coding: utf-8 -*-

import datetime
import copy
from sql import Sql,Expression,Field

class TableSplit(object):
    '''
    获取需要查询的表名。
    '''
    def __init__(self,all,all_format=None,format=None):
        self._all=[]
        self._all_format=all_format
        self._format=format
        for a in all:
            self._all.append(self.to_object(a,self._all_format))

    def splits_to_object(self,splits):
        results=[]
        for split in splits:
            split=copy.deepcopy(split)
            split.value=self.to_object(split.value,self._format)
            results.append(split)
        return results

    def get_current_tables(self,splits):
        splits=self.splits_to_object(splits)
        results=self._all
        for split in splits:
            results=sorted(results,cmp=self.cmp_split)
            result=None
            if self.cmp_split(split.value,results[0])==0:
                result=0
            elif self.cmp_split(split.value,results[len(results)-1]) in (0,1):
                result=len(results)-1
            else:
                for i in range(1,len(results)):
                    if self.cmp_split(split.value,results[i-1]) in (0,1) and self.cmp_split(split.value,results[i])==-1:
                        result=i-1
                        break
            if result is not None and split.expression in ">=":
                results=results[result:]
            elif result is not None and split.expression in "<=":
                results=results[:result+1]
        return self.get_splits_table_name(results)

    def get_splits_table_name(self,splits):
        names=[]
        for split in sorted(splits,self.cmp_split):
            names.append(self.to_table(split,self._all_format))
        return names

    def to_object(self,item,format=None):
        return item

    def cmp_split(self,a,b):
        return cmp(a,b)

    def to_table(self,item,format):
        return str(item)

class NumberTableSplit(TableSplit):
    '''
    使用数字分表，获取需要查询的表名。
    '''
    def to_object(self,item,format=None):
        return int(item)

class DateTimeTableSplit(TableSplit):
    '''
    使用日期分表，获取需要查询的表名。
    '''
    def __init__(self,all,all_format=None,format=None):
        if not all_format:all_format="%Y-%m-%d %H:%M:%D"
        if not format:format="%Y-%m-%d %H:%M:%D"
        super(DateTimeTableSplit,self).__init__(all,all_format,format)

    def to_object(self,item,format=None):
        return datetime.datetime.strptime(item,format)

    def to_table(self,item,format):
        return item.strftime(format)

class SplitSql(object):
    '''
    根据查询条件拆解sql。
    '''
    def __init__(self,sql,split_name,split_type,split_all,split_all_format,split_format,split_handle):
        self._sql=Sql(sql) if isinstance(sql,str) else copy.deepcopy(sql)
        self._split_name=split_name
        self._split_type=split_type
        self._split_all=split_all
        self._split_all_format=split_all_format
        self._split_format=split_format
        self._split_handle=split_handle
        self.splits=[]

    def get_split_field(self,wheres=None):
        splits=[]
        if not wheres: wheres=self._sql.get_where()
        for w in wheres:
            if isinstance(w,Expression):
                if w.name==self._split_name:
                    splits.append(w);
            else:
                splits.extend(self.get_split_field(w))
        return splits

    def get_current_tables(self,splits):
        if not self._split_type:
            return []
        if self._split_type=="int" or self._split_type=="float":
            return NumberTableSplit(self._split_all).get_current_tables(splits)
        if self._split_type=="datetime":
            return DateTimeTableSplit(self._split_all,self._split_all_format,self._split_format).get_current_tables(splits)
        return []

    def get_split_all(self):
        if isinstance(self._split_all,str):
            self._split_all=self._split_all.split(",")
        elif callable(self._split_all):
            self._split_all=self._split_all()
        elif not isinstance(self._split_all,list):
            try:
                self._split_all=list(self._split_all)
            except:
                return []

    def get_splits(self):
        if self._split_handle and callable(self._split_handle): return self._split_handle(self._sql.get_where())
        if not isinstance(self._split_all,list) and not isinstance(self._split_all,tuple):
            self.get_split_all()
        if not self._split_all:return []
        return self.get_current_tables(self.get_split_field())

    def add_group_by_name(self):
        for g in self._sql.get_group_by():
            has=False
            for s in self._sql.get_select():
                if s.name==g:
                    has=True
                    break
            if not has:
                self._sql.get_select().append(Field(g))

    def filter_having(self,having):
        for h in having:
            if isinstance(h,Expression):
                if h.expression in (">=",">"):
                    h.close()
            else:
                self.filter_gt(h)

    def fill_table(self,sql,s):
        f=sql.get_from()
        for i in range(0,len(f)):
            if '@1' in f[i]:
                f[i]=f[i].replace('@1',s)

    def fill(self):
        sqls=[]
        for s in self.splits:
            sql=copy.deepcopy(self._sql)
            self.fill_table(sql,s)
            sqls.append(sql)
        return sqls

    def get_sqls(self):
        '''
        返回拆解后的sql。
        '''
        self.splits=self.get_splits()
        if len(self.splits)<=1:
            return self.fill()
        self.filter_having(self._sql.get_having())
        self.add_group_by_name()
        return self.fill()