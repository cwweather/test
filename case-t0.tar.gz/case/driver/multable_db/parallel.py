# -*- coding: utf-8 -*-

import time
import logging
import threading
from base import vtraceback as traceback
from Queue import Queue
from utils import Enum
from driver import Config

log=logging.getLogger(Config.get("logger",None))

class MultableDbParallelQueryError(Exception):
    pass

class ExecutableThread(object):
    def __init__(self):
        self._thread=threading.Thread(target=self.run)
        self._event=threading.Event()
        self._executable=None

        self._thread.setDaemon(True)
        self._thread.start()

    def run(self):
        while True:
            self._event.wait()
            self._executable.run()
            self._executable=None
            self._event.clear()
            ExecutableQueue.release(self)

    def execute(self,executable):
        self._executable=executable
        self._event.set()

class Executable(object):
    '''
    工作线程。
    '''
    STATE=Enum(
        INITED=0,
        STARTING=1,
        STARTED=2,
        RUNNING=3,
        END=4
    )

    def __init__(self,handler,sql,sync=False,**kwargs):
        self._handler=handler
        self._sql=sql
        self._sync=sync
        self.datas=None
        self.state=self.STATE.INITED
        self._error=False
        self._kwargs=kwargs

    def run(self):
        self.state=self.STATE.RUNNING
        try:
            self.datas=self._handler(str(self._sql),**self._kwargs)
            self._error=False
        except Exception:
            log.error(traceback.format_exc())
            self._error=True
        self.state=self.STATE.END

    def start(self):
        self.state=self.STATE.STARTING
        if self._sync:
            thread=ExecutableQueue.acquire()
            self.state=self.STATE.STARTED
            thread.execute(self)
        else:
            self.state=self.STATE.STARTED
            self.run()

    def get(self):
        while self.state!=self.STATE.END:
            time.sleep(0.001)
        if self._error:
            raise MultableDbParallelQueryError
        return self.datas

class ExecutableQueue(object):
    def __init__(self):
        self._queue=Queue()
        self._threads=[]

        self.init()

    def init(self):
        for i in range(Config.get("parallel_thread_count",5)):
            thread=ExecutableThread()
            self._threads.append(thread)
            self._queue.put(thread)

    def acquire(self):
        return self._queue.get()

    def release(self,thread):
        self._queue.put(thread)
ExecutableQueue=ExecutableQueue()

class Parallel(object):
    '''
    使用多线程从多张表中查询数据。
    '''
    def __init__(self,sync=False):
        self._sync=True if str(sync)=="True" else False

    def get(self,q,sql,**kwargs):
        executables=[]
        datas=[]
        sync=self._sync if len(sql)>1 else False
        for s in sql:
            e=Executable(q,s,sync,**kwargs)
            e.start()
            executables.append(e)
        for e in executables:
            datas.append(e.get())
        return datas

    def query(self, q, sql,**kwargs):
        if q and sql:
            return self.get(q,sql,**kwargs)
        return []
