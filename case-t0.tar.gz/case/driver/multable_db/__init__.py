# -*- coding: utf-8 -*-

import copy
import logging
from driver.db import Driver as DBDriver
from sql import Sql
from split import SplitSql
from parallel import Parallel
from compose import Compose
from driver import Config

log=logging.getLogger(Config.get("logger",None))

class Data(object):
    def __init__(self,sql,datas):
        self._sql=sql
        self._datas=datas
        self._compose_datas=None

    def compose(self):
        if self._compose_datas is None:
            self._compose_datas=Compose(self._sql,self._datas).get_result()

    def __iter__(self):
        self.compose()
        for data in self._compose_datas:
            yield data
        raise StopIteration

    def __getitem__(self, item):
        self.compose()
        return self._compose_datas.__getitem__(item)

    def __len__(self):
        self.compose()
        return self._compose_datas.__len__()

    def __nonzero__(self):
        if not self._datas:
            return bool(self._datas)
        else:
            ret=False
            for data in self._datas:
                ret = ret or bool(data)
            return ret

    def extend(self,other):
        self.compose()
        self._compose_datas.extend(other)

class Driver(object):
    '''
    数据库多表查询接口。
    '''
    def __init__(self,config):
        self.config=config
        self._driver=DBDriver(config)

    def update_config(self,**kwargs):
        config=copy.copy(self.config)
        return config.update(kwargs)

    def check_is_split(self,sql):
        sql=sql[sql.find("from")+4:].strip()
        s=''
        for i in range(0,len(sql)):
            if sql[i]==' ':continue
            if i>0 and len(s)>0 and s[-1:]!=',' and sql[i-1]==' ' and sql[i]!=',':break
            s+=sql[i]
        return '@1' in s

    def query(self, sql_str, is_split=True,**kwargs):
        if not is_split:
            return self._driver.query(sql_str,**kwargs)
        if not self.check_is_split(sql_str):
            return self._driver.query(str(sql_str),**kwargs)

        sql=Sql(sql_str)
        config=self.update_config(**kwargs) if kwargs else self.config
        split=SplitSql(sql,config.get("split_name"),config.get("split_type"),config.get("split_all"),config.get("split_all_format"),config.get("split_format"),config.get("split_handle"))
        datas=Parallel(config.get("sync")).query(self._driver.query,split.get_sqls(),**kwargs)
        datas=Data(sql,datas)
        log.debug("multable db result:sql=%s",sql_str)
        return datas

    def execute(self,*args,**kwargs):
        return self._driver.execute(*args,**kwargs)

    def insert(self,*args,**kwargs):
        return self._driver.insert(*args,**kwargs)

    def update(self,*args,**kwargs):
        return self._driver.update(*args,**kwargs)

    def delete(self,*args,**kwargs):
        return self._driver.delete(*args,**kwargs)