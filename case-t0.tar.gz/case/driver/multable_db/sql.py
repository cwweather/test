# -*- coding: utf-8 -*-

import re

class SqlItem(object):
    def __init__(self,sql):
        self._sql=sql
        self._state=True

    def open(self):
        self._state=True

    def close(self):
        self._state=False

    def state(self):
        return self._state

    def __nonzero__(self):
        return bool(self._sql)

class Field(SqlItem):
    '''
    sql中select中的字段。
    '''
    def __init__(self,sql):
        super(Field,self).__init__(sql)
        self.name=""
        self.ao=""
        self.has_as=""
        self.key=""

        self.parse()

    def parse(self):
        if ' ' in self._sql or self._sql.endswith(")"):
            index=self._sql.rfind(' ') if not self._sql.endswith(")") else len(self._sql)
            self.name=self._sql[:index].strip()
            self.key=self._sql[index+1:]
            if self.name.endswith(" as"):
                self.has_as='as'
                self.name=self.name[:-3]
            if self.name.endswith(")"):
                self.ao=self.name[:self.name.find('(')].strip()
            else:
                self.name=self._sql
        else:
            self.name=self._sql

    def __str__(self):
        if not self._state:return ""
        sql_str=self.name
        if self.key:
            sql_str+=" as "+self.key if self.has_as else " "+self.name
        return sql_str

class Expression(SqlItem):
    '''
    sql中一个查询条件字段。
    '''
    EXPRESSION=("!=",">=","<=","=",">","<","is","is not","like","in")
    def __init__(self,sql):
        super(Expression,self).__init__(sql)
        self.and_or=""
        self.name=""
        self.expression=""
        self.value_type=""
        self.value=""

        self.parse()

    def parse(self):
        if self._sql.startswith("and"):
            self.and_or="and"
        elif self._sql.startswith("or"):
            self.and_or="or"
        sql=self._sql[len(self.and_or):].strip()
        for e in self.EXPRESSION:
            if e in sql:
                sqls=sql.split(e)
                self.name=sqls[0].strip()
                self.expression=e.strip()
                self.value=sqls[1].strip()
                break
        if self.value=='null':
            self.value_type='NULL'
        elif self.value[0]=="'" or self.value[0]=='"':
            self.value_type="string"
        else:
            self.value_type="number"

    def __str__(self):
        if not self._state:return ""
        sql_str=""
        if self.and_or:
            sql_str+=self.and_or+" "
        sql_str+=self.name+" "+self.expression+" "+self.value
        return sql_str

class ExpressionGroup(SqlItem):
    '''
    sql中以括号包裹的一组查询条件字段。
    '''
    def __init__(self,sql):
        super(ExpressionGroup,self).__init__(sql)
        self.and_or=""
        self.expression_list=[]

        self.parse()

    def split(self,sql):
        result=[]
        bracket=False
        and_or=[0]
        for i in range(0,len(sql)):
            if sql[i]=="(":
                bracket=True
            elif sql[i]==")":
                bracket=False
            if not bracket and sql[i-4:i+1]==' and ':
                result.append(sql[and_or.pop():i-3].strip())
                and_or.append(i-3)
            elif not bracket and sql[i-3:i+1]==' or ':
                result.append(sql[and_or.pop():i-2].strip())
                and_or.append(i-2)
        if and_or and sql:
            result.append(sql[and_or.pop():].strip())
        if not result and sql:
            result.append(sql)
        return result


    def parse(self):
        if self._sql.startswith("and") or self._sql.startswith("or"):
            self.and_or="and" if self._sql.startswith("and") else "or"
            sql=self._sql[self._sql.find("(")+1:self._sql.rfind(")")]
            expressions=self.split(sql)
        else:
            expressions=self.split(self._sql)
        for expression in expressions:
            if (expression.startswith("(") or expression.startswith("and (") or expression.startswith("and(") or expression.startswith("or (") or expression.startswith("or(")) and expression.endswith(")") and "in(" not in expression and "in (" not in expression:
                self.expression_list.append(ExpressionGroup(expression))
            else:
                self.expression_list.append(Expression(expression))

    def __str__(self):
        if not self._state:return ""
        sql_str=self.and_or+" (" if self.and_or else ""
        for expression in self.expression_list:
            sql_str+=str(expression)+" "
        return sql_str+")" if self.and_or else sql_str

    def __getitem__(self, item):
        if item>=len(self.expression_list):
            raise StopIteration
        return self.expression_list[item]

    def __nonzero__(self):
        return bool(self.expression_list)

class Order(SqlItem):
    '''
    sql中order by字段。
    '''
    def __init__(self,sql):
        super(Order,self).__init__(sql)
        self.name=""
        self.desc=False

        self.parse()

    def parse(self):
        if " " in self._sql:
            o=self._sql.split(" ")
            self.name=o[0].strip()
            if o[1].strip()=="desc":
                self.desc=True
        else:
            self.name=self._sql

    def __str__(self):
        if not self._state:return ""
        return self.name+" desc" if self.desc else self.name

class Limit(SqlItem):
    '''
    sql中limit字段。
    '''
    def __init__(self,sql):
        super(Limit,self).__init__(sql)

        self.count=""
        self.start=""

        self.parse()

    def parse(self):
        if "," in self._sql:
            splits=self._sql.split(",")
            self.count=splits[0].strip()
            self.start=splits[1].strip()
        else:
            self.count=self._sql.strip()

    def __str__(self):
        if self.start:
            return self.count+","+self.start
        else:
            return self.count

class Sql(object):
    '''
    解析查询slq。
    '''
    SQL_SEQ=(", ",", "," ",", "," ",", "," ")
    SQL_WORD=("select","from","where","group by","having","order by","limit")
    def __init__(self,sql):
        self._sql_str=re.compile(r"\s+").sub(" ",str(sql).lower())
        self._sql={}

        self.parse()

    def parse(self):
        self._sql=self.split(self.SQL_WORD)
        for word,sql in self._sql.items():
            self._sql[word]=getattr(self,"parse_"+word.replace(" ","_"))(sql)

    def split(self,sep=list()):
        result={s:"" for s in sep}
        word_index={}
        for s in sep:
            index=self._sql_str.find(s)
            if index>=0:
                word_index[index]=s

        keys=sorted(word_index.keys())
        for i in range(0,len(word_index)):
            if i+1==len(word_index):
                result[word_index[keys[i]]]=self._sql_str[keys[i]+len(word_index[keys[i]]):].strip()
            else:
                result[word_index[keys[i]]]=self._sql_str[keys[i]+len(word_index[keys[i]]):keys[i+1]].strip()
        return result

    def parse_select(self,sql):
        return [Field(s.strip()) for s in sql.split(",") if s.strip()]

    def parse_from(self,sql):
        return [sql.strip()]

    def parse_where(self,sql):
        return ExpressionGroup(sql)

    def parse_group_by(self,sql):
        if not sql:return []
        return [g.strip() for g in sql.split(",") if g.strip()]

    def parse_having(self,sql):
        return ExpressionGroup(sql)

    def parse_order_by(self,sql):
        if not sql:return []
        return [Order(o.strip()) for o in sql.split(',') if o.strip()]

    def parse_limit(self,sql):
        if not sql:return ''
        return Limit(sql)

    def get_select(self):
        return self._sql["select"]

    def get_from(self):
        return self._sql["from"]

    def get_where(self):
        return self._sql["where"]

    def get_group_by(self):
        return self._sql["group by"]

    def get_having(self):
        return self._sql["having"]

    def get_order_by(self):
        return self._sql["order by"]

    def get_limit(self):
        return self._sql["limit"]

    def get_sql(self,sql,seq=""):
        sql_str=""
        for s in sql:
            if isinstance(s,list):
                sql_str+=self.get_sql(s,seq)
            else:
                sql_str+=str(s)
            sql_str+=seq
        return sql_str[:-len(seq)].strip()

    def __str__(self):
        sql_str=""
        for i in range(0,len(self.SQL_WORD)):
            w=self.SQL_WORD[i]
            s=self._sql[self.SQL_WORD[i]]
            if isinstance(s,list):
                s_str=self.get_sql(s,self.SQL_SEQ[i])
            else:
                s_str=str(s).strip()
            if s_str:
                sql_str+=w+' '+s_str+" "
        return sql_str