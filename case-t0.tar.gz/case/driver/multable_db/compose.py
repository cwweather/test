# -*- coding: utf-8 -*-

import copy

class Compose(object):
    '''
    从多表查询到数据后进行组合处理，group by、having、order by、limit。
    '''
    def __init__(self,sql,datas):
        self._sql=sql
        self._datas=datas

    def list_datas(self):
        datas=copy.deepcopy(self._datas[0])
        for d in self._datas[1:]:
            datas.extend(d)
        self._datas=datas

    def get_field(self,name):
        for f in self._sql.get_select():
            if f.name==name:
                return f
        return None

    def get_aos(self):
        return [f.key or f.name for f in self._sql.get_select() if f.ao]

    def add_data(self,aos,datas):
        for i in range(0,len(datas)):
            data={}
            for d in datas[i]:
                for k,v in d.items():
                    if k not in data:
                        data[k]=v
                        continue
                    data[k]=data[k]+v if k in aos else v
            datas[i]=data
        return datas

    def group_by(self):
        aos=self.get_aos()
        groups=self._sql.get_group_by() if self._sql.get_group_by() else [] if aos else [f.key or f.name for f in self._sql.get_select() if not f.ao]
        datas={}
        for data in self._datas:
            key="".join([str(data[g]) for g in groups])
            if key not in datas:
                datas[key]=[]
            datas[key].append(data)
        self._datas=self.add_data(aos,datas.values())

    def get_having_gt(self):
        return [h for h in self._sql.get_having() if h.expression in (">=",">")]

    def filter_having(self,data):
        hgs=self.get_having_gt()
        for hg in hgs:
            if hg.name not in data:continue
            value=float(hg.value) if hg.value_type=="number" else hg.value
            if hg.expression==">":
                if data[hg.name]<=value:
                    return False
            elif hg.expression=='>=':
                if data[hg.name]<value:
                    return False
        return True

    def having(self):
        if not self.get_having_gt():return
        datas=[]
        for data in self._datas:
            if self.filter_having(data):
                datas.append(data)
        self._datas=datas

    def order_cmp(self,orders,count):
        def _oc(o1,o2):
            def _cmp(i,orders,count):
                order=orders[i]
                c=cmp(o1[order.name],o2[order.name])
                if c==0 and i<(count-1):c=_cmp(i+1,orders,count)
                if order.desc:c=-c
                return c
            return _cmp(0,orders,count)
        return _oc

    def ordering(self):
        orders=self._sql.get_order_by()
        if not orders:return
        count=len(orders)
        self._datas=sorted(self._datas,self.order_cmp(orders,count))

    def limit(self):
        limit=self._sql.get_limit()
        if not limit:return
        if limit.start:
            self._datas=self._datas[int(limit.start):int(limit.count)]
        else:
            self._datas=self._datas[:int(limit.count)]

    def get_result(self):
        if len(self._datas)<=1:
            self._datas=self._datas[0]
            return self._datas
        self.list_datas()
        self.group_by()
        self.having()
        self.ordering()
        self.limit()
        return self._datas
