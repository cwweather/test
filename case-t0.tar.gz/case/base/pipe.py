# -*- coding: utf-8 -*-
#13-12-12
import pickle
import cPickle
import multiprocessing

class Connection(object):
    def __init__(self,conn):
        self._conn=conn

    def send(self,obj):
        self._conn.send_bytes(cPickle.dumps(obj,cPickle.HIGHEST_PROTOCOL))

    def recv(self):
        data=self._conn.recv_bytes()
        try:
            result = cPickle.loads(data)
            return result
        except:
            return pickle.loads(data)

    def __getattr__(self, item):
        return self._conn.__getattr__(item)

def Pipe(*args,**kwargs):
    p1,p2=multiprocessing.Pipe(*args,**kwargs)
    return Connection(p1),Connection(p2)
