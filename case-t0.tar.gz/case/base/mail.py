# -*- coding: utf-8 -*-
#14-2-24

import email
import smtplib
from email.mime.text import MIMEText
from email.utils import COMMASPACE
from logger import log

def send_mail(server_name, me, to, subject, text='', html='', server_user=None, server_passwd=None):
    subject=subject.encode("utf8") if isinstance(subject,unicode) else subject
    text = text.encode("utf8") if isinstance(text, unicode) else text

    msg = MIMEText(text)
    msg['From'] = me
    msg['Subject'] = subject
    msg['To'] = to

    smtp = smtplib.SMTP_SSL(server_name, 465)
    if server_user and server_passwd:
        smtp.login(server_user, server_passwd)
    smtp.sendmail(me, to, msg.as_string())
    log.info("send mail:server_name=%s,From=%s,To=%s,Subject=%s,content=%s %s",server_name,me,to,subject,text,html)
    smtp.close()