# -*- coding: utf-8 -*-
#13-12-27

class StraightLineVerticalException(Exception):pass
class StraightLineHorizontalException(Exception):pass

def get_slope(p1,p2):
    if p1[0]==p2[0]:
        raise StraightLineVerticalException
    if p1[1]==p2[1]:
        raise  StraightLineHorizontalException
    return float(p2[1]-p1[1])/float(p2[0]-p1[0])

def get_straight_line(p1,p2):
    k=get_slope(p1,p2)
    return k,p1[1]-k*p1[0]

def get_intersect(y,p1,p2):
    k,b=get_straight_line(p1,p2)
    return ((y-b)/k,y)

def check_in_line(p,p1,p2):
    if p2[0]<p1[0]:
        p1,p2=p2,p1
    if p2[1]<p1[1]:
        return p[0]>p1[0] and p[0]<=p2[0] and p[1]<p1[1] and p[1]>=p2[1]
    else:
        return p[0]>p1[0] and p[0]<=p2[0] and p[1]>p1[1] and p[1]<=p2[1]

def check_intersect(p,p1,p2):
    try:
        intersect=get_intersect(p[1],p1,p2)
    except StraightLineVerticalException:
        return p[0]<=p1[0] and p[1]>p1[1] and p[1]<=p2[1]
    except StraightLineHorizontalException:
        return False
    if check_in_line(intersect,p1,p2):
        return intersect[0]>=p[0]
    return False

def check_point_in_polygon(point,polygon):
    point=(float(point[0]),float(point[1]))
    intersect=0
    for i in xrange(len(polygon)):
        if check_intersect(point,polygon[i],polygon[i+1 if i+1<len(polygon) else 0]):
            intersect+=1
    return intersect%2!=0

def test():
    polygon=[[0,0],[5,5],[10,5],[10,15],[0,10]]
    print check_point_in_polygon((3,5),polygon)
    print check_point_in_polygon((3,6),polygon)

    polygon=[[22.700,111.11],[22.576,111.31],[22.436,111.43],[22.551,111.59],[22.487,111.67],[22.279,111.46],[22.098,111.32],[21.851,111.41],[21.525,111.44],[21.420,111.28],[21.252,111.05],[21.428,111.01],[21.650,111.77],[21.486,110.63],[21.719,110.38],[22.185,110.36],[22.154,110.62],[22.299,110.78],[22.573,110.77]]
    print check_point_in_polygon((22.073,110.93),polygon)
    print check_point_in_polygon((22.416,110.53),polygon)
    print check_point_in_polygon((23.181,110.32),polygon)
    print check_point_in_polygon((22.750855,109.269161),polygon)

    polygon=[[111.11, 22.700],[111.31, 22.576],[111.43, 22.436],[111.59, 22.551],[111.67, 22.487],[111.46, 22.279],[111.32, 22.098],[111.41, 21.851],[111.44, 21.525],[111.28, 21.420],[111.05, 21.252],[111.01, 21.428],[111.77, 21.650],[110.63, 21.486],[110.38, 21.719],[110.36, 22.185],[110.62, 22.154],[110.78, 22.299],[110.77, 22.573]]
    print check_point_in_polygon((110.93,22.073),polygon)
    print check_point_in_polygon((110.53,22.416),polygon)
    print check_point_in_polygon((110.32,23.181),polygon)
    print check_point_in_polygon((109.269161,22.750855),polygon)

if __name__=="__main__":
    test()

