# -*- coding: utf-8 -*-
#13-11-28

from utils import Enum
import types
from thrift.transport import TSocket,TTransport
from thrift.protocol import TBinaryProtocol
from toolserver import Tool
import settings
from logger import log

APP_NAME=Enum(
    APPTYPE_QPOS=0,  # QPOS
    APPTYPE_QYB=1,  # 签约宝
    APPTYPE_QMM=2  # 钱喵喵
)

APP_PLATFORM=Enum(
    PLATFORM_IOS=0, #'ios'
    PLATFORM_ANDROID=1 #'android'
)


SEND_MODE = Enum(
    SEND_MODE_ALL=0,
    SEND_MODE_GROUP=1,
    SEND_MODE_MOBILE=2,
    SEND_MODE_USERID=3
)

def push_msg(to, content, apptypes=APP_NAME.APPTYPE_QPOS, platforms=APP_PLATFORM.values(), mode=SEND_MODE.SEND_MODE_USERID):
    if mode==SEND_MODE.SEND_MODE_USERID:
        to=[str(user) for user in to]
    if type(content) == types.UnicodeType:
        content = content.encode('utf-8')

    if not isinstance(apptypes,list) and not isinstance(apptypes,tuple):
        apptypes=(apptypes,)

    if not isinstance(platforms,list) and not isinstance(platforms,tuple):
        platforms=(platforms,)

    if settings.debug:
        result=None
    else:
        transport = TSocket.TSocket(settings.TOOL_SERVICE_IP,settings.TOOL_SERVICE_PORT)
        TTransport.TBufferedTransport(transport)
        protocol = TBinaryProtocol.TBinaryProtocol(transport)

        client = Tool.Client(protocol)
        transport.open()
        result = client.pushmsg(apptypes, platforms, mode, content, to)
        transport.close()
    log.info('push msg to:%s,content:%s:,result:%s',to,content.decode("utf8"),result)
    return result
