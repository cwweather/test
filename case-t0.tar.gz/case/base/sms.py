# -*- coding: utf-8 -*-

import types
from thrift.transport import TSocket,TTransport
from thrift.protocol import TBinaryProtocol
from toolserver import Tool
import settings
from logger import log

def send_sms(to, content):
    '''
    使用toolserver发送短信。
    '''
    content=content.encode("utf8") if isinstance(content,unicode) else content

    result=None
    if not settings.debug:
        transport = TSocket.TSocket(settings.TOOL_SERVICE_IP,settings.TOOL_SERVICE_PORT)
        TTransport.TBufferedTransport(transport)
        protocol = TBinaryProtocol.TBinaryProtocol(transport)

        client = Tool.Client(protocol)
        transport.open()
        result = client.sendsms2(to,content,"","case","case")
        transport.close()
    log.info('send sms to:%s,content:%s:,result:%s',to,content,result)
    return result
