# -*- coding: utf-8 -*-

import datetime

def get_trade_table_names():
    now=datetime.datetime.now()
    return ["%04d%02d" % (y,m) for y in range(now.year-1,now.year+1) for m in range(1,13 if y!=now.year else now.month+1)]
