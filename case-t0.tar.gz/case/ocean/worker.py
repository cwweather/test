import threading

class Worker(threading.Thread):
    def __init__(self,interface):
        super(Worker,self).__init__()
        self.state=None
        self._stop=False
        self._interface=interface

        self.setDaemon(True)

    def run(self):
        while not self._stop:
            self._interface.loop()

    def stop(self):
        self._stop=True
        self._interface.nop()
        self.join()

    def get_interface(self):
        return self._interface
