# -*- coding: utf-8 -*-
#14-2-25

from interface import InterfaceManager
from request import Request

class BusyInterfaceError(Exception):pass

class ProtocolHandler(object):
    def handle(self,name,*args,**kwargs):
        return getattr(self,name)(*args,**kwargs)

class Protocol(object):
    Handler=ProtocolHandler
    Request=Request

    def __init__(self):
        self._info=InterfaceManager.register(self)
        self._handler=self.get_handler()

    def get_handler(self):
        return self.Handler()

    def get_request(self,*args,**kwargs):
        return self.Request(*args,**kwargs)

    def request(self,*args,**kwargs):
        request=self.get_request(self._handler.handle,*args,**kwargs)
        interface=self._info.get_interface(request.__hash__())
        return interface.request(request)

    def lock(self):
        self._info.lock()

    def unlock(self):
        self._info.unlock()

    def __del__(self):
        self._info.destory()
