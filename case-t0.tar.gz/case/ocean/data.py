# -*- coding: utf-8 -*-
#13-12-6

from protocol import Protocol,ProtocolHandler
from request import Request

class DataRequest(Request):
    pass

class DataHandler(ProtocolHandler):
    pass

class Data(Protocol):
    Handler = DataHandler
    Request = DataRequest

class SyncDataHandler(ProtocolHandler):
    pass

class SyncData(Protocol):
    Handler = SyncDataHandler
    Request = DataRequest

    def get_request(self,*args,**kwargs):
        request=self.Request(*args,**kwargs)
        request.sync=True
        return request

    def request(self,*args,**kwargs):
        data=super(SyncData,self).request(*args,**kwargs)
        data.protocol=self
        return data

