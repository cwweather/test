# -*- coding: utf-8 -*-
#14-1-13

import psutil
import multiprocessing
from queue import InterfaceQueue,WorkerQueue
from worker import Worker
from interface import Interface
from option import Option
import config

class Space(object):
    _current_space=None

    def __init__(self):
        self._interface_queue=InterfaceQueue()
        self._worker_queue=WorkerQueue()
        self._process=None
        self._stop=multiprocessing.Event()
        self._option=Option(self)

    def id(self):
        return self._process.pid

    def init(self):
        self.init_interface()

    def init_interface(self):
        for i in range(config.get("interface_count",15)):
            interface=Interface()
            self._interface_queue.add(interface)

    def load(self):
        self._process=multiprocessing.Process(target=self.start)

    def open(self):
        self._process.start()

    def close(self):
        self._stop.set()
        self._process.join(config.get("stop_time_out",15))
        if self._process.is_alive():
            self._process.terminate()

    def loop(self):
        self._stop.wait()

        from cache import CacheManager
        if CacheManager.obj:
            CacheManager.obj.save_all()

    def start(self):
        Space._current_space=self

        for interface in self._interface_queue:
            worker=Worker(interface)
            self._worker_queue.add(worker)
            worker.start()

        self._option.start_server()
        self.loop()

    def get_interfaces(self):
        return self._interface_queue

    def request(self,request):
        interface=self._interface_queue.acquire()
        result=interface.request(request)
        self._interface_queue.release(interface)
        return result

    @staticmethod
    def current_space():
        return Space._current_space

    def option(self):
        return self._option

    def state(self):
        states=[]
        totle_time,totle_count=0,0
        for interface in self._interface_queue:
            state=interface.state()
            totle_time+=state["totle_time"]
            totle_count+=state["totle_count"]
            states.append(state)

        ps=psutil.Process(self._process.pid)
        return {
            "pid":ps.pid,
            "ppid":ps.ppid,
            "cmdline":ps.cmdline,
            "stop":self._stop.is_set(),
            "interface_count":self._interface_queue.count(),
            "totle_time":totle_time,
            "totle_count":totle_count,
            "mem_size":ps.get_memory_info()[0],
            "interface_states":states,
        }