import types

class Request(object):
    def __init__(self,callback,*args,**kwargs):
        if type(callback) == types.MethodType:
            self.instance=callback.im_self
            self.callback=callback.__name__
        else:
            self.callback=callback
        self.args=args
        self.kwargs=kwargs
        self.sync=False

    def run(self):
        if callable(self.callback):
            return self.callback(*self.args,**self.kwargs)
        else:
            return getattr(self.instance,self.callback)(*self.args,**self.kwargs)

    def __str__(self):
        if callable(self.callback):
            return "callback=%s,args=%s,kwargs=%s" % (self.callback,self.args,self.kwargs)
        else:
            return "callback=%s.%s,args=%s,kwargs=%s" % (self.instance,self.callback,self.args,self.kwargs)

    def __hash__(self):
        return str(self).__hash__()
