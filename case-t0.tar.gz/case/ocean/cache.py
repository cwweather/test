# -*- coding: utf-8 -*-
#13-12-6

import threading
from protocol import ProtocolHandler,Protocol
from request import Request

class CacheRequest(Request):
    def __init__(self,key,*args,**kwargs):
        super(CacheRequest,self).__init__(*args,**kwargs)

        self._key=key

    def __hash__(self):
        return str(self._key).__hash__()

class CacheManager(object):
    obj=None
    def __init__(self):
        self._datas={}

    def _get(self,id):
        return self._datas.get(str(id),None)

    def _set(self,id,data):
        self._datas[str(id)]=data

    def _remove(self,id):
        if str(id) in self._datas:
            del self._datas[str(id)]

    def save_all(self):
        for key,cache in self._datas.iteritems():
            cache.save()

    @staticmethod
    def get_data(id):
        if CacheManager.obj is None:
            CacheManager.obj=CacheManager()
        return CacheManager.obj._get(id)

    @staticmethod
    def set_data(id,data):
        if CacheManager.obj is None:
            CacheManager.obj=CacheManager()
        CacheManager.obj._set(id,data)

    @staticmethod
    def remove(id):
        if CacheManager.obj is None:
            CacheManager.obj=CacheManager()
        CacheManager.obj._remove(id)

class CacheHandler(ProtocolHandler):
    def handle(self,name,*args,**kwargs):
        try:
            return getattr(self,name)(*args,**kwargs)
        except AttributeError:
            return self.proxy(name,*args,**kwargs)

    def init(self,id,cd,*args,**kwargs):
        if not cd:
            return bool(CacheManager.get_data(id))
        cd=cd(*args,**kwargs)
        CacheManager.set_data(id,cd)
        cd.init()
        return True

    def destroy(self,id):
        cd=CacheManager.get_data(id)
        if cd and cd.get() is None:
            CacheManager.remove(id)

    def proxy(self, name, id,*args,**kwargs):
        cd=CacheManager.get_data(id)
        if cd:
            f=getattr(cd,name)
            cd.lock()
            try:
                ret=f(*args,**kwargs)
            finally:
                cd.unlock()
            return ret
        return None

class CacheData(object):
    def __init__(self):
        self._data=None

    def init(self):
        self._lock=threading.RLock()

    def load(self):
        self._data=[]

    def save(self):
        pass

    def get(self):
        return self._data

    def set(self,data):
        self._data=data

    def lock(self):
        self._lock.acquire()

    def unlock(self):
        self._lock.release()

class Cache(Protocol):
    Handler = CacheHandler
    Request = CacheRequest
    Data=CacheData

    def __init__(self):
        super(Cache,self).__init__()
        self._id=self.get_id()

        self.init()

    def get_cache_data(self):
        return self.Data,(),{}

    def get_id(self):
        return "%s.%s" % (self.__class__.__module__,self.__class__.__name__)

    def get_request(self,handle,name,*args,**kwargs):
        return self.Request(self._id,handle,name,self._id,*args,**kwargs)

    def init(self):
        if not self.request("init",None):
            cd,args,kwargs=self.get_cache_data()
            return self.request("init",cd,*args,**kwargs)

    def load(self):
        self.request("load")

    def save(self):
        self.request("save")

    def get(self):
        return self.request("get")

    def set(self,data):
        self.request("set",data)

    def lock(self):
        self._info.lock()
        self.request("lock")

    def unlock(self):
        self.request("unlock")
        self._info.unlock()

    def __del__(self):
        self.request("destroy")
        super(Cache,self).__del__()

