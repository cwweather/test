import random
import time

class InterfaceQueue(object):
    def __init__(self):
        self._interfaces=[]

    def add(self,interface):
        self._interfaces.append(interface)

    def release(self,interface):
        interface.set_active(False)

    def acquire(self,info):
        count=self.count()
        try_count=0
        while True:
            interface=random.choice(self._interfaces)
            if interface.set_active():
                return interface
            if try_count>count*4:
                time.sleep(0.002)
                try_count=-1
            try_count+=1

    def __iter__(self):
        for interface in self._interfaces:
            yield interface
        raise StopIteration

    def count(self):
        return len(self._interfaces)

class WorkerQueue(object):
    def __init__(self):
        self._workers=[]

    def add(self,worker):
        self._workers.append(worker)

    def remove(self,worker):
        self._workers.remove(worker)

class SpaceQueue(object):
    def __init__(self):
        self._spaces=[]

    def add(self,space):
        self._spaces.append(space)

    def remove(self,space):
        self._spaces.remove(space)

    def __iter__(self):
        for space in self._spaces:
            yield space
        raise StopIteration

    def __getitem__(self, index):
        return self._spaces[index]

    def count(self):
        return len(self._spaces)

    def select(self,hash):
        return self._spaces[hash % len(self._spaces)]