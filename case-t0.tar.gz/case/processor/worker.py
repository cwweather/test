import time
import multiprocessing
import psutil
from config import log
from option import Option

class Worker(multiprocessing.Process):
    _current_worker=None

    def __init__(self,processor,queue):
        super(Worker,self).__init__()
        self._processor=processor
        self._queue=queue
        self._broadcast=multiprocessing.Queue()
        self._stop=multiprocessing.Event()
        self._option=Option(self)
        self._busy=False
        self._run_time=0
        self._sleep_time=time.time()
        self._totle_time=0
        self._totle_count=0
        self._current_task=None

    def run(self):
        Worker._current_task=self
        self._option.start_server()

        while not self._stop.is_set():
            if not self._broadcast.empty():
                self._current_task=self._broadcast.get(0.001)
            else:
                self._current_task=self._queue.get(0.1)
            if self._current_task and not self._current_task.done:
                self._busy=True
                self._run_time=time.time()

                try:
                    self._current_task.run()
                    log.debug("processor task:%s,time=%.3fms",self._current_task,(time.time()-self._run_time)*1000)
                except:
                    from base import vtraceback as traceback
                    log.error("processor task error:%s\n%s",self._current_task,traceback.format_exc())

                self._busy=False
                self._sleep_time=time.time()
                self._totle_time+=self._sleep_time-self._run_time
                self._totle_count+=1

    def stop(self):
        self._stop.set()

    def terminate(self):
        log.error("processor worker terminate error:worker=%s,state=%s",self,self.state())
        return super(Worker,self).terminate()

    def broadcast(self,task):
        self._broadcast.put(task)

    def state(self):
        ps=psutil.Process(self.pid)
        return {
            "pid":ps.pid,
            "ppid":ps.ppid,
            "cmdline":ps.cmdline,
            "stop":self._stop.is_set(),
            "busy":self._busy,
            "run_time":self._run_time,
            "sleep_time":self._sleep_time,
            "totle_time":self._totle_time,
            "totle_count":self._totle_count,
            "current_task":self._current_task,
            "mem_size":ps.get_memory_info()[0]
        }

    @staticmethod
    def get_current_worker():
        return Worker._current_task

    def option(self):
        return self._option
