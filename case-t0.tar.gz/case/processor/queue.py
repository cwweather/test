import time
import threading
import multiprocessing
from base.pipe import Pipe
import config
from config import log

class Queue(object):
    def __init__(self):
        self._tasks=[]
        self._thread=threading.Thread(target=self.server)
        self._pp,self._sp=Pipe()
        self._lock=multiprocessing.Lock()
        self._glock=multiprocessing.Lock()
        self._empty_lock=multiprocessing.Event()

        self._thread.setDaemon(True)
        self._thread.start()

    def _put(self,tasks):
        last_task=self._tasks[-1] if len(self._tasks)>0 else None
        tasks=sorted(tasks,lambda x,y:cmp(x.priority,y.priority))
        self._tasks.extend(tasks)
        if last_task and last_task.priority!=tasks[0].priority:
            self._tasks=sorted(self._tasks,lambda x,y:cmp(x.priority,y.priority))
        if not self._empty_lock.is_set():self._empty_lock.set()

    def _get(self):
        task=self._tasks.pop(0)
        if task.type==task.TASK_TYPE.BROADCAST:
            from processor import Processor
            Processor._processor.broadcast_task(task)
            task=None
        if len(self._tasks)<=0:self._empty_lock.clear()
        return task

    def put(self,task):
        with self._lock:
            self._sp.send(("set",task))

    def get(self,timeout=None):
        with self._glock:
            if not self._empty_lock.wait(timeout):return None
            with self._lock:
                self._sp.send(("get",None))
                return self._sp.recv()

    def server(self):
        while True:
            method,value=self._pp.recv()
            if method=="get":
                self._pp.send(self._get())
            elif method=="set":
                self._put(value)

    def clear(self):
        log.info("processor not finish task:%s",self._tasks)

    def count(self):
        return len(self._tasks)

class WorkerQueue(object):
    def __init__(self):
        self._workers=[]

    def add(self,worker):
        self._workers.append(worker)

    def remove(self,worker):
        worker.stop()
        self._workers.remove(worker)

    def __iter__(self):
        for worker in self._workers:
            yield worker
        raise StopIteration

    def stop(self):
        t=time.time()
        for worker in self._workers:
            worker.stop()
        for worker in self._workers:
            if worker.is_alive():
                worker.join(config.get("stop_time_out",15-(time.time()-t)))
                if worker.is_alive():
                    worker.terminate()

    def count(self):
        return len(self._workers)