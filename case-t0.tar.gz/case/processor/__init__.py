from utils import Enum
from queue import Queue,WorkerQueue
from worker import Worker
from task import Task
import context
import config
from config import log

PROCESSOR_STATE=Enum(
    UNINIT=0,
    INITED=1,
    LOADED=2,
    STARTED=3,
    STOPED=4
)

class OceanAlreadyInitError(Exception):pass
class OceanAlreadyStartError(Exception):pass
class OceanAlreadyLoadError(Exception):pass
class OceanNotStartedError(Exception):pass

class Processor(object):
    def __init__(self):
        self._task_queue=None
        self._worker_queue=None
        self._state=PROCESSOR_STATE.UNINIT

    def init(self):
        if self._state!=PROCESSOR_STATE.UNINIT and self._state!=PROCESSOR_STATE.STOPED:
            raise OceanAlreadyInitError
        self._task_queue=Queue()
        self._worker_queue=WorkerQueue()
        context.init()
        self._state=PROCESSOR_STATE.INITED

    def load(self):
        if self._state!=PROCESSOR_STATE.INITED:
            raise OceanAlreadyLoadError
        for i in range(config.get("worker_count",2)):
            w=Worker(self,self._task_queue)
            self._worker_queue.add(w)
        self._state=PROCESSOR_STATE.LOADED

    def start(self):
        if self._state!=PROCESSOR_STATE.LOADED:
            raise OceanAlreadyStartError
        for worker in self._worker_queue:
            worker.start()
        self._state=PROCESSOR_STATE.STARTED

    def stop(self):
        if self._state!=PROCESSOR_STATE.STARTED:
            raise OceanNotStartedError
        self._worker_queue.stop()
        self._task_queue.clear()
        self._task_queue=None
        self._worker_queue=None
        self._state=PROCESSOR_STATE.STOPED

    def add(self,tasks):
        if not tasks:return
        from config import log
        self._task_queue.put(tasks)
        if len(tasks)>1:
            log.debug("processor tasks add :%s",len(tasks))
        else:
            log.debug("processor task add :%s",tasks[0])

    def broadcast_task(self,task):
        for worker in self._worker_queue:
            worker.broadcast(task)

_processor=Processor()

def init():
    _processor.init()

def load():
    _processor.load()

def start():
    _processor.start()

def stop():
    state=get_state()
    _processor.stop()
    log.info("processor state:%s",state)

def add_task(task):
    _processor.add([task])

def add_tasks(tasks):
    _processor.add(tasks)

def get_processor():
    return _processor

def set_config(c):
    config.update(c)

def get_current_worker():
    return Worker.get_current_worker()

def get_state():
    worker_states=[]
    totle_time,totle_count,mem_size=0,0,0
    for worker in _processor._worker_queue:
        state=worker.option().state()
        if state:
            totle_time+=state["totle_time"]
            totle_count+=state["totle_count"]
            mem_size+=state["mem_size"]
        worker_states.append(state)

    return {
        "task_queue_count":_processor._task_queue.count(),
        "worker_count":_processor._worker_queue.count(),
        "totle_time":totle_time,
        "totle_count":totle_count,
        "mem_size":mem_size,
        "worker_states":worker_states,
    }