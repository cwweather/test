import types
from utils import Enum

class Task(object):
    TASK_TYPE=Enum(
        NORMAL=0,
        BROADCAST=1,
    )

    def __init__(self,callback,*args,**kwargs):
        if type(callback) == types.MethodType:
            self.instance=callback.im_self
            self.callback=callback.__name__
        else:
            self.callback=callback
        self.args=args
        self.kwargs=kwargs
        self.priority=10
        self.type=self.TASK_TYPE.NORMAL
        self.context=None
        self.done=False

    def run(self):
        try:
            if callable(self.callback):
                self.callback(*self.args,**self.kwargs)
            else:
                getattr(self.instance,self.callback)(*self.args,**self.kwargs)
        finally:
            self.done=True

            if self.context:
                self.context.finish()
        return True

    def __repr__(self):
        return self.__str__()

    def __str__(self):
        if callable(self.callback):
            return "callback=%s,args=%s,kwargs=%s" % (self.callback,self.args,self.kwargs)
        else:
            return "callback=%s.%s,args=%s,kwargs=%s" % (self.instance,self.callback,self.args,self.kwargs)