# -*- coding: utf-8 -*-
#13-12-9

import logging
import settings

'''
default={
    "worker_count":2,
    "stop_time_out":15,
    'context_ratio':10000,
    "logger":None,
}'''

_config=settings.processor

class Log(object):
    def __init__(self):
        self._log=logging.getLogger(_config.get("logger",None))

    def debug(self,*args,**kwargs):
        return self._log.debug(*args,**kwargs)

    def info(self,*args,**kwargs):
        return self._log.info(*args,**kwargs)

    def warning(self,*args,**kwargs):
        return self._log.warning(*args,**kwargs)

    def error(self,*args,**kwargs):
        return self._log.error(*args,**kwargs)

    def critical(self,*args,**kwargs):
        return self._log.critical(*args,**kwargs)

    def __getattr__(self, name):
        return getattr(self._log,name)

log=Log()

def get(name,default=None):
    return _config.get(name,default)

def update(config):
    _config.update(config)