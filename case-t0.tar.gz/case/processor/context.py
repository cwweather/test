# -*- coding: utf-8 -*-
#14-2-21

import math
import time
import multiprocessing
import config
import task

_lock=None
_context_index=None
_contexts=None

class ContextInfo(object):
    def __init__(self,context_id):
        self._context_id=context_id
        global _contexts
        _contexts[self._context_id]=0

    def finish(self):
        global _contexts
        _contexts[self._context_id]=1

    def get_context_id(self):
        return self._context_id

class Context(object):
    def __init__(self):
        self._contexts=[]

    def create_info(self):
        global _context_index
        with _lock:
            _context_index.value+=1
            if _context_index.value==len(_contexts):
                _context_index.value=0
            while _contexts[_context_index.value]!=0:
                _context_index.value+=1
                if _context_index.value==len(_contexts):
                    _context_index.value=0
                    time.sleep(0.01)
            index=_context_index.value
        context=ContextInfo(index)
        self._contexts.append(context)
        return context

    def wait(self):
        global _contexts
        while True:
            for context in self._contexts:
                context_id=context.get_context_id()
                if _contexts[context_id]==1:
                    self._contexts.remove(context)
                    _contexts[context_id]=0
            if not self._contexts:
                break
            time.sleep(0.025*math.sqrt(len(self._contexts)))

    def Task(self,callback,*args,**kwargs):
        t=task.Task(callback,*args,**kwargs)
        t.context=self.create_info()
        return t

    def __enter__(self):
        self._contexts=[]

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.wait()

def init():
    global _lock,_context_index,_contexts
    _lock=multiprocessing.Lock()
    _context_index=multiprocessing.Value('i',-1)
    _contexts=multiprocessing.Array('i',config.get('worker_count',2)*config.get('context_ratio',10000))