# -*- coding: utf-8 -*-
#14-1-10

import threading
import multiprocessing
from base.pipe import Pipe

class Option(object):
    def __init__(self,worker):
        self._worker=worker
        self._pp,self._sp=Pipe()
        self._thread=None
        self._lock=multiprocessing.Lock()
        self._stop=multiprocessing.Event()

    def server(self):
        while not self._stop.is_set():
            cmd,args,kwargs=self._pp.recv()
            if hasattr(self,cmd):
                try:
                    result=getattr(self,cmd)(*args,**kwargs)
                except:
                    result=None
            else:
                result=None
            self._pp.send(result)


    def start_server(self):
        self._thread=threading.Thread(target=self.server)
        self._thread.setDaemon(True)
        self._thread.start()

    def server_cmd(self,cmd,*args,**kwargs):
        with self._lock:
            self._sp.send((cmd,args,kwargs))
            return self._sp.recv()

    def state(self):
        if multiprocessing.current_process().pid==self._worker.pid:
            return self._worker.state()
        else:
            return self.server_cmd("state")