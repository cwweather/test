# -*- coding: utf-8 -*-
#14-1-13

import datetime
import settings
from core.oceandriver import Driver

class AutoIgnore(object):
    def run(self):
        sql="update case_cases set state=2,modifytime='%s' where jointime<='%s'" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),(datetime.date.today()-datetime.timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S"))
        db=Driver(settings.db.risk2)
        db.update(sql)

class IgnoreDelayed(object):

    def __init__(self):
        self._now=datetime.datetime.now()
        self._risk2_db=Driver(settings.db.risk2)

    def run(self):
        sql="select userid from case_delay where tradedate>='%s' group by userid order by userid" % self._now.strftime("%Y-%m-%d")
        delayeduser = self._risk2_db.query(sql)
        if delayeduser:
            sql="update case_cases set state=2,modifytime='%s' where time>='%s' and userid in (%s)" % (self._now.strftime("%Y-%m-%d %H:%M:%S"), self._now.strftime("%Y-%m-%d 00:00:00"), ",".join([str(user["userid"]) for user in delayeduser]))
            self._risk2_db.update(sql)

if __name__=="__main__":
    ai=AutoIgnore()
    ai.run()
