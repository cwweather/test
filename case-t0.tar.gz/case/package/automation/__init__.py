# -*- coding: utf-8 -*-
#13-11-28

from core.schprocessor import Plan,register
from delay import DelayMsg
from ignore import AutoIgnore, IgnoreDelayed
import settings

ALL_AUTOMATION=[
    (DelayMsg,False,{"hour":14,"minute":0,"second":0}),
    (AutoIgnore,False,{"hour":0,"minute":0,"second":0}),
    (IgnoreDelayed,True,{"minutes":1}),
]

def run(time,cls):
    c=cls()
    c.run()

try:
    disable=settings.automation.disable
except:pass

def start():
    for a in ALL_AUTOMATION:
        if a[1]:
            plan=Plan.make_interval_plan(run,(a[0],),**a[2])
            register(plan)
        else:
            plan=Plan.make_plan(run,(a[0],),**a[2])
            register(plan)
