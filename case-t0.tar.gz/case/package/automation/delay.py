# -*- coding: utf-8 -*-
#13-11-28

import datetime
from core.oceandriver import Driver
from base.appmsg import push_msg
import settings
from logger import log

class DelayMsg(object):
    msg_id=10

    def __init__(self):
        self._now=datetime.datetime.now()
        self._risk2_db=Driver(settings.db.risk2)

    def get_msg(self):
        sql="select id,smstext from case_smstemplate where id=%s" % self.msg_id
        return self._risk2_db.query(sql)[0]["smstext"]

    def get_delay_users(self):
        sql="select userid from case_delay where delaytime>='%s' and delaystatus=1 group by userid order by userid" % self._now.strftime("%Y-%m-%d 00:00:00")
        return [user["userid"] for user in self._risk2_db.query(sql)]

    def push_msg(self,users,msgtext):
        push_msg(users,msgtext)

    def run(self):
        users=self.get_delay_users()
        msgtext=self.get_msg()
        self.push_msg(users,msgtext)
        log.info("delay push msg: %s,%s",users,msgtext)

if __name__=="__main__":
    try:
        dm=DelayMsg()
        dm.run()
    except:
        from base import vtraceback as traceback
        log.error(traceback.format_exc())
