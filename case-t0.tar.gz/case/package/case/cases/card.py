# -*- coding: utf-8 -*-

from ..case import register_case,Case
from base.sms import send_sms
import settings
from core.oceandriver import Driver

@register_case
class DangerCard(Case):
    '''
    交易返回码是高危码的交易
    参数：code 高危码;is_black 是否拉黑
    备注：cardcd 卡号;sysdtm 交易时间;retcd 交易返回码
    '''
    has_syssn = True

    def __init__(self,*args,**kwargs):
        super(DangerCard,self).__init__(*args,**kwargs)

        self.code=str(self.code).split(",")
        self.is_black=True if int(self.is_black)>0 else False

        self.core_db=Driver(settings.db.core)
        self.mis_db=Driver(settings.db.mis)

    def search(self,sql=''):
        sql = "select userid,cardcd,syssn,sysdtm,retcd from record_@1 where sysdtm>='%s' and sysdtm<'%s' and retcd in (%s)" % (self.get_this_start_time(),self.get_this_end_time(),",".join(["'"+code+"'" for code in self.code]))
        return self.trade_db.query(sql)

    def end_data(self,datas,ends):
        if self.is_black:
            self.black(ends)
        return datas

    def black(self,black_trades):
        if not black_trades:return
        self.to_black_card({_t["cardcd"]:_t["userid"] for _t in black_trades})
        self.to_black_user([_t["userid"] for _t in black_trades])

    def get_has(self,selects,table,ins,type):
        sql="select %s from %s where %s and %s=1 and end_time>'%s'" % (",".join(selects),table,ins,type,self._now.strftime("%Y-%m-%d %H:%M:%S"))
        return self.risk2_db.query(sql)

    def add_black(self,tablse,dict):
        names=dict.keys()+["ctime"]
        data=dict.values()+[self._now.strftime("%Y-%m-%d %H:%M:%S")]
        sql="insert into %s (%s) values(%s)" % (tablse,",".join(names),("%s,"*len(data))[:-1])
        self.risk2_db.insert(sql,[data])

    def update_black(self,table,type,where,value):
        sql="update %s set %s=1,start_time='%s',end_time='2029-12-30 23:59:59',source='规则处理' where %s=%s " % (table,type,self._now.strftime("%Y-%m-%d %H:%M:%S"),where,str(value))
        self.risk2_db.update(sql)

    def get(self,db,table,selects,where,extra=""):
        sql="select %s from %s where %s %s" % (",".join(selects),table,where,extra)
        return db.query(sql)

    def to_black_card(self,black_cards):
        has_cards=self.get_has(["cardcd"],"card_black_white","cardcd in (%s)" % ",".join(["'"+card+"'" for card in black_cards.keys()]),"card_type")
        has_cards=[card["cardcd"] for card in has_cards]
        cards=list(set(black_cards.keys())-set(has_cards))
        if not cards:return
        for card in cards:
            if self.get(self.risk2_db,"card_black_white",["cardcd"],"cardcd='%s'" % card):
                self.update_black("card_black_white","card_type","cardcd","'"+card+"'")
            else:
                self.add_black("card_black_white",{"cardcd":card,"card_type":1,"start_time":self._now.strftime("%Y-%m-%d %H:%M:%S"),"end_time":"2029-12-30 23:59:59","source":u"规则处理"})
        self.send_msm({black_cards[card]:card for card in cards},16)

    def to_black_user(self,black_users):
        has_users=self.get_has(["userid"],"user_black_white","userid in (%s)" % ",".join([str(user) for user in black_users]),"user_type")
        has_users=[user["userid"] for user in has_users]
        users=list(set(black_users)-set(has_users))
        if not users:return
        sql = "select userid,COUNT(cardcd) as cnt from (select * from trade_record where sysdtm>='%s' and userid in (%s) and (payresp in (%s) or (payresp=1118 and riskret like '%s')) GROUP BY cardcd) trade_record_cardcd GROUP BY userid HAVING cnt>3 ORDER BY userid" % (self._now.strftime('%Y-%m-01 00:00:00'),",".join([str(user) for user in users]),",".join(self.code),'%HRK001%')
        users =[user["userid"] for user in self.risk2_db.query(sql)]
        if not users:return
        for user in users:
            if self.get(self.risk2_db,"user_black_white",["userid"],"userid=%s" % user):
                self.update_black("user_black_white","user_type","userid",str(user))
            else:
                self.add_black("user_black_white",{"userid":user,"user_type":1,"start_time":self._now.strftime("%Y-%m-%d %H:%M:%S"),"end_time":"2029-12-30 23:59:59","source":u"规则处理"})

            self.add_op_log(user)
        self.send_msm(users,17)

    def add_op_log(self,user):
        sql="insert into mis_oplog (admin_id,user_id,op_type,`action`,detail,notify_type) values(10000,%s,3,'商户黑白名单','操作[商户进入黑名单]商户ID[%s]来源[规则处理]',0)" % (user,user)
        self.mis_db.insert(sql)

    def send_msm(self,users,template_id):
        if not users:
            return
        template=self.get(self.risk2_db,"case_smstemplate",["smstext"],"id=%s" % str(template_id))
        if len(template)<1:return
        template=template[0]["smstext"]
        if type(users) is dict:
            user_phones=self.get(self.core_db,"auth_user",["id","username"],"id in (%s)" % ",".join([str(user) for user in users.keys()]))
            for user_phone in user_phones:
                send_sms(user_phone["username"],template % users[user_phone["id"]][-4:])
        else:
            user_phones=self.get(self.core_db,"auth_user",["username"],"id in (%s)" % ",".join([str(user) for user in users]))
            for user_phone in user_phones:
                send_sms(user_phone["username"],template)
