# -*- coding: utf-8 -*-

from ..case import register_case,Case
from base.geo import get_distance
import settings
from core.oceandriver import Driver
from cache.user import Profile

@register_case
class DistanceApplyBussiness(Case):
    '''
    入网经纬度与经营经纬度距离大于(distance)千米
    参数：distance 距离
    备注：distance 距离;apply_position 入网经纬度;busi_position 经营经纬度
    '''

    def __init__(self,*args,**kwargs):
        super(DistanceApplyBussiness,self).__init__(*args,**kwargs)

        self.mis_db=Driver(settings.db.mis)

        self.distance=int(self.distance)

    def search(self,sql=''):
        sql = "select user,latitude,longitude from apply where uploadtime between '%s' and '%s'" % (self.get_this_start_time(),self.get_this_end_time())
        applys = { a['user']: a  for a in self.mis_db.query(sql) if a['latitude'] and a['longitude']}
        if not applys:return []

        profile=Profile()
        return [{"userid":p,"apply_position":applys[p],"busi_position":profile[p]} for p in applys]

    def filter(self,case):
        if not case["busi_position"]:return False
        distance=get_distance(case["apply_position"]['latitude'],case["apply_position"]['longitude'],case["busi_position"]['latitude'],case["busi_position"]['longitude'])
        if distance>=self.distance:
            case["distance"]='%.3f' % distance
            case["apply_position"]="%s,%s" % (case["apply_position"]['latitude'],case["apply_position"]['longitude'])
            case["busi_position"]="%s,%s" % (case["busi_position"]['latitude'],case["busi_position"]['longitude'])
            return True
        return False

@register_case
class DistanceApplyTrade(Case):
    '''
    入网经纬度与交易经纬度距离大于(distance)千米
    参数：distance 距离
    备注：distance 距离;apply_position 入网经纬度;trade_position 交易经纬度
    '''
    has_syssn = True

    def __init__(self,*args,**kwargs):
        super(DistanceApplyTrade,self).__init__(*args,**kwargs)

        self.mis_db=Driver(settings.db.mis)

        self.distance=int(self.distance)

    def search(self,sql=''):
        sql = "select userid,latitude,longitude,syssn from record_@1 where sysdtm>='%s' and sysdtm<'%s'" % (self.get_this_start_time(),self.get_this_end_time())
        trades = {t["userid"]:t for t in self.trade_db.query(sql) if t['latitude'] and t['longitude']}
        if not trades:return []

        sql = "select user,latitude,longitude from apply where user in (%s)" % ",".join([str(user) for user in trades.keys()])
        applys = {a['user']:a  for a in self.mis_db.query(sql) if a['latitude'] and a['longitude']}

        return [{"userid":a,"syssn":trades[a]["syssn"],"apply_position":applys[a],"trade_position":trades[a]} for a in applys]

    def filter(self,case):
        distance=get_distance(case["apply_position"]['latitude'],case["apply_position"]['longitude'],case["trade_position"]['latitude'],case["trade_position"]['longitude'])
        if distance>=self.distance:
            case["distance"]='%.3f' % distance
            case["apply_position"]="%s,%s" % (case["apply_position"]['latitude'],case["apply_position"]['longitude'])
            case["trade_position"]="%s,%s" % (case["trade_position"]['latitude'],case["trade_position"]['longitude'])
            return True
        return False
