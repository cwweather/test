# -*- coding: utf-8 -*-
import datetime
from ..case import register_case,Case
from base.sms import send_sms
import settings
from core.oceandriver import Driver

@register_case
class HRKcode(Case):
    '''
    交易返回码是高危码的交易
    参数：code 高危码;is_black 是否拉黑:0不拉黑，1卡商户都拉黑，2卡拉黑，3商户拉黑; if_forceblack 是否强制拉黑，覆盖原有记录
    备注：cardcd 卡号;sysdtm 交易时间;retcd 交易返回码
    '''
    has_syssn = True

    def __init__(self,*args,**kwargs):
        super(HRKcode,self).__init__(*args,**kwargs)

        self.code=str(self.code).replace(" ", "").split(",")
        self.is_black=int(self.is_black)
        self.dayormonth = str(self.dayormonth)
        if self.dayormonth == "d":
            self.dayormonth = "d"
        else:
            self.dayormonth = "01"
        try:
            self.blackdays = int(self.blackdays) if self.blackdays else 180
        except:
            self.blackdays = 180
        self.core_db=Driver(settings.db.core)
        self.mis_db=Driver(settings.db.mis)


    def search(self,sql=''):
        sql = "select userid,cardcd,syssn,sysdtm,retcd from record_@1 where sysdtm>='%s' and sysdtm<'%s' and retcd in (%s)" % (self.get_this_start_time(),self.get_this_end_time(),",".join(["'"+code+"'" for code in self.code]))
        return self.trade_db.query(sql)

    def end_data(self,datas,ends):
        if self.is_black:
            self.black(ends)
        return datas

    def black(self,black_trades):
        if not black_trades:return
        if self.is_black == 1 or self.is_black == 2:
            self.to_black_card({_t["cardcd"]:_t["userid"] for _t in black_trades})
        if self.is_black == 1 or self.is_black == 3:
            self.to_black_user([_t["userid"] for _t in black_trades])

    def get_has(self,selects,table,ins):
        sql="select %s from %s where %s and end_time>'%s'" % (",".join(selects),table,ins,self._now.strftime("%Y-%m-%d %H:%M:%S"))
        return self.risk2_db.query(sql)

    def add_black(self,tablse,dict):
        names=dict.keys()+["ctime"]
        data=dict.values()+[self._now.strftime("%Y-%m-%d %H:%M:%S")]
        sql="insert into %s (%s) values(%s)" % (tablse,",".join(names),("%s,"*len(data))[:-1])
        self.risk2_db.insert(sql,[data])

    def update_black(self,table,type,where,value):
        sql="update %s set %s=1,start_time='%s',end_time='%s',source='规则处理' where %s=%s " % \
            (table,
             type,
             self._now.strftime("%Y-%m-%d %H:%M:%S"),
             (self._now + datetime.timedelta(days=self.blackdays)).strftime("%Y-%m-%d %H:%M:%S"),
             where,
             str(value))
        self.risk2_db.update(sql)

    def get(self,db,table,selects,where,extra=""):
        sql="select %s from %s where %s %s" % (",".join(selects),table,where,extra)
        return db.query(sql)

    def to_black_card(self,black_cards):
        if isinstance(black_cards, list):
            has_cards=self.get_has(["cardcd"],"card_black_white","cardcd in (%s)" % ",".join(["'"+card+"'" for card in black_cards]))
            has_cards=[card["cardcd"] for card in has_cards]
            cards=list(set(black_cards)-set(has_cards))
        else:
            has_cards=self.get_has(["cardcd"],"card_black_white","cardcd in (%s)" % ",".join(["'"+card+"'" for card in black_cards.keys()]))
            has_cards=[card["cardcd"] for card in has_cards]
            cards=list(set(black_cards.keys())-set(has_cards))
        if not cards:return
        for card in cards:
            if self.get(self.risk2_db,"card_black_white",["cardcd"],"cardcd='%s'" % card):
                self.update_black("card_black_white","card_type","cardcd","'"+card+"'")
            else:
                self.add_black("card_black_white", {
                    "cardcd": card,
                    "card_type": 1,
                    "start_time": self._now.strftime("%Y-%m-%d %H:%M:%S"),
                    "end_time": (self._now + datetime.timedelta(days=self.blackdays)).strftime("%Y-%m-%d %H:%M:%S"),
                    "source": u"规则处理"
                })

    def to_black_user(self,black_users):
        has_users=self.get_has(["userid"],"user_black_white","userid in (%s)" % ",".join([str(user) for user in black_users]))
        has_users=[user["userid"] for user in has_users]
        users=list(set(black_users)-set(has_users))
        if not users:return
        for user in users:
            if self.get(self.risk2_db,"user_black_white",["userid"],"userid=%s" % user):
                self.update_black("user_black_white","user_type","userid",str(user))
            else:
                self.add_black("user_black_white", {
                    "userid": user,
                    "user_type": 1,
                    "start_time": self._now.strftime("%Y-%m-%d %H:%M:%S"),
                    "end_time": (self._now + datetime.timedelta(days=self.blackdays)).strftime("%Y-%m-%d %H:%M:%S"),
                    "source":u"规则处理"
                })
            self.add_op_log(user)
        self.send_msm(users,17)

    def add_op_log(self,user):
        sql="insert into mis_oplog (admin_id,user_id,op_type,`action`,detail,notify_type) values(10000,%s,3,'商户黑白名单','操作[商户进入黑名单]商户ID[%s]来源[规则处理]',0)" % (user,user)
        self.mis_db.insert(sql)

    def send_msm(self,users,template_id):
        if not users:
            return
        template=self.get(self.risk2_db,"case_smstemplate",["smstext"],"id=%s" % str(template_id))
        if len(template)<1:return
        template=template[0]["smstext"]
        if type(users) is dict:
            user_phones=self.get(self.core_db,"auth_user",["id","username"],"id in (%s)" % ",".join([str(user) for user in users.keys()]))
            for user_phone in user_phones:
                send_sms(user_phone["username"],template % users[user_phone["id"]][-4:])
        else:
            user_phones=self.get(self.core_db,"auth_user",["username"],"id in (%s)" % ",".join([str(user) for user in users]))
            for user_phone in user_phones:
                send_sms(user_phone["username"],template)


@register_case
class HRKcode_t0(HRKcode):
    '''
    x分钟内>=c张不同卡出现高危码，拉黑商户
    [
        {"name":"code","descript":"高危码"},
        {"name":"is_black","descript":"是否拉黑：1卡商户都拉黑，2卡拉黑，3商户拉黑"},
        {"name":"dayormonth","descript":"商户高危码按日统计(d)或者按月统计(m)"},
        {"name":"mins","descript":"当前时间多少分钟的交易"},
        {"name":"mins_count","descript":"达到多少次不同卡交易"},
        {"name":"blackdays","descript":"拉黑天数"},
    ]
    参数：code 高危码;is_black 是否拉黑:0不拉黑，1卡商户都拉黑，2卡拉黑，3商户拉黑; if_forceblack 是否强制拉黑，覆盖原有记录
    备注：cardcd 卡号;sysdtm 交易时间;retcd 交易返回码
    '''
    has_syssn = True

    def __init__(self, *args, **kwargs):
        super(HRKcode_t0, self).__init__(*args, **kwargs)
        self.mins = int(self.mins)
        self.mins_count = int(self.mins_count)
        self.core_db = Driver(settings.db.core)
        self.mis_db = Driver(settings.db.mis)
        self.t0 = 1

    def get_group_users(self):
        if self.t0:
            sql = "select userid from profile where settle_flag=2"
            t0_users = self.core_db.query(sql)
            sql = ",".join([str(user["userid"]) for user in t0_users])
            return " and userid in (" + sql + ") and"
        else:
            return ""

    def get_starttime(self):
        if self.mins:
            return (self._now-datetime.timedelta(minutes=self.mins)).strftime("%Y-%m-%d %H:%M:%S")
        else:
            return self._now.strftime("%Y-%m-%d 00:00:00")

    def search(self, sql=''):
        sql = "select userid,cardcd,syssn,sysdtm,retcd from record_@1 where %s sysdtm>='%s' and sysdtm<'%s' and retcd in (%s) group by userid, cardcd" % \
              (
                  self.get_group_users(),
                  self.get_starttime(),
                  self._now.strftime("%Y-%m-%d %H:%M:%S"),
                  ",".join(["'"+code+"'" for code in self.code])
              )
        all = self.trade_db.query(sql)
        cases = {}
        data = []
        for hrk_trade in all:
            userid = hrk_trade["userid"]
            cardcd = hrk_trade["cardcd"]
            syssn = hrk_trade["syssn"]
            sysdtm = hrk_trade["sysdtm"]
            retcd = hrk_trade["retcd"]
            if userid not in cases:
                cases[userid] = {
                    "cardcds": [cardcd],
                    "syssn": syssn,
                    "sysdtm": [sysdtm],
                    "retcd": set([retcd]),
                }
            else:
                cases[userid]["cardcds"].append(cardcd)
                cases[userid]["syssn"] = syssn
                cases[userid]["sysdtm"].append(sysdtm)
                cases[userid]["retcd"].add(retcd)
        for user in cases:
            if len(cases[user]["cardcds"]) > self.mins_count:
                cases[user]["retcd"] = list(cases[user]["retcd"])
                cases[user].update({"userid": user})
                data.append(cases[user])
        return data

    def end_data(self, datas, ends):
        if self.is_black:
            self.black(ends)
        return datas

    def black(self, black_trades):
        if not black_trades:
            return
        blackcards = []
        blackuserids = []
        for _t in black_trades:
            if self.is_black == 1 or self.is_black == 2:
                blackcards.extend(_t["cardcds"])
            if self.is_black == 1 or self.is_black == 3:
                blackuserids.append(_t["userid"])
        if self.is_black == 1 or self.is_black == 2:
            self.to_black_card(list(set(blackcards)))
        if self.is_black == 1 or self.is_black == 3:
            self.to_black_user(list(set(blackuserids)))

@register_case
class HRKcodeSameCard(HRKcode_t0):
    def __init__(self, *args, **kwargs):
        super(HRKcodeSameCard, self).__init__(*args, **kwargs)

    def search(self, sql=''):
        sql = "select cardcd,userid,syssn,sysdtm,retcd from record_@1 where %s sysdtm>='%s' and sysdtm<'%s' and retcd in (%s) group by cardcd" % \
              (
                  self.get_group_users(),
                  self.get_starttime(),
                  self._now.strftime("%Y-%m-%d %H:%M:%S"),
                  ",".join(["'"+code+"'" for code in self.code])
              )
        all = self.trade_db.query(sql)
        cases = {}
        data = []
        for hrk_trade in all:
            userid = hrk_trade["userid"]
            cardcd = hrk_trade["cardcd"]
            syssn = hrk_trade["syssn"]
            sysdtm = hrk_trade["sysdtm"]
            retcd = hrk_trade["retcd"]
            if cardcd not in cases:
                cases[cardcd] = {
                    "userids": [userid],
                    "syssn": syssn,
                    "sysdtm": [sysdtm],
                    "retcd": set([retcd]),
                }
            else:
                cases[cardcd]["userids"].append(userid)
                cases[cardcd]["syssn"] = syssn
                cases[cardcd]["sysdtm"].append(sysdtm)
                cases[cardcd]["retcd"].add(retcd)
        for card in cases:
            if len(cases[card]["userids"]) > self.mins_count:
                cases[card]["retcd"] = list(cases[card]["retcd"])
                cases[card].update({"cardcd": card})
                data.append(cases[card])
        return data

    def black(self, black_trades):
        if not black_trades:
            return
        blackcards = []
        blackuserids = []
        for _t in black_trades:
            if self.is_black == 1 or self.is_black == 2:
                blackcards.append(_t["cardcd"])
            if self.is_black == 1 or self.is_black == 3:
                blackuserids.extend(_t["userids"])
        if self.is_black == 1 or self.is_black == 2:
            self.to_black_card(list(set(blackcards)))
        if self.is_black == 1 or self.is_black == 3:
            self.to_black_user(list(set(blackuserids)))