# -*- coding: utf-8 -*-

from ..case import register_case,Case
import datetime
import settings
from core.oceandriver import Driver
from utils import Enum
from cache.user import Profile

@register_case
class SamePhone(Case):
    '''
    收据的手机号码，与商户在钱方绑定注册的手机号码一致，且交易金额超过（amt_abov）。
    参数：amt_abov 交易金额
    备注：sumamt 交易金额;daysumamt 当日交易金额;mobile 手机号
    '''

    def __init__(self,*args,**kwargs):
        super(SamePhone,self).__init__(*args,**kwargs)

        self.amt_abov=int(self.amt_abov)*100

    def get_users(self):
        sql = "select userid,contact from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and contact is not null and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) group by userid,contact order by userid" % (self.get_this_start_time(),self.get_this_end_time())
        return {user["contact"]:user["userid"] for user in self.trade_db.query(sql)}

    def search(self,sql=''):
        users=self.get_users()
        if not users:return {}
        sql = "select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and contact is not null and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) and userid in (%s) group by userid having sumamt>=%s order by userid" % (self.get_this_today(),self.get_this_end_time(),",".join([str(user) for user in set(users.values())]),self.amt_abov)
        trades = {trade["userid"]:trade["sumamt"] for trade in self.trade_db.query(sql)}
        if not trades:return []

        profile=Profile()
        day_sumamts=self.get_day_sumamt(users.keys())

        return [{"userid":user,'sumamt': trades.get(user,0),"daysumamt":day_sumamts.get(contact,0), 'mobile':contact} for contact,user in users.items() if user in trades and profile[user] and contact==profile[user]["mobile"]]

    def get_day_sumamt(self,contacts):
        sql = "select contact,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and contact in (%s) group by contact order by contact" % (self.get_this_today(),self.get_this_end_time(),",".join(["'"+str(contact)+"'" for contact in contacts]))
        return {contact["contact"]:contact["sumamt"] for contact in self.trade_db.query(sql)}


@register_case
class HasNoPwd(Case):
    '''
    商户信用卡交易无密码，且该交易的交易金额大于（amt_abov）
    参数： amt_abov 交易金额
    备注： cardcd 卡号;sumamt 交易金额
    '''

    def __init__(self,*args,**kwargs):
        super(HasNoPwd,self).__init__(*args,**kwargs)

        self.amt_abov=int(self.amt_abov)*100

    def get_today(self):
        return self._now.strftime("%Y-%m-%d 00:00:00") if self._now.day<=datetime.datetime.strptime(self.last_start_time,"%Y-%m-%d %H:%M:%S").day else (self._now-datetime.timedelta(days=1)).strftime("%Y-%m-%d 00:00:00")

    def get_cards(self):
        cardcd_sql="select cardcd from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) and haspwd=0 group by cardcd" % (self.get_this_start_time(),self.get_this_end_time())
        return self.trade_db.query(cardcd_sql)

    def search(self,sql=''):
        cards=self.get_cards()
        if not cards:return []
        sql = "select userid,cardcd,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and cardcd in (%s) and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) and haspwd=0 group by userid,cardcd having sumamt>%s order by sumamt desc" % (self.get_this_today(),self.get_this_end_time(),",".join(["'"+card["cardcd"]+"'" for card in cards]),self.amt_abov)
        return self.trade_db.query(sql)

@register_case
class TopTradingVolume(Case):
    '''
    前(days)日(card_type)交易额最高的(user_count)个商户。
    参数：days 天数;user_count 统计数目;card_type 交易类型
    备注：sumamt 总交易金额;desumamt 借记卡交易金额;cresumamt 信用卡交易金额
    '''
    run_interval = None
    run_time = ["20**-**-** 00:00:00 *",]
    CARD_TYPE=Enum(
        ALL=(0,u'所有卡类型'),
        DEBIT=(1,u'借记卡'),
        CREDIT=(2,u'信用卡'),
    )

    def __init__(self,*args,**kwargs):
        super(TopTradingVolume,self).__init__(*args,**kwargs)

        self.days=int(self.days)
        self.user_count=int(self.user_count)
        self.card_type=int(self.card_type)
        self.abov_amt=int(self.abov_amt)*100
        self.txamt=int(self.txamt)*100

    def get_this_start_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-1)).strftime("%Y-%m-%d 00:00:00")

    def get_this_end_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-2)).strftime("%Y-%m-%d 00:00:00")

    def get_this_today(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-1)).strftime('%Y-%m-%d 00:00:00')

    def get_debit_card_volume(self,userid):
        sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and cardtp='01' and userid=%s group by userid order by userid" \
            % (self.get_this_start_time(),self.get_this_end_time(),userid)
        sumamt = self.trade_db.query(sql)
        return (sumamt[0]["sumamt"] or 0) if sumamt else 0

    def get_credit_card_volume(self,userid):
        sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and cardtp='02' and userid=%s group by userid order by userid" \
            % (self.get_this_start_time(),self.get_this_end_time(),userid)
        sumamt = self.trade_db.query(sql)
        return (sumamt[0]["sumamt"] or 0) if sumamt else 0

    def get_user_count(self):
        if self.user_count<=0:
            return ''
        return "limit %s" % self.user_count

    def get_card_type(self):
        if self.card_type==self.CARD_TYPE.ALL:
            return ''
        elif self.card_type==self.CARD_TYPE.DEBIT:
            return "and cardtp='01'"
        elif self.card_type==self.CARD_TYPE.CREDIT:
            return "and cardtp='02'"
        return ''

    def get_abov_amt(self):
        if self.abov_amt<=0:
            return ''
        return 'having sumamt>%s' % self.abov_amt

    def get_txamt(self):
        if self.txamt<=0:
            return ''
        return "and txamt>%s" % self.txamt

    def search(self,sql=''):
        sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0  %s %s group by userid %s order by sumamt desc,userid %s" \
            % (self.get_this_start_time(),self.get_this_end_time(),self.get_card_type(),self.get_txamt(),self.get_abov_amt(),self.get_user_count())
        return self.trade_db.query(sql)

    def filter(self,case):
        if self.card_type==self.CARD_TYPE.ALL:
            case.update({"desumamt":self.get_debit_card_volume(case["userid"]),"cresumamt":self.get_credit_card_volume(case["userid"])})
        return True

@register_case
class TopTradingCount(Case):
    '''
    前(days)日(card_type)刷卡次数最高(user_count)个商户。
    参数：days 天数;user_count 统计数目;card_type 交易类型
    备注：cnt 刷卡次数;sumamt 总交易额
    '''
    run_interval = None
    run_time = ["20**-**-** 00:00:00 *",]
    CARD_TYPE=Enum(
        ALL=(0,u'所有卡类型'),
        DEBIT=(1,u'借记卡'),
        CREDIT=(2,u'信用卡'),
    )

    def __init__(self,*args,**kwargs):
        super(TopTradingCount,self).__init__(*args,**kwargs)

        self.days=int(self.days)
        self.user_count=int(self.user_count)
        self.card_type=int(self.card_type)
        self.cnt=int(self.cnt)
        self.txamt=int(self.txamt)*100

    def get_this_start_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-1)).strftime("%Y-%m-%d 00:00:00")

    def get_this_end_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-2)).strftime("%Y-%m-%d 00:00:00")

    def get_this_today(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-1)).strftime('%Y-%m-%d 00:00:00')

    def get_user_count(self):
        if self.user_count<=0:
            return ''
        return "limit %s" % self.user_count

    def get_card_type(self):
        if self.card_type==self.CARD_TYPE.ALL:
            return ''
        elif self.card_type==self.CARD_TYPE.DEBIT:
            return "and cardtp='01'"
        elif self.card_type==self.CARD_TYPE.CREDIT:
            return "and cardtp='02'"
        return ''

    def get_cnt(self):
        if self.cnt<=0:
            return ''
        return 'having cnt>%s' % self.cnt

    def get_txamt(self):
        if self.txamt<=0:
            return ''
        return "and txamt>%s" % self.txamt

    def search(self,sql=''):
        sql="select userid,COUNT(userid) as cnt,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 %s %s GROUP BY userid %s ORDER BY cnt DESC,userid %s" \
            % (self.get_this_start_time(),self.get_this_end_time(),self.get_card_type(),self.get_txamt(),self.get_cnt(),self.get_user_count())
        return self.trade_db.query(sql)

@register_case
class BusicdPercent(Case):
    '''
    前(days)日(busicd)交易数于总交易数比大于(percent)且（busicd）交易数大于（min_count）的商户。
    参数：days 天数;busicd 交易类型;count 交易次数;sumamt 交易金额;percent 比值
    备注：cnt 总交易数;sumamt 总交易额;bcnt 交易数
    '''
    run_interval = None
    run_time = ["20**-**-** 00:00:00 *",]

    def __init__(self,*args,**kwargs):
        super(BusicdPercent,self).__init__(*args,**kwargs)

        self.days=int(self.days)
        self.busicd=str(self.busicd)
        self.count=int(self.count)
        self.sumamt=int(self.sumamt)*100
        self.percent=float(self.percent)

    def get_key(self):
        if self.busicd=='300000':
            return 'becnt'
        return 'bcnt'

    def get_this_start_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-1)).strftime("%Y-%m-%d 00:00:00")

    def get_this_end_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-2)).strftime("%Y-%m-%d 00:00:00")

    def get_this_today(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-1)).strftime('%Y-%m-%d 00:00:00')

    def search(self,sql=''):
        sql="select userid,COUNT(userid) as cnt,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and cardtp is not null GROUP BY userid having cnt>=%s and sumamt>=%s order by userid" \
            % (self.get_this_start_time(),self.get_this_end_time(),self.count,self.sumamt)
        all_trades={trade["userid"]:trade for trade in self.trade_db.query(sql)}

        sql="select userid,COUNT(userid) as bcnt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='%s' and retcd='0000' and cancel=0 and cardtp is not null GROUP BY userid order by userid" \
            % (self.get_this_start_time(),self.get_this_end_time(),self.busicd)
        btrades={trade["userid"]:trade for trade in self.trade_db.query(sql)}

        return [{"userid":trade,"cnt":all_trades[trade]["cnt"],"sumamt":all_trades[trade]["sumamt"],self.get_key():btrades[trade]["bcnt"]} for trade in all_trades if trade in btrades]

    def filter(self,case):
        return float(case["cnt"])/float(case[self.get_key()])<1/self.percent

@register_case
class FilterUserInfo(Case):
    '''
    新申请的商户信息中包含设定关键词.
    参数：bussiness_addr 经营地址;idnumber 身份证号;mobile 手机号
    备注：bussiness_addr 经营地址;idnumber 身份证号;mobile 手机号
    '''
    def __init__(self,*args,**kwargs):
        super(FilterUserInfo,self).__init__(*args,**kwargs)

        self.bussiness_addr=unicode(self.bussiness_addr).strip().split(",")
        self.idnumber=str(self.idnumber).strip().split(",")
        self.mobile=str(self.mobile).strip().split(",")

        self.mis_db=Driver(settings.db.mis)

    def search(self,sql=''):
        sql="select `user`,city,address,idnumber,mobile from apply where uploadtime between '%s' and '%s' order by `user`" % (self.get_this_start_time(),self.get_this_end_time())
        users=self.mis_db.query(sql)
        return [{"userid":user["user"],"bussiness_addr":user["city"]+" "+user["address"],"idnumber":user["idnumber"],"mobile":user["mobile"]} for user in users]

    def filter(self,case):
        return self.filter_bussiness_addr(case["bussiness_addr"]) or self.filter_idnumber(case["idnumber"]) or self.filter_mobile(case["mobile"])

    def filter_bussiness_addr(self,bussiness_addr):
        for ba in self.bussiness_addr:
            if ba in bussiness_addr:
                return True
        return False

    def filter_idnumber(self,idnumber):
        for ID in self.idnumber:
            if ID.strip()==idnumber.strip():
                return True
        return False

    def filter_mobile(self,mobile):
        for p in self.mobile:
            if p.strip()==mobile.strip():
                return True
        return False


@register_case
class CreditPaymentsRisk(Case):
    '''
    针对于信用卡还款与商户交易卡对比关联规则，便于发现商户的套现行为
    '''

    has_syssn = True

    def __init__(self,*args,**kwargs):
        super(CreditPaymentsRisk,self).__init__(*args,**kwargs)
        self.txamt=int(self.txamt)*100
        self.sumamt=int(self.sumamt)*100

    def get_users(self):
        sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='401000' and retcd='0000' and cancel=0 having sumamt>=%s order by userid" % (self.get_this_today(),self.get_this_end_time(),self.sumamt)
        return [user["userid"] for user in self.trade_db.query(sql)]

    def get_cards(self,users):
        if not users:return {},{},[]
        sql="select userid,cardcd,incardcd,syssn from record_@1 where userid in (%s) and sysdtm>='%s' and sysdtm<'%s' and busicd='401000' and retcd='0000' and cancel=0 and txamt>='%s' order by userid" % (",".join([str(user) for user in users]),self.get_this_start_time(),self.get_this_end_time(),self.txamt)
        rets=self.trade_db.query(sql)
        return {user["userid"]:user for user in rets},{card["incardcd"]:card for card in rets},rets

    def get_trades(self,users,cards):
        if not users or not cards:return {}
        sql="select userid,cardcd,syssn from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and cardtp='02' and userid in (%s) and cardcd in (%s) order by userid" % (self.get_this_today(),self.get_this_end_time(),",".join([str(user) for user in users]),",".join(["'"+str(card)+"'" for card in cards]))
        return self.trade_db.query(sql)

    def search(self,sql=''):
        users=self.get_users()
        users,credits,cards=self.get_cards(users)
        trades=self.get_trades(users.keys(),credits.keys())

        datas=[]
        for card in cards:
            for trade in trades:
                if card["incardcd"]==trade["cardcd"]:
                    datas.append({"userid":card["userid"],"syssn":card["syssn"],"cardcd":card["cardcd"],"incardcd":card["incardcd"]})
        return datas

@register_case
class CancelTradePercent(Case):
    def __init__(self,*args,**kwargs):
        super(CancelTradePercent,self).__init__(*args,**kwargs)

        self.cnt=int(self.cnt)

    def get_this_start_time(self):
        return (self._now-datetime.timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")

    def get_this_end_time(self):
        return self.get_today()

    def get_this_today(self):
        return self.get_today()

    def get_real_time(self):
        return (self._now-datetime.timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")

    def get_trade_count(self):
        sql="select userid,COUNT(*) as cnt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' GROUP BY userid order by userid" % (self.get_this_start_time(),self.get_this_end_time())
        return {trade["userid"]:trade["cnt"] for trade in self.trade_db.query(sql)}

    def get_cancel_trade_count(self):
        sql="select userid,COUNT(*) as cnt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='201000' and cancel=0 GROUP BY userid order by userid" % (self.get_this_start_time(),self.get_this_end_time())
        return {trade["userid"]:trade["cnt"] for trade in self.trade_db.query(sql)}

    def search(self,sql=''):
        data=[]
        trades=self.get_trade_count()
        cancel_trades=self.get_cancel_trade_count()
        for trade in cancel_trades:
            if trades[trade]>2:
                data.append({
                    "userid":trade,
                    "cnt":trades[trade],
                    "cancel_cnt":cancel_trades[trade],
                    "parcent":round(float(cancel_trades[trade])/float(trades[trade]),4)
                })

        data=sorted(data,lambda a,b:cmp(a["parcent"],b["parcent"]),reverse=True)
        return data[:self.cnt]