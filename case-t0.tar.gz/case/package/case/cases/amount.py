# -*- coding: utf-8 -*-

from ..case import register_case,Case
import datetime
import json

@register_case
class CumulativeCredit(Case):
    '''
    同一张卡在（check_days）周期内，成功信用卡交易金额满足（amt_abov )，如果据上次生成案件未超（check_days）但交易金额再次大于（amt_abov）则再次生成案件。
    参数： check_days 天数;amt_abov  交易金额
    备注： sumamt  交易金额;daysumamt 当日交易金额;carcd 卡号
    '''

    def __init__(self,*args,**kwargs):
        super(CumulativeCredit,self).__init__(*args,**kwargs)

        self.check_days=int(self.check_days)
        self.amt_abov=int(self.amt_abov)*100

    def get_new_trades(self):
        sql = "select userid from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' group by userid" % (self.get_this_start_time(),self.get_this_end_time())
        users=self.trade_db.query(sql)
        sql = "select cardcd from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' group by cardcd" % (self.get_this_start_time(),self.get_this_end_time())
        cards=self.trade_db.query(sql)
        return users,cards

    def get_joined(self,sql=''):
        sql = "select userid,info,jointime from case_cases where jointime>='%s' and casetype='%s'" % ((datetime.date.today() - datetime.timedelta(days=self.check_days)).strftime("%Y-%m-%d %H:%M:%S"), self.casetype)
        ret = self.risk2_db.query(sql,master=True)
        joined = {}
        for _r in ret:
            try:
                joined[(_r['userid'], json.loads(_r['info'])['data']['cardcd'])] = _r['jointime']
            except:
                pass
        self._joined=ret
        return joined

    def check_last_cumula(self,joined,userid, cardcd):
        if (userid,cardcd) not in joined:return True
        last_time = joined[(userid, cardcd)]
        sql = "select USERID,CARDCD,sum(TXAMT) as sumamt from record_@1 where busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) AND SYSDTM>'%s' and userid=%s and cardcd='%s' GROUP BY CARDCD,USERID HAVING sumamt>=%s ORDER BY userid" % (last_time, userid, cardcd,self.amt_abov)
        ret = self.trade_db.query(sql)
        return bool(ret)

    def search(self,sql=''):
        users,cards=self.get_new_trades()
        if not users or not cards: return []
        sql = "select USERID,CARDCD,sum(TXAMT) as sumamt from record_@1 where busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) AND SYSDTM>='%s' and userid in (%s) and cardcd in (%s) GROUP BY CARDCD,USERID HAVING sumamt>=%s ORDER BY userid" \
            % ((datetime.date.today() - datetime.timedelta(days=self.check_days)).strftime("%Y-%m-%d %H:%M:%S"), ",".join([str(user["userid"]) for user in users]),",".join(["'"+card["cardcd"]+"'" for card in cards]),self.amt_abov)
        credits = self.trade_db.query(sql)

        joined=self.get_joined()
        datas=[{"userid":c["userid"],'sumamt':c["sumamt"],'cardcd': c['cardcd']} for c in credits if self.check_last_cumula(joined,c['userid'], c['cardcd'])]
        day_sumamts=self.get_day_sumamt([data["cardcd"] for data in datas])
        for data in datas:
            try:
                day_sumamt={"daysumamt":day_sumamts[data["cardcd"]]}
            except KeyError:
                day_sumamt={"daysumamt":0}
            data.update(day_sumamt)
        return datas

    def get_day_sumamt(self,cards):
        if not cards:return {}
        sql = "select cardcd,sum(TXAMT) as sumamt from record_@1 where  busicd='000000' and retcd='0000' and cancel=0 and cardcd in (%s) AND SYSDTM>='%s' AND SYSDTM<'%s' group by cardcd" % (",".join(["'"+card+"'" for card in cards]),self.get_this_today(),self.get_this_end_time())
        return {trade["cardcd"]:trade["sumamt"] for trade in self.trade_db.query(sql)}

