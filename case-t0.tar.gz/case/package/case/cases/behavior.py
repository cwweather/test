# -*- coding: utf-8 -*-

from ..case import register_case,Case
import datetime
import settings
from core.oceandriver import Driver
from utils import Enum

@register_case
class CardbinTimeBreak(Case):
    """
    商户在（break_time）分钟内，累积完成（break_count）笔以上同卡bin即卡号前6位交易
    参数：break_time 爆发时间;break_cnt 交易次数;break_amt 交易金额
    因子配置：[{"name":"c_type","descript":"C端判断类型（0同卡bin，1同卡（同账户））"},{"name":"card_type","descript":"卡类型（0所有卡，1借记卡，2信用卡）"},{"name":"break_time","descript":"触发时间（分钟）"},{"name":"break_cnt","descript":"触发次数"},{"name":"break_amt","descript":"触发交易额总额（元）"}]
    """
    CARD_TYPE = Enum(
        ALL=(0, u'所有卡类型'),
        DEBIT=(1, u'借记卡'),
        CREDIT=(2, u'信用卡'),
    )

    #C端判断类型
    C_TYPE = Enum(
        CARDBIN=(0, u"同卡bin"),
        CARD=(1, u"同卡（同账户）")
    )

    def __init__(self, *args, **kwargs):
        super(CardbinTimeBreak, self).__init__(*args, **kwargs)
        if not self.card_type:
            self.card_type = "0"
        self.card_type = int(self.card_type)
        self.c_type = int(self.c_type)
        self.break_time = int(self.break_time)
        self.break_cnt = int(self.break_cnt)
        self.break_amt = int(self.break_amt)
        self.has_syssn = True
        try:
            self.t0 = self.t0
        except:
            self.t0 = 0
        self.core_db=Driver(settings.db.core)

    def get_group_users(self):
        if self.t0:
            sql = "select userid from profile where settle_flag=2"
            t0_users = self.core_db.query(sql)
            sql = ",".join([str(user["userid"]) for user in t0_users])
            return "userid in (" + sql + ") and"
        else:
            return ""

    def get_card_type(self):
        if self.card_type==self.CARD_TYPE.ALL:
            return ''
        elif self.card_type==self.CARD_TYPE.DEBIT:
            return "and cardtp='01'"
        elif self.card_type==self.CARD_TYPE.CREDIT:
            return "and cardtp='02'"
        return ''

    def get_trades(self):
        """
        获取这些商户在开始运行时间前后指定时间内的交易
        """
        sql = "select userid,syssn,sysdtm,txamt,cardcd from record_@1 where %s sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' %s order by userid, sysdtm" % (
            self.get_group_users(),
            (self.time.get_start()-datetime.timedelta(minutes=self.break_time)).strftime("%Y-%m-%d %H:%M:%S"),
            self.time.get_start().strftime("%Y-%m-%d %H:%M:%S"),
            self.get_card_type())
        trades = self.trade_db.query(sql)
        return trades

    def search(self,sql=''):
        """
        根据条件（break_time, break_cnt, break_amt）查询交易
        """
        trades = self.get_trades()
        result = []
        userid = ""
        userid_tradelist = []
        if trades:
            for trade in trades:
                u = trade["userid"]
                if userid != u:
                    if userid:
                        r = self.is_break_time(userid, userid_tradelist)
                        if r:
                            result.append(r)
                    userid = u
                    userid_tradelist = [trade]
                else:
                    userid_tradelist.append(trade)
            r = self.is_break_time(userid, userid_tradelist)
            if r:
                result.append(r)
        return result

    def is_break_time(self, userid, trades):
        break_trades = []
        break_sumamt = 0
        card = ""
        syssn = ""
        for i in range(0, len(trades)):
            bt = [trades[i]]
            sumamt = int(trades[i]["txamt"])
            for j in range(i+1, len(trades)):
                if self.before(trades[i]["sysdtm"], trades[j]["sysdtm"], self.break_time):
                    if trades[i]["cardcd"] != trades[j]["cardcd"]:
                        ifsamecard = False
                    else:
                        ifsamecard = True
                    if self.c_type == self.C_TYPE.CARDBIN:
                        cardi = trades[i]["cardcd"][:6]
                        cardj = trades[j]["cardcd"][:6]
                    else:
                        cardi = trades[i]["cardcd"]
                        cardj = trades[j]["cardcd"]
                    if cardi == cardj:
                        if not ifsamecard or self.c_type == self.C_TYPE.CARD:
                            bt.append(trades[j])
                            sumamt += int(trades[j]["txamt"])
                else:
                    break
            if len(bt) >= self.break_cnt and sumamt >= self.break_amt:
                break_trades = bt
                break_sumamt = sumamt
                card = cardi
                syssn = trades[j]["syssn"]
                break
        if break_trades:
            if self.c_type == self.C_TYPE.CARDBIN:
                return {"userid": userid, "syssn": syssn, "cnt": len(break_trades), "sumamt": break_sumamt, "cardbin": card}
            else:
                return {"userid": userid, "syssn": syssn, "cnt": len(break_trades), "sumamt": break_sumamt, "cardcd": card}
        else:
            return None

    def before(self,t1,t2,gap):
        if not gap:
            return t1.split(" ")[0] == t2.split(" ")[0]
        if datetime.datetime.strptime(t2, "%Y-%m-%d %H:%M:%S")-datetime.datetime.strptime(t1,"%Y-%m-%d %H:%M:%S")<datetime.timedelta(minutes=gap):
            #t1在t2之前gap分钟
            return True
        else:
            return False


@register_case
class SameCardTimeBreak(CardbinTimeBreak):
    def __init__(self, *args, **kwargs):
        """
        {"name":"sameuser","descript":"是否可同商户（0不同商户，1可同商户）"}
        """
        super(SameCardTimeBreak, self).__init__(*args, **kwargs)
        try:
            self.sameuser = int(self.sameuser)
        except:
            self.sameuser = 1
        self.t0 = 1

    def get_groupby(self):
        if self.sameuser:
            return " group by cardcd "
        else:
            return " group by cardcd, userid"

    def search(self, sql=''):
        """
        根据条件（break_time, break_cnt, break_amt）查询同卡交易
        """
        sql = "select count(cardcd) as tradecount,sum(txamt) as sumtxamt,cardcd,userid,syssn,sysdtm,txamt from record_@1 where %s sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' %s %s having count(cardcd)>=%s and sum(txamt)>=%s" % (
            self.get_group_users(),
            (self.time.get_start()-datetime.timedelta(minutes=self.break_time)).strftime("%Y-%m-%d %H:%M:%S"),
            self.time.get_start().strftime("%Y-%m-%d %H:%M:%S"),
            self.get_card_type(),
            self.get_groupby(),
            self.break_cnt,
            self.break_amt,
        )
        trades = self.trade_db.query(sql)
        return trades

    def is_break_time(self, cardcd, trades):
        break_trades = []
        break_sumamt = 0
        card = ""
        syssn = ""
        for i in range(0, len(trades)):
            bt = [trades[i]]
            sumamt = int(trades[i]["txamt"])
            for j in range(i+1, len(trades)):
                if self.before(trades[i]["sysdtm"], trades[j]["sysdtm"], self.break_time):
                    if trades[i]["cardcd"] != trades[j]["cardcd"]:
                        ifsamecard = False
                    else:
                        ifsamecard = True
                        cardi = trades[i]["cardcd"]
                        cardj = trades[j]["cardcd"]
                    if cardi == cardj:
                        if not ifsamecard or self.c_type == self.C_TYPE.CARD:
                            bt.append(trades[j])
                            sumamt += int(trades[j]["txamt"])
                else:
                    break
            if len(bt) >= self.break_cnt and sumamt >= self.break_amt:
                break_trades = bt
                break_sumamt = sumamt
                card = cardi
                syssn = trades[j]["syssn"]
                break
        if break_trades:
            if self.c_type == self.C_TYPE.CARDBIN:
                return {"userid": cardcd, "syssn": syssn, "cnt": len(break_trades), "sumamt": break_sumamt, "cardbin": card}
            else:
                return {"userid": cardcd, "syssn": syssn, "cnt": len(break_trades), "sumamt": break_sumamt, "cardcd": card}
        else:
            return None


@register_case
class BlackCardbinTimeBreak(CardbinTimeBreak):
    def __init__(self, *args, **kwargs):
        super(BlackCardbinTimeBreak, self).__init__(*args, **kwargs)
        self.t0 = 1

    def end_data(self, datas, ends):
        if "userid" in ends:
            user = ends["userid"]
            if self.get(self.risk2_db,"user_black_white",["userid"],"userid=%s" % user):
                self.update_black("user_black_white","user_type","userid",str(user))
            else:
                self.add_black("user_black_white",
                               {
                                   "userid": user,
                                   "user_type": 1,
                                   "start_time": self._now.strftime("%Y-%m-%d %H:%M:%S"),
                                   "end_time": "2029-12-30 23:59:59",
                                   "source":u"规则处理"
                               })
            self.add_op_log(user)
        return datas

    def add_black(self, tablse, dict):
        names = dict.keys()+["ctime"]
        data = dict.values()+[self._now.strftime("%Y-%m-%d %H:%M:%S")]
        sql = "insert into %s (%s) values(%s)" % (tablse, ",".join(names), ("%s,"*len(data))[:-1])
        self.risk2_db.insert(sql, [data])

    def update_black(self, table, type, where, value):
        sql = "update %s set %s=1,start_time='%s',end_time='2029-12-30 23:59:59',source='规则处理' where %s=%s " % (
            table,
            type,
            self._now.strftime("%Y-%m-%d %H:%M:%S"),
            where,
            str(value))
        self.risk2_db.update(sql)

    def add_op_log(self,user):
        sql="insert into mis_oplog (admin_id,user_id,op_type,`action`,detail,notify_type) values(10000,%s,3,'商户黑白名单','操作[商户进入黑名单]商户ID[%s]来源[规则处理]',0)" % (user,user)
        self.mis_db.insert(sql)

@register_case
class ShortTimeBreak(Case):
    '''
    商户在（break_time）分钟内，累积完成（break_count）笔以上(card_type)交易
    参数：break_time 爆发时间;break_count 交易次数;card_type 卡类型; ret 1成功交易，0失败交易
    备注：cnt 交易次数;sumamt 交易总额
    [{"name":"ret","descript":"是否成功交易（成功1 失败0）"},{"name":"biztype","descript":"交易类型"},{"name":"card_type","descript":"卡类型"},{"name":"break_time","descript":"时间"},{"name":"break_count","descript":"次数"},{"name":"txamt","descript":"单笔交易额"},{"name":"sumamt","descript":"交易额总额"},{"name":"maxamt","descript":"最大交易额总额0或者没有表示无限"}]
    '''

    CARD_TYPE=Enum(
        ALL=(0,u'所有卡类型'),
        DEBIT=(1,u'借记卡'),
        CREDIT=(2,u'信用卡'),
        DIFF=(3,u'不同卡'),
    )

    def __init__(self,*args,**kwargs):
        super(ShortTimeBreak,self).__init__(*args,**kwargs)

        self.card_type=int(self.card_type)
        self.break_time=int(self.break_time)
        self.break_count=int(self.break_count)
        self.txamt=int(self.txamt)*100
        self.sumamt=int(self.sumamt)*100
        try:
            self.maxamt = int(self.maxamt)*100
        except:
            self.maxamt = 0
        try:
            self.ret = int(self.ret)
        except:
            self.ret = 1
        try:
            self.biztype = self.biztype
        except:
            self.biztype = "000000"
        try:
            self.t0 = self.t0
        except:
            self.t0 = 1
        self.core_db = Driver(settings.db.core)

    def get_group_users(self):
        if self.t0:
            sql = "select userid from profile where settle_flag=2"
            t0_users = self.core_db.query(sql)
            sql = ",".join([str(user["userid"]) for user in t0_users])
            return "userid in (" + sql + ") and"
        else:
            return ""

    def get_starttime(self):
        if self.break_time:
            return (self.time.get_start()-datetime.timedelta(minutes=self.break_time)).strftime("%Y-%m-%d %H:%M:%S")
        else:
            return self.time.get_start().strftime("%Y-%m-%d 00:00:00")

    def get_card_type(self):
        if self.card_type==self.CARD_TYPE.ALL:
            return ''
        elif self.card_type==self.CARD_TYPE.DEBIT:
            return "and cardtp='01'"
        elif self.card_type==self.CARD_TYPE.CREDIT:
            return "and cardtp='02'"
        elif self.card_type==self.CARD_TYPE.DIFF:
            return "group by cardcd"
        return ''

    def get_joined(self,sql=''):
        if not sql:
            sql = "select userid,info from case_cases where jointime>='%s' and casetype='%s'" % (self.get_this_today(), self.casetype)
        return self.risk2_db.query(sql,master=True)

    def get_ret(self):
        if self.ret:
            return "retcd='0000'"
        else:
            return "retcd!='0000'"

    def get_biztype(self):
        return self.biztype

    def get_users(self):
        sql = "select userid,sum(txamt) as sumamt from record_@1 where %s sysdtm>='%s' and sysdtm<'%s' and busicd='%s' and %s and cancel=0 group by userid having sumamt>%s %s order by userid" % (
            self.get_group_users(),
            self.get_starttime(),
            self.time.get_start().strftime("%Y-%m-%d %H:%M:%S"),
            self.get_biztype(),
            self.get_ret(),
            self.sumamt,
            "" if not self.maxamt else " and sumamt<=%s" % self.maxamt
        )
        return [user["userid"] for user in self.trade_db.query(sql)]

    def get_sumamt(self,trades):
        sumamt=0
        for trade in trades:
            sumamt+=trade["txamt"]
        return sumamt

    def than_time(self, t1, t2, than):
        if not than:
            return t1.split(" ")[0] == t2.split(" ")[0]
        return datetime.datetime.strptime(t2,"%Y-%m-%d %H:%M:%S")-datetime.datetime.strptime(t1,"%Y-%m-%d %H:%M:%S")<datetime.timedelta(minutes=than)

    def is_break_time(self, userid, trades):
        break_trades = []
        for i in range(0,len(trades)):
            bt = [trades[i]]
            for j in range(i+1, len(trades)):
                if self.than_time(trades[i]["sysdtm"], trades[j]["sysdtm"], self.break_time):
                    bt.append(trades[j])
                else:
                    break
            if len(bt) > len(break_trades):
                break_trades = bt
        is_break = True if len(break_trades) >= self.break_count else False
        return is_break, len(break_trades), self.get_sumamt(break_trades) if is_break else None

    def get_txamt(self):
        if self.txamt<=0:
            return ''
        return "and txamt>%s" % self.txamt

    def search(self,sql=''):
        users=self.get_users()
        if not users:return []
        sql = "select userid,sysdtm,txamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and userid in (%s) and %s and busicd='%s' %s and cancel=0 %s order by sysdtm" % (
            self.get_starttime(),
            self.time.get_start().strftime("%Y-%m-%d %H:%M:%S"),
            ",".join([str(user) for user in users]),
            self.get_ret(),
            self.get_biztype(),
            self.get_txamt(),
            self.get_card_type())
        trades = self.trade_db.query(sql)

        user_trades={}
        for trade in trades:
            if trade["userid"] not in user_trades:
                user_trades[trade["userid"]]=[]
            user_trades[trade["userid"]].append(trade)
        user_trades={ut:user_trades[ut] for ut in user_trades if len(user_trades[ut])>=self.break_count}

        break_trades=[]
        for user_trade in user_trades:
            is_break,cnt,sumamt=self.is_break_time(user_trade,user_trades[user_trade])
            if is_break and sumamt>=self.sumamt:
                break_trades.append({"userid":user_trade,"cnt":cnt,"sumamt":sumamt})
        return break_trades

@register_case
class KeepCreditCard(Case):
    '''
    单信用卡在连续（month）月内（包括当月），每月累积交易金额超过（large_amt）。
    参数：month 月数;large_amt 交易金额
    备注：sumamt 交易总额;daysumamt 当日交易额;cardcd 卡号
    '''

    def __init__(self,*args,**kwargs):
        super(KeepCreditCard,self).__init__(*args,**kwargs)

        self.month=int(self.month)
        self.large_amt=int(self.large_amt)*100

    def get_cards(self):
        sql="select userid,cardcd from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) group by cardcd,userid" % (self.get_this_start_time(),self.get_this_end_time())
        return {card["cardcd"]:card["userid"] for card in self.trade_db.query(sql)}

    def search(self,sql=''):
        cards=self.get_cards()
        all_cards = []
        for _m in xrange(self.month):
            trades=[]
            for i in range(0,len(cards),1000):
                sql = "select cardcd,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and  sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and cardcd in (%s) group by cardcd HAVING sumamt>=%s" % ((self.time.get_start() - datetime.timedelta(days=30*(_m+1))).strftime("%Y-%m-%d %H:%M:%S"), (self.time.get_start() - datetime.timedelta(days=30*_m)).strftime("%Y-%m-%d %H:%M:%S"), ",".join(["'"+card+"'" for card in cards.keys()[i:i+1000]]),self.large_amt)
                trades.extend(self.trade_db.query(sql))
            all_cards.append(trades)

        three_month_cards = set([ _c['cardcd'] for _c in all_cards[0]])
        for _t in xrange(self.month-1):
            three_month_cards &= set([ _c['cardcd'] for _c in all_cards[_t+1]])

        if not three_month_cards:return []
        three_month_cards=list(three_month_cards)

        sumamts=self.get_sumamt(three_month_cards)
        day_sumamts=self.get_day_sumamt(three_month_cards)

        return [{"userid":cards[card],"sumamt":sumamts.get(card,0),"daysumamt":day_sumamts.get(card,0),'cardcd': card} for card in three_month_cards]

    def get_sumamt(self,cards):
        sql = "select cardcd,sum(TXAMT) as sumamt from record_@1 where  busicd='000000' and retcd='0000' and cancel=0 and cardcd in (%s) AND SYSDTM>='%s' group by cardcd" % (",".join(["'"+card+"'" for card in cards]),(self.time.get_start() - datetime.timedelta(days=30*(self.month))).strftime("%Y-%m-%d %H:%M:%S"))
        return {trade["cardcd"]:trade["sumamt"] for trade in self.trade_db.query(sql)}

    def get_day_sumamt(self,cards):
        sql = "select cardcd,sum(TXAMT) as sumamt from record_@1 where  busicd='000000' and retcd='0000' and cancel=0 and cardcd in (%s) AND SYSDTM>='%s' and SYSDTM<'%s' group by cardcd" % (",".join(["'"+card+"'" for card in cards]),self.get_this_today(),self.get_this_end_time())
        return {trade["cardcd"]:trade["sumamt"] for trade in self.trade_db.query(sql)}

@register_case
class DirectSameCard(Case):
    '''
    某卡在商户处成功交易金额满足（current_amt），且该卡在其他商户处(days)天内成功交易的金额满足（other_amt）
    参数：current_amt 当前商户交易额;other_amt 其他商户交易额;days 天数
    备注：txamt 交易额;users 商户;cardcd 卡号
    '''
    has_syssn = True

    def __init__(self,*args,**kwargs):
        super(DirectSameCard,self).__init__(*args,**kwargs)

        self.days=int(self.days)
        self.current_amt=int(self.current_amt)*100
        self.other_amt=int(self.other_amt)*100
        self.other_cnt=int(self.other_cnt)

    def get_sumamts(self,cards):
        if not cards:return []
        sql = "SELECT USERID,cardcd,count(*) as cnt,sum(TXAMT) as SUMAMT from record_@1 WHERE CARDCD in (%s) and SYSDTM>='%s' and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) and txamt>=%s GROUP BY USERID,cardcd having cnt>=%s order by userid" % (",".join(["'"+card+"'" for card in cards]), (self.time.get_start()-datetime.timedelta(days=self.days)).strftime("%Y-%m-%d 00:00:00"),self.other_amt,self.other_cnt)
        return self.trade_db.query(sql)

    def get_others(self,sumamts,card,userid):
        users=[]
        for s in sumamts:
            if card==s["cardcd"] and userid!=s["userid"]:
                users.append(s["userid"])
        return list(set(users))

    def search(self,sql=''):
        sql = "SELECT USERID,CARDCD,TXAMT,SYSSN from record_@1 WHERE SYSDTM>='%s' and SYSDTM<'%s' and busicd='000000' and retcd='0000' and cancel=0 and txamt>=%s and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null)" % (self.get_this_start_time(),self.get_this_end_time(),self.current_amt)
        trades = self.trade_db.query(sql)
        sumamts=self.get_sumamts(list({trade["cardcd"] for trade in trades}))
        datas = []
        for _t in trades:
            users=self.get_others(sumamts,_t['cardcd'], _t['userid'])
            if users:
                datas.append({"userid":_t["userid"],"syssn":_t["syssn"],'txamt': _t['txamt'], 'users': users, 'cardcd': _t['cardcd']})
        return datas

@register_case
class RiskUserErr(Case):
    '''
    在BI系统RISK_USER_ERROR表中出现的商户ID，发sql
    参数：
    备注：balance_inquiry 余额查询占比;pin_err 余额查询PIN错误占比+交易PIN错误占比;danger_card 高位卡交易占比
    '''
    run_interval = None
    run_time = ["20**-**-** 00:00:00 1",]

    def __init__(self,*args,**kwargs):
        super(RiskUserErr,self).__init__(*args,**kwargs)

        self.oracle_db=Driver(settings.db.oracle)

    def search(self,sql=''):
        sql = u'''SELECT "商户ID" AS userid,"余额查询占比" as balance_inquiry,"余额查询PIN错误占比"+"交易PIN错误占比" AS pin_err,"高位卡交易占比" AS danger_card FROM RISK_USER_ERROR'''
        return self.oracle_db.query(sql)
