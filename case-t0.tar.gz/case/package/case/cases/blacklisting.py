# -*- coding: utf-8 -*-

from ..case import register_case,Case
from utils import Enum
from cache.risk import RiskRestrict
from cache.user import Profile
from base.geo import get_distance
import datetime
from ityfoon import Tyfoon
from ityfoon.ttypes import CriminalType, Punishment, Penalty
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol
from settings import TYFOON_IP, TYFOON_PORT
from logger import log

@register_case
class RiskBlacklisting(Case):
    """
    根据风控标记和其他条件生成案件
    与RiskToCase区别：忽略指定时间内出现指定 的次数
    参数：
        txamtMin：单笔金额范围小值
        txamtMax：单笔金额范围大值（当两值相同忽略该条件）
        sumamtMin：总额金额范围小值
        sumamtMax：总额金额范围大值（当两值相同忽略该条件）
        cardtp：卡片类型，1－借记卡；2－信用卡；3－忽略卡类型
        payresp：返回码（成功交易或者拒绝的交易）
        hitedrules：警告集
        riskret：拒绝集
    备注：
        cnt：命中次数
        sumamt：命中总金额
        hitedrules 规则集
    """
    has_syssn = True

    def __init__(self, *args, **kwargs):
        super(RiskBlacklisting, self).__init__(*args, **kwargs)
        self.txamtMin = int(self.txamtMin)*100
        self.txamtMax = int(self.txamtMax)*100
        self.sumamtMin = int(self.sumamtMin)*100
        self.sumamtMax = int(self.sumamtMax)*100
        self.cardtp = str(self.cardtp).strip()
        self.payresp = str(self.payresp).strip().split(",")
        self.hitedrules = str(self.hitedrules).strip().split(",")
        self.riskret = str(self.riskret).strip().split(",")
        self.listingcarddays = int(self.listingcarddays)
        self.cardblackorwhite = str(self.cardblackorwhite)
        self.listingcardreason = str(self.listingcardreason)
        self.listinguserdays = int(self.listinguserdays)
        self.userblackorwhite = str(self.userblackorwhite)
        self.listinguserreason = str(self.listinguserreason)
        self.operatorid = str(self.operatorid)

        self.txamtMin = 0
        self.txamtMax = 0
        self.sumamtMin = 0
        self.sumamtMax = 0
        self.cardtp = "3"
        self.payresp = ""
        self.hitedrules = ""
        self.riskret = "HRK002"
        self.listingcarddays = 180
        self.cardblackorwhite = "black"
        self.listingcardreason = "高危码规则自动拉黑"
        self.listinguserdays = 0
        self.userblackorwhite = ""
        self.listinguserreason = ""
        self.operatorid = "54383"

        # thrift启动
        transport = TSocket.TSocket(TYFOON_IP, TYFOON_PORT)
        transport = TTransport.TBufferedTransport(transport)
        protocol = TBinaryProtocol.TBinaryProtocol(transport)
        self.client = Tyfoon.Client(protocol)

        if self.cardblackorwhite == "white":
            self.cardblackorwhite = 2
        else:
            self.cardblackorwhite = 1

        if self.userblackorwhite == "white":
            self.userblackorwhite = 2
        else:
            self.userblackorwhite = 1

    def get_cardtp(self):
        if self.cardtp or self.cardtp == "3":
            return "and cardtp='%s'" % self.cardtp
        else:
            return ""

    def get_payresp(self):
        if not self.payresp or self.payresp == ['']:
            return ''
        payresp = ""
        if self.payresp[0][0] == '-':
            self.payresp[0] = self.payresp[0][1:]
            for h in self.payresp:
                payresp += "payresp not like '%"+str(h)+"%' and "
        else:
            for h in self.payresp:
                payresp += "payresp like '%"+str(h)+"%'  or "

        payresp = payresp.strip()
        if payresp:
            payresp = "and ("+payresp[:-3]+")"
        return payresp

    def get_hitedrules(self):
        if not self.hitedrules or self.hitedrules == ['']:
            return ''
        hitedrules = ""
        if self.hitedrules[0][0] == '-':
            self.hitedrules[0] = self.hitedrules[0][1:]
            for h in self.hitedrules:
                hitedrules += "hitedrules not like '%"+str(h)+"%' and "
        else:
            for h in self.hitedrules:
                hitedrules += "hitedrules like '%"+str(h)+"%'  or "

        hitedrules = hitedrules.strip()
        if hitedrules:
            hitedrules = "and ("+hitedrules[:-3]+")"
        return hitedrules

    def get_riskret(self):
        if not self.riskret or self.riskret==['']:return ''
        riskret=""
        if self.riskret[0][0]=='-':
            self.riskret[0]=self.riskret[0][1:]
            for r in self.riskret:
                riskret+="riskret not like '%"+str(r)+"%' and "
        else:
            for r in self.riskret:
                riskret+="riskret like '%"+str(r)+"%'  or "

        riskret=riskret.strip()
        if riskret:
            riskret="and ("+riskret[:-3]+")"
        return riskret

    def get_txamt(self):
        if self.txamtMin < 0 or self.txamtMax < 0 or self.txamtMin == self.txamtMax:
            return ""
        return "and txamt>=%s and txamt<=%s" % (self.txamtMin, self.txamtMax)

    def check_sumamt(self,datas):
        results=[]
        for data in datas:
            if data["sumamt"] >= self.sumamtMin and data["sumamt"] <= self.sumamtMax:
                results.append(data)
        return results

    def search(self,sql=''):
        sql = "select userid, cardcd, count(1) as cnt, sum(txamt) as sumamt from trade_record where sysdtm>='%s' and sysdtm<'%s' %s %s %s %s %s group by userid" % (self.get_this_start_time(),self.get_this_end_time(),self.get_cardtp(),self.get_payresp(),self.get_hitedrules(),self.get_riskret(),self.get_txamt())
        datas = self.risk2_db.query(sql)

        if not datas:
            return datas
        if self.sumamtMax > 0 and self.sumamtMax != self.sumamtMin:
            datas = self.check_sumamt(datas)

        return datas

    def end_data(self, datas, ends):
        #卡拉黑天数不为0，开始拉卡
        if self.listingcarddays != 0:
            cards = [_t["cardcd"] for _t in ends]
            self.listingcard(cards, self.operatorid, self.cardblackorwhite, self.listingcarddays, self.listingcardreason)
        if self.listinguserdays != 0:
            userids = [_t["userid"] for _t in ends]
            self.listinguser(userids, self.operatorid, self.userblackorwhite, self.listinguserdays, self.listinguserreason)
        return datas

    def black(self,black_trades):
        if not black_trades:return
        self.to_black_card({_t["cardcd"]:_t["userid"] for _t in black_trades})
        self.to_black_user([_t["userid"] for _t in black_trades])

    def listingcard(self, cards, operatorid, cardblackorwhite, listingcarddays, listingcardreason):

        p = Punishment(criminalids=cards, criminaltype=int(CriminalType.CARD), operator=operatorid, penalty=Penalty.BLACKLISTING, reason=listingcardreason)
        p.param = "{'blackorwhite':'%s','starttime':'%s','endtime':'%s','source':'%s'}" % (
            cardblackorwhite,
            datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            (datetime.datetime.now() + datetime.timedelta(days=listingcarddays)).strftime('%Y-%m-%d %H:%M:%S'),
            listingcardreason
        )
        result = self.client.execute(p)
        if result.respcd != 0:
            log.warn("blacklisting cards fail! data: %s" % str(result.data))
        else:
            log.info("%s cards were listed" % len(p))

    def listinguser(self, userids, operatorid, userblackorwhite, listinguserdays, listinguserreason):
        punishments = []
        for userid in userids:
            p = Punishment(criminalid=userid, criminaltype=int(CriminalType.MERCHANT), operator=operatorid, penalty=Penalty.BLACKLISTING, reason=listinguserreason)
            p.param = "{'blackorwhite':'%s','starttime':'%s','endtime':'%s','source':'%s'}" % (
                userblackorwhite,
                datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                (datetime.datetime.now() + datetime.timedelta(days=listinguserdays)).strftime('%Y-%m-%d %H:%M:%S'),
                listinguserreason
            )
            punishments.append(p)
        result = self.client.execute(punishments)
        if result.respcd != 0:
            log.warn("blacklisting user fail! data: %s" % str(result.data))
        else:
            log.info("%s users were listed" % len(punishments))


