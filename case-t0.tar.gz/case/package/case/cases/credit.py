# -*- coding: utf-8 -*-

from ..case import register_case,Case
from cache.risk import RiskRestrict

@register_case
class MonCredit(Case):
    '''
    商户当月信用卡刷卡总额超过(abov_amt)，且信用卡刷卡总额除以商户信用卡月限大于(min_ratio)。
    参数：abov_amt 交易金额;min_ratio 比率
    备注：sumamt 交易总额;ratio 比率
    '''

    def __init__(self,*args,**kwargs):
        super(MonCredit,self).__init__(*args,**kwargs)

        self.abov_amt=int(self.abov_amt)*100
        self.min_ratio=float(self.min_ratio)
        self.user_restrict=None

    def get_joined(self,sql=''):
        sql="select userid,info from case_cases where jointime>='%s' and casetype='%s'" % (self.get_this_today(), self.casetype)
        return super(type(self),self).get_joined(sql)

    def get_user_restrict(self):
        return { r['userid']: r['rcv_credit_month_amt'] for r in RiskRestrict() if (r['userid']>=10000 and r['rcv_credit_month_amt']>=self.abov_amt) }

    def search(self,sql=''):
        self.user_restrict=self.get_user_restrict()
        sql = "select userid,sum(txamt) as sumamt from record_@1 where SYSDTM>='%s' and SYSDTM<'%s' and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) GROUP BY USERID HAVING sumamt>1000000" % (self.get_this_today(),self.get_this_end_time())
        return self.trade_db.query(sql)

    def filter(self,case):
        case['ratio']=float(case['sumamt']) / float(self.user_restrict.get(case['userid'], 999999999999999))
        return case['ratio']>=self.min_ratio
