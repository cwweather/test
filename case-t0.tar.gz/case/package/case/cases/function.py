# -*- coding: utf-8 -*-

import datetime
from logger import log
from ..case import register_case,Case
import settings
from core.oceandriver import Driver
from base.sms import send_sms

@register_case
class LargeCertificate(Case):
    '''
    商户大额交易凭证
    参数：
    备注：picurl 图片地址;comments 评论;haschecked 是否确认
    '''
    has_syssn = True
    table_name='certificate'

    def search(self,sql=''):
        fengxiang_db=Driver(settings.db.fengxiang)
        trades=fengxiang_db.query_objects(self.table_name,where='{"type":"大额凭证","upload_time":{"$gte":"%s","$lt":"%s"}}' % (self.get_this_start_time(),self.get_this_end_time()))
        results=[]
        for trade in trades:
            results.append({"syssn":trade["syssn"],"picurl":trade["certificatePic"],"comments":trade["comments"],"userid":int(trade["userid"]),"haschecked":trade["has_checked"]})
        return results

@register_case
class DelayTimeOut(Case):
    '''
    商户被延迟未打款超过(days)天
    参数：days 天数
    备注：expectdate 应打款日期;memo 备注
    '''
    run_interval = None
    run_time = ["20**-**-** 00:00:00 *",]

    def __init__(self,*args,**kwargs):
        super(DelayTimeOut,self).__init__(*args,**kwargs)

        self.days=int(self.days)
        self.settle_db=Driver(settings.db.settle)

    def search(self,sql=''):
        sql="select userid,expectdate,memo from debit_paychnl where (status=3 or isdelay=1) and expectdate<'%s'" % (self.time.get_start()-datetime.timedelta(days=self.days)).strftime("%Y-%m-%d 00:00:00")
        return self.settle_db.query(sql)

@register_case
class FilterScore(Case):
    '''
    每日商户评分低于（score）的商户
    参数：score 分数;unique 是否可重复
    备注：score 分数;time 时间
    '''
    run_interval = None
    run_time = ["20**-**-** 08:00:00 *",]

    def __init__(self,*args,**kwargs):
        super(FilterScore,self).__init__(*args,**kwargs)

        self.score=int(self.score)
        self.unique=bool(int(self.unique))

    def get_none_interval(self):
        interval=1
        weekday=self._now.weekday()
        if weekday==6:
            interval=2
        elif weekday==0:
            interval=3
        return interval

    def get_this_start_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days)).strftime("%Y-%m-%d 00:00:00")

    def get_this_end_time(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days-1)).strftime("%Y-%m-%d 00:00:00")

    def get_this_today(self):
        return (self.time.get_start()-datetime.timedelta(days=self.days)).strftime('%Y-%m-%d 00:00:00')


    def get_sumamts(self,users):
        if not users:return {}
        sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and userid in (%s) group by userid order by userid" % (self.get_this_start_time(),self.get_this_end_time(),",".join(["'"+str(user)+"'" for user in users]))
        return {trade["userid"]:trade["sumamt"] for trade in self.trade_db.query(sql)}

    def search(self,sql=''):
        sql="select userid,score,`time` from merchant_score where `time`>='%s' and `time`<'%s' and score<=%s order by userid" % (self.get_this_today(),self.get_this_end_time(),self.score)
        users=self.risk2_db.query(sql)

        if users and self.unique:
            sql="select userid from case_cases where jointime>='%s' and jointime<'%s' and userid in (%s) group by userid order by userid" % (self.get_this_today(),self.get_this_end_time(),",".join(["'"+str(user["userid"])+"'" for user in users]))
            has_users=[user["userid"] for user in self.risk2_db.query(sql,master=True)]

            users=[user for user in users if user["userid"] not in has_users]
        self.sumamts=self.get_sumamts([user["userid"] for user in users])
        return users

    def filter(self,case):
        case["sumamt"]=self.sumamts[case["userid"]] if case["userid"] in self.sumamts else 0
        return True

@register_case
class DebitNight(Case):
    '''
    商户晚(start_hour)点至次日凌晨(end_hour)点间借记卡单笔交易大于（txamt)同时12小时内借记卡查询数不小于（debit_inquire）且（days）天内借记卡交易占比大于（debit_ratio）
    参数：txamt 借记卡单笔交易额;start_hour 开始时间;end_hour 结束时间;days 天数;debit_ratio 借记卡交易占比;debit_inquire 最小查询数
    备注：sumamt 交易总额;debit_sumamt 借记卡交易总额
    '''

    def __init__(self,*args,**kwargs):
        super(DebitNight,self).__init__(*args,**kwargs)

        self.txamt=int(self.txamt)*100
        self.start_hour=int(self.start_hour)
        self.end_hour=int(self.end_hour)
        self.days=int(self.days)
        self.debit_ratio=float(self.debit_ratio)
        self.debit_inquire=int(self.debit_inquire)

    def get_this_start_time(self):
        '''
        返回上次案件开始运行时间。
        '''
        if self._now.hour==self.start_hour and self._now.minute==0:
            return self._now.strftime("%Y-%m-%d "+("%02d" % self.start_hour)+":00:00")
        return super(DebitNight,self).get_this_start_time()

    def run(self):
        if self.start_hour>self.end_hour:
            self.end_hour+=24
        now=self._now.hour+24 if self.end_hour>24 and self._now.hour<self.end_hour-24 else self._now.hour
        if now<self.start_hour or now>self.end_hour:
            return False
        return super(DebitNight,self).run()

    def get_users(self):
        sql="select userid from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and cardtp='01' and txamt>%s group by userid order by userid" % (self.get_this_start_time(),self.get_this_end_time(),self.txamt)
        return [user["userid"] for user in self.trade_db.query(sql)]

    def get_inquire(self,users):
        if not users:return []
        sql="select userid,count(*) as cnt from record_@1 where sysdtm>='%s' and busicd='300000' and retcd='0000' and cancel=0 and cardtp='01' and userid in (%s) group by userid having cnt>=%s order by userid " % ((self.time.get_start()-datetime.timedelta(hours=12)).strftime("%Y-%m-%d %H:%M:%S"),",".join(["'"+str(user)+"'" for user in users]),self.debit_inquire)
        return [user["userid"] for user in self.trade_db.query(sql)]

    def get_sumamts(self,users):
        if not users:return {}
        sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s'  and userid in (%s) and busicd='000000' and retcd='0000' and cancel=0 and txamt>2000 group by userid order by userid" % ((self.time.get_start()-datetime.timedelta(days=self.days)).strftime("%Y-%m-%d 00:00:00"),",".join(["'"+str(user)+"'" for user in users]))
        return {user["userid"]:user["sumamt"] for user in self.trade_db.query(sql)}

    def get_debit_sumamts(self,users):
        if not users:return {}
        sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and userid in (%s) and busicd='000000' and retcd='0000' and cancel=0 and cardtp='01' and txamt>2000 group by userid order by userid" % ((self.time.get_start()-datetime.timedelta(days=self.days)).strftime("%Y-%m-%d 00:00:00"),",".join(["'"+str(user)+"'" for user in users]))
        return {user["userid"]:user["sumamt"] for user in self.trade_db.query(sql)}

    def search(self,sql=''):
        users=self.get_users()
        users=self.get_inquire(users)
        if not users:return []
        sumamts=self.get_sumamts(users)
        debit_sumamts=self.get_debit_sumamts(users)
        return [{"userid":user,"sumamt":sumamts[user],"debit_sumamt":debit_sumamts[user]} for user in users if debit_sumamts[user]/sumamts[user]>self.debit_ratio]

@register_case
class FilterRetcd(Case):
    '''
    特定交易码发短信
    参数：retcd 交易返回码;msg_tpl 短信模板id
    备注：
    '''
    def __init__(self,*args,**kwargs):
        super(FilterRetcd,self).__init__(*args,**kwargs)

        self.retcd=str(self.retcd).strip()
        self.msg_tpl=int(self.msg_tpl)

        self.core_db=Driver(settings.db.core)

    def run(self):
        log.info("%s start" % self.name)
        users=self.get_trades()
        self.send_sms(users)
        log.info("%s end" % self.name)
        return True

    def get_retcds(self):
        retcds=self.retcd.split(",")
        return ",".join(["'"+retcd+"'" for retcd in retcds])

    def get_trades(self):
        sql="select userid from record_@1 where sysdtm>='%s' and sysdtm<'%s' and retcd in (%s) group by userid order by userid" % (self.get_this_start_time(),self.get_this_end_time(),self.get_retcds())
        return [user["userid"] for user in self.trade_db.query(sql)]

    def send_sms(self,users):
        if not users:return
        sql="select smstext from case_smstemplate where id=%s" % self.msg_tpl
        tpl=self.risk2_db.query(sql)[0]["smstext"]
        sql="select id,username from auth_user where id in (%s) order by id" % ",".join([str(user) for user in users])
        phones=[user["username"] for user in self.core_db.query(sql)]
        send_sms(",".join(phones),tpl)
        log.info("send sms:%s,%s" % (users,tpl))
