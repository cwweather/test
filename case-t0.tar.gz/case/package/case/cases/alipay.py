# -*- coding: utf-8 -*-

import datetime
from ..case import register_case,Case

@register_case
class AlipayTradeControl(Case):
    '''
    支付宝支付交易控制
    '''

    def __init__(self, *args, **kwargs):
        '''
        初始化
        '''
        super(AlipayTradeControl, self).__init__(*args, **kwargs)

        self.cnt = int(self.cnt)
        self.has_lonlat = bool(int(self.has_lonlat))
        self.timegap = int(self.timegap)

    def get_has_lonlat(self):
        '''
        是否比对地理位置
        '''
        if self.has_lonlat:
            return ', longitude, latitude'
        return ''

    def get_timegap(self):
        '''
        获取时间间隔（分钟）
        '''
        if self.timegap:
            return (self._now-datetime.timedelta(minutes=self.timegap)).strftime("%Y-%m-%d %H:%M:%S")
        return self.get_this_today()

    def search(self,sql=''):
        '''
        返回指定时间段内，地理位置相同(可选)的一定数量的交易
        '''
        sql = "select userid, count(*) as cnt,sum(txamt) as sumamt %s from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='800101' and retcd='0000' and cancel=0 group by userid %s having cnt>=%s order by userid" % (self.get_has_lonlat(),self.get_timegap(),self.get_this_end_time(),self.get_has_lonlat(),self.cnt)
        data=self.trade_db.query(sql)
        result = []
        if self.has_lonlat and data:
            for d in data:
                if d['longitude'] and d['latitude']:
                    result.append(d)
        return result

