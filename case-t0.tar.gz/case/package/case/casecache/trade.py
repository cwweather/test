# -*- coding: utf-8 -*-
#14-2-24

import datetime
from driver import Driver
from cache import ExpiredCache,ExpiredCacheData
import settings

class NinetyDayActivityUserData(ExpiredCacheData):
    def __init__(self,*args,**kwargs):
        super(NinetyDayActivityUserData,self).__init__(*args,**kwargs)
        self._compose=False
        self._current_time=datetime.datetime.now()

    def check(self):
        if not self._time or self._time.day!=datetime.datetime.now().day:
            self.load()
            self._time=datetime.datetime.now()

    def load(self):
        sql="select userid from record_@1 where sysdtm>='%s' and busicd='000000' and retcd='0000' and cancel=0 group by userid order by userid" % (datetime.datetime.now()-datetime.timedelta(days=90)).strftime("%Y-%m-%d 00:00:00")
        self._current_time=datetime.datetime.now()
        self._data=Driver(settings.db.trade).query(sql)
        self._compose=False

    def refresh(self):
        sql="select userid from record_@1 where sysdtm>='%s' and busicd='000000' and retcd='0000' and cancel=0" % self._current_time.strftime("%Y-%m-%d %H:%M:%S")
        self._current_time=datetime.datetime.now()
        return Driver(settings.db.trade).query(sql)

    def get(self):
        self.check()
        if self._compose:
            users=self.refresh()
            for user in users:
                self._data[user["userid"]]=True
        return (self._compose,self._data)

    def set(self,data):
        self._compose,self._data=data

class NinetyDayActivityUser(ExpiredCache):
    Data = NinetyDayActivityUserData
    def __init__(self,*args,**kwargs):
        super(NinetyDayActivityUser,self).__init__(*args,**kwargs)
        self._users=None

    def compose(self):
        if not self._users:
            compose,datas=self.get()
            if not compose:
                datas={data["userid"]:True for data in datas}
                self.set((True,datas))
            self._users=datas

    def __iter__(self):
        self.compose()
        for user in self._users:
            yield user
        raise StopIteration

    def __getitem__(self, userid):
        self.compose()
        return self._users[userid]

    def __contains__(self, userid):
        self.compose()
        return userid in self._users