# -*- coding: utf-8 -*-

import json
import datetime
from factor import FactorList

class RuleItem(object):
    '''
    案件规则。
    '''
    TIME_INTERVAL={"year":365*24*60*60,"month":30*24*60*60,"day":24*60*60,"hour":60*60,"minute":60,"second":1,"week":7*24*60*60}

    def __init__(self,rule,start,end):
        self._r=rule
        self._factors=[]
        self.init_attr(rule)
        self.load()

        self._time=RuleTime(start,end)

    def init_attr(self,rule):
        for name,value in rule.items():
            if name=="params":
                setattr(self,"_"+name,json.loads(value))
            else:
                setattr(self,"_"+name,value)

    def get_interval(self):
        if self._interval[0]:
            return self.TIME_INTERVAL[self._interval[1][self._interval[1].keys()[0]][:-1]]
        else:
            time="second"
            for i in self._interval[1]:
                for tv in self.TIME_INTERVAL:
                    if i==tv and self.TIME_INTERVAL[i]>self.TIME_INTERVAL[time]:
                        time=i
            return self.TIME_INTERVAL[time]

    def load(self):
        self._factors=FactorList(self,self._params)

    def get_time(self):
        return self._time

    def __iter__(self):
        for factor in self._factors:
            yield factor
        raise StopIteration

    def __getitem__(self,index):
        return self._factors[index]

    def __getstate__(self):
        return (self._r,self._time._start,self._time._end)

    def __setstate__(self,state):
        rule,start,end=state
        self._r=rule
        self._factors=[]
        self.init_attr(rule)
        self.load()

        self._time=RuleTime(start,end)

class RuleTime(object):
    def __init__(self,start,end):
        self._start=start
        self._end=end

    def get_start(self):
        return self._start

    def get_end(self):
        return self._end

    def get_start_format(self):
        return self._start.strftime("%Y-%m-%d %H:%M:%S")

    def get_end_format(self):
        return self._end.strftime("%Y-%m-%d %H:%M:%S")
