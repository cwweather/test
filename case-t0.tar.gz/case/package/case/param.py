# -*- coding: utf-8 -*-

class ParamItem(object):
    def __init__(self,rule,factor,param):
        self._rule=rule
        self._factor=factor
        self._p=param

        self.name=""
        self.expression=""
        self.type=""
        self.value=""

        self.load()

    def load(self):
        if "name" in self._p:
            self.name=self._p["name"]
        if "expression" in self._p:
            self.expression=self._p["expression"]
        if "type" in self._p:
            self.type=self._p["type"]
        if "value" in self._p:
            self.value=self._p["value"]

    def __unicode__(self):
        return self.expression+self.value

    def __str__(self):
        return self.expression+self.value

    def __int__(self):
        return int(self.value)

    def __float__(self):
        return float(self.value)

class Param(object):
    '''
    单个因子的所有配置参数。
    '''
    def __init__(self,rule,factor,params):
        self._rule=rule
        self._factor=factor
        self._params=[]

        self.load(params)

    def load(self,params):
        for param in params:
            self._params.append(ParamItem(self._rule,self._factor,param))

    def __iter__(self):
        for param in self._params:
            yield param
        raise StopIteration

    def __getitem__(self,name):
        for param in self._params:
            if param.name==name:
                return param
        raise KeyError("%s not find" % name)

    def items(self):
        all=[]
        for p in self:
            all.append((p,self[p]))
        return tuple(all)
