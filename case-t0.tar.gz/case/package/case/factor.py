# -*- coding: utf-8 -*-
from case import ALL_CASE

import settings
from param import Param

from cache.case import Factor
class NoneFactorError(Exception):pass

class FactorItem(object):
    '''
    案件规则中的一个因子。
    '''
    def __init__(self,rule,factor):
        self._rule=rule
        self._factor=None
        self._params=[]
        self._factor_case=None

        self.load(factor)

    def load(self,factor):
        self.load_factor(factor)
        self.load_param(factor)
        self.load_factor_case()

    def load_factor(self,factor):
        factors=Factor()
        if int(factor["factor"]) in factors:
            self._factor=factors[int(factor["factor"])]
            self.factor_id=self._factor["factorid"]
            self.factor_name=self._factor["name"]

    def load_param(self,factor):
        self._params=Param(self._rule,self,factor["params"])

    def load_factor_case(self):
        '''通过因子名获取因子实例'''
        if self.factor_name in settings.case.factor:
            name=settings.case.factor[self.factor_name]
        else:
            name=self.factor_name
        for c in ALL_CASE:
            n=c.name if c.name else c.__name__
            if name==n:
                self._factor_case=c
                return c
        raise NoneFactorError

    def get_instance(self):
        return self._factor_case(self._rule,self._rule.get_time(),self.load_args())

    def load_args(self):
        args={
            "casetype":self._rule._case_id
        }
        for param in self._params:
            args[param.name]=param
        return args

class FactorList(object):
    '''
    单个案件规则下的所有因子。
    '''
    def __init__(self,rule,factors):
        self._rule=rule
        self._factors=factors

        self.load()

    def load(self):
        fs=[]
        for factor in self._factors:
            fs.append(FactorItem(self._rule,factor))
        self._factors=fs

    def __iter__(self):
        for factor in self._factors:
            yield factor
        raise StopIteration

    def __getitem__(self,index):
        return self._factors[index]
