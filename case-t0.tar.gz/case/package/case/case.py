# -*- coding: utf-8 -*-

'''
案件运行流程：
    1、使用run方法启动。
    2、根据案件配置的运行周期判断当前是否能运行，如果能运行则继续否则退出。
    3、调用search参数据库中搜索数据。
    4、调用filter对搜索到的数据进行过滤，看是否符合规则。
    5、调用format格式化搜索到的数据，选择案件内容。
    6、插入新案件。
'''

import os
import sys
import datetime
import json

import settings
from logger import log
from core.oceandriver import Driver
from cache.qfpay import Staff


class Case(object):
    '''
    所有案件的基类,制定案件运行流程，定义案件时重载该类实现新案件。

    整个案件流程为：
    def search(self,sql='') 搜索数据，返回list，每项是一条记录
    def filter(self,case) 判断每条数据是否是合法的案件，是则返回True否则返回False
    def fotmat(self,case) 对找到的案件进行格式化，生成案件内容，返回userid,info,syssn
    '''
    name=None
    priority=5
    method=2
    state=1
    period=0
    has_syssn=False

    def __init__(self,rule,time,args):
        self.rule=rule
        self.name=self.__class__.__name__
        self.time=time

        self._joined=None
        self._now=datetime.datetime.today()

        self.map_args(args)

        self.load_default_db()


    def load_default_db(self):
        self.risk2_db=Driver(settings.db.risk2)
        self.trade_db=Driver(settings.db.trade)

    def map_args(self,args):
        for name,value in args.items():
            setattr(self,name,value)

    def get_this_start_time(self):
        # 案件开始时间
        return self.time.get_start_format()

    def get_this_end_time(self):
        # 案件结束时间
        return self.time.get_end_format()

    def get_now(self):
        return self._now.strftime('%Y-%m-%d %H:%M:%S')

    def get_today(self):
        return self._now.strftime('%Y-%m-%d 00:00:00')

    def get_this_today(self):
        return self.time.get_start().strftime('%Y-%m-%d 00:00:00')

    def run(self):
        '''
        启动案件。
        '''
        log.info("%s start" % self.name)
        datas = self.get_data()
        self.add_data(datas)
        log.info("%s end" % self.name)
        return True

    def get_group_users(self):
        return []

    def get_real_time(self):
        return self.get_this_today()

    def get_data(self):
        datas=[]
        self.start_search()
        results=self.search()
        log.info("%s find all count: %s" % (self.name,len(results)))

        results=self.end_search(results)
        s_datas=[]
        for _c in results:
            if self.filter(_c):
                userid,data,syssn=self.format(_c)
                info=json.dumps(data)
                if self.has_joined(userid,info,syssn):
                    datas.append((userid,info,syssn))
                    s_datas.append(_c)
        datas=self.end_data(datas,s_datas)
        datas=self.fill_data(datas)
        return datas

    def fill_data(self,datas):
        now= self.get_now()
        cases=[]
        real_time=self.get_real_time()
        for data in datas:
            userid,info,syssn=data
            if self.has_syssn:
                cases.append([userid,self.casetype,self.priority,syssn,real_time,now,now,self.method,self.state,info])
            else:
                cases.append([userid,self.casetype,self.priority,None,real_time,now,now,self.method,self.state,info])
        return cases

    def start_search(self):
        pass

    def end_search(self,results):
        return results

    def end_data(self,datas,ends):
        return datas

    def add_data(self,datas):
        '''
        插入新案件。
        '''
        datas=self.filter_qfpay_staff(datas)
        from data import Data
        data=Data(self.rule,datas)
        data.store()
        if datas:
            from base import mail
            rule_name = self.rule._r["name"]
            case_id = self.rule._r["case_id"]
            out_type = self.rule._r["out_type"]
            rule_type = self.rule._r["type"]
            text = u"案件名称:{}\n案件ID:{}\n案件详情:\n".format(
                rule_name,
                str(case_id)
            )
            if rule_type == 12 or out_type == 4:
                mail.send_mail(
                    settings.MAIL_SERVER["name"],
                    settings.MAIL_ME,
                    settings.MAIL_TO,
                    "案件报警" + str(case_id),
                    text=text + str(datas),
                    server_user=settings.MAIL_SERVER["user"],
                    server_passwd=settings.MAIL_SERVER["passwd"]
                )

    def filter_qfpay_staff(self,datas):
        if not datas:return datas
        staff=Staff()
        return [data for data in datas if data[0] not in staff]

    def get_joined(self,sql=''):
        if not sql:
            sql = "select userid,info from case_cases where jointime>='%s' and casetype='%s'" % (self.get_this_today(), self.casetype)
        return self.risk2_db.query(sql,master=True) or []

    def has_joined(self,userid,info,syssn=None):
        '''
        判断新生成的案件是否有重复。
        '''
        if self._joined is None:
            self._joined=self.get_joined()
            log.info("%s this day add count: %s" % (self.name,len(self._joined)))
        return {"userid":userid,"info":info} not in self._joined

    def search(self,sql=''):
        if sql:
            return self.trade_db.query(sql) or []
        return []

    def filter(self,case):
        return True if case else False

    def format(self,case):
        if "userid" in case:
            userid=case["userid"]
            syssn=case["syssn"] if "syssn" in case else None
            info={"data":{_c.lower():case[_c] for _c in case if _c not in ["userid","syssn"]}}
            return userid,info,syssn
        return 0,{"data":{}},None


class ALL_CASE(object):
    def __init__(self):
        self._all_case=None

    def get_name(self,case):
        return case.name if case.name else case.__name__

    def append(self,case):
        self._all_case[self.get_name(case)]=case

    def __iter__(self):
        if self._all_case is None:
            self._all_case={}
            get_all_case()
        for case in self._all_case:
            yield self._all_case[case]
        raise StopIteration

    def __getitem__(self, name):
        return self._all_case[name]
ALL_CASE=ALL_CASE()

def register_case(case):
    '''
    装饰器，注册案件。
    '''
    ALL_CASE.append(case)
    return case

def get_all_case():
    '''
    搜索注册的案件。
    '''
    for case in os.listdir(settings.BASE_PATH+"package/case/cases/"):
        if case[-3:]=='.py' and case!='__init__.py':
            cases_name="package.case.cases."+case[:-3]
        elif case[-4:]=='.pyc' and case!='__init__.pyc':
            cases_name="package.case.cases."+case[:-4]
        elif os.path.isdir(settings.BASE_PATH+"package/case/cases/"+case):
            cases_name="package.case.cases."+case
        else:
            cases_name=None
        if cases_name and cases_name not in ALL_CASE:
            if cases_name in sys.modules:
                reload(sys.modules[cases_name])
            else:
                try:
                    __import__(cases_name)
                except ImportError:
                    log.error("import error "+cases_name)
    return ALL_CASE
