# -*- coding: utf-8 -*-
#14-2-24

from core.oceandriver import Driver
import settings

class Data(object):
    def __init__(self,rule,data):
        self._rule=rule
        self._data=data
        self._risk2_db=Driver(settings.db.risk2)

    def store(self):
        if not self._data:return
        sql= "insert into case_cases (userid, casetype, priority, syssn, `time`, jointime, modifytime, method, state, info) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        self._risk2_db.insert(sql, self._data)