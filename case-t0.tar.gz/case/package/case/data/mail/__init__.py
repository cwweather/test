# -*- coding: utf-8 -*-
#14-2-24

import json
import datetime
from cache import Cache
from base import mail
from cache.case import Rule
import settings

CASE_INFO_DESC = {
    'amt': u'金额',
    'cnt': u'笔数',
    'distance':u'距离',
    'apply_position':u'商户经营位置经纬度',
    'risk_index': u'风险分数',
    'sumamt': u'总额',
    'txamt': u'交易金额',
    'cardcd': u'卡号',
    'users': u'用户',
    'alluser': u'用户',
    'sysdtm': u'时间',
    'retcd': u'交易返回码',
    'trade_position': u'交易位置经纬度',
    'mobile': u'手机',
    'ratio': u'比率',
    'syssn': u'流水号',
    'hitedrules': u'触发规则',
    'risk_rule': u'风险规则',
    'desumamt':u'借记卡总额',
    'cresumamt':u'信用卡总额',
    'becnt':u'查询笔数',
    'picurl':u'图片',
    'idnumber':u'身份证好',
    "bussiness_addr":u'经营地址',
}

class Data(object):
    def __init__(self,rule,data):
        self._rule=rule
        self._data=data

        self._cache=Cache("case@data@mail")
        self.init()

    def init(self):
        if self._rule._case_id in settings.case.data_mail["case"]:
            self._mails=settings.case.data_mail["case"][self._rule._case_id]
        else:
            self._mails=settings.case.data_mail["default"]

    def check(self,mail_data):
        ret=datetime.datetime.now()-mail_data["time"]>datetime.timedelta(minutes=5)
        if ret:
            mail_data["time"]=datetime.datetime.now()
        return ret

    def send_mail(self,to,data):
        if not data:return
        mail.send_mail(
            settings.MAIL_SERVER["name"],
            settings.MAIL_ME,
            to,
            "案件测试数据",
            html=self.format(data),
            server_user=settings.MAIL_SERVER["user"],
            server_passwd=settings.MAIL_SERVER["passwd"]
        )

    def store(self):
        self._cache.lock()
        data=self._cache.get()
        if not data:data={}
        for mail in self._mails:
            if mail not in data:data[mail]={"time":datetime.datetime.now(),"data":[]}
            data[mail]['data'].extend(self._data)
            if self.check(data[mail]):
                self.send_mail(mail,data[mail]['data'])
                del data[mail]
        self._cache.set(data)
        self._cache.unlock()

    def get_case_names(self):
        return {rule["case_id"]:rule["name"] for rule in Rule()}

    def format(self,data):
        msg=u'''
        <style type="text/css">
            table{
                width: 100%;
                border-top: 1px solid #ddd;
                border-right: 1px solid #ddd;
                word-break: break-all;
                font-size: 14px;
                font-family: "Lucida Grande","DejaVu Sans","Bitstream Vera Sans",Verdana,Arial,sans-serif;
                color: #333;
            }

            th{
                border-left: 1px solid #ddd;
                border-bottom: 1px solid #ddd;
                color: #666;
                padding: 2px 5px;
            }

            td{
                border-left: 1px solid #ddd;
                border-bottom: 1px solid #ddd;
                padding: 8px;
            }

            a{
                color: #036;
                cursor: auto;
                text-decoration: none;
            }
        </style>
        <table>
            <thead>
                <tr>
                    <th>商户ID</th>
                    <th>案件类型</th>
                    <th>案件详情</th>
                    <th>加入时间</th>
                </tr>
            </thead>
            <tbody>
        '''

        case_names=self.get_case_names()
        for i in xrange(len(data)):
            d=data[i]
            msg+=u"                <tr%s>\n" % (u' style="background: #EDF3FE;" ' if i % 2==0 else '')
            msg+=u'                    <td><a href="http://mis.qfpay.com/admin/risk2/traderecord/?userid=%s">%s</a></td>\n' % (d[0],d[0])
            msg+=u"                    <td>%s</td>\n" % case_names.get(d[1],d[1])
            msg+=u"                    <td>%s</td>\n" % self.format_info(d[-1])
            msg+=u"                    <td>%s</td>\n" % d[-4]
            msg+=u"                </tr>\n"
        msg+=u"            </tbody>\n        </table>\n"
        return msg

    def format_info(self,info):
        try:data = json.loads(info)['data']
        except:data = {}

        info = u""
        for key in data:
            if key.find('amt') > -1:
                data[key] = "%.2f" % (int(data[key])/100)
            if key == 'cardcd':
                cards = ''
                for c in data[key].split(','):
                    card = c.strip()
                    if card:cards += '''<a href="http://mis.qfpay.com/admin/risk2/traderecord/?cardcd=%s">%s</a>, ''' % (card, card)
                data[key] = cards[:-2]
            info += '%s: %s, ' % (CASE_INFO_DESC.get(key, key), data[key])
        return info[:-2]