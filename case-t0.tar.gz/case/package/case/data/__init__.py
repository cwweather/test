# -*- coding: utf-8 -*-
#14-2-24

from processor import Task,add_task
from ..rule import RuleItem
import settings

class Data(object):
    def __init__(self,rule,data):
        self._rule=rule
        self._data=data

    def get_adapt(self,out_type='2'):
        adapt=__import__(settings.case.data.get(out_type,"log"),globals(),locals())
        return adapt.Data(self._rule,self._data)

    def start(self):
        adapt=self.get_adapt(str(self._rule._out_type))
        adapt.store()
        if str(self._rule._out_type)!='2':
            adapt=self.get_adapt()
            adapt.store()

    def store(self):
        task=Task(self.start)
        add_task(task)
