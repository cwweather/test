# -*- coding: utf-8 -*-
#14-2-24

import datetime
import settings

class Data(object):
    def __init__(self,rule,data):
        self._rule=rule
        self._data=data
        self._file_name=self.get_file_name()

    def get_file_name(self):
        if self._rule._case_id in settings.case.data_file["case"]:
            return settings.case.data_file["case"][str(self._rule._case_id)]+"case_data_"+str(self._rule._case_id)+"."+datetime.date.today().strftime("%Y-%m-%d")
        return settings.case.data_file["default"]+"case_data."+datetime.date.today().strftime("%Y-%m-%d")

    def store(self):
        with open(self._file_name,"a+") as f:
            for data in self._data:
                f.write(str(data))
                f.write("\n")