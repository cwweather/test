# -*- coding: utf-8 -*-
#14-2-24

from logger import log

class Data(object):
    def __init__(self,rule,data):
        self._rule=rule
        self._data=data

    def store(self):
        log.info("%s count:%s" % (self._rule._name,len(self._data)))
        log.info("%s data:%s" % (self._rule._name,self._data))