# -*- coding: utf-8 -*-

import datetime
import json
from base import vtraceback as traceback
from cache import Cache
from cache.case import Rule
from session import Session
from logger import log
from core.schprocessor import Plan,register,unregister
from core.oceandriver import Driver
from rule import RuleItem
from ..score.adapt import get_score
import settings

class Processor(object):
    '''
    运行所有案件规则。
    ：factor list
    :cases list
    '''
    def parse_interval(self,interval):
        try:
            interval=json.loads(interval)
        except:
            interval=(True,{"seconds":60})
        return interval

    def save_session(self,session,name,**kwargs):
        session.lock()
        rule_session=session[name]
        if rule_session is None:
            rule_session={}
        for key,value in kwargs.items():
            rule_session[key]=value
        session[name]=rule_session
        session.unlock()

    def run(self,time,rule):
        '''运行一条规则'''
        now=datetime.datetime.now()
        today=datetime.datetime(now.year,now.month,now.day)
        cache=Cache("registered_rule_cache")
        cache.lock()
        rule_cache=cache[rule["case_id"]]
        if not rule_cache or rule_cache.get("running"):
            log.warning("%s is running" % rule["name"])
            cache.unlock()
            return
        rule_cache['running']=True
        cache[rule["case_id"]]=rule_cache
        cache.unlock()

        session=Session("case")
        session_case=session[rule["case_id"]] or {}
        start_time=session_case.get("last_succed_time",None)
        start_time=(start_time if start_time.hour==0 and start_time.minute==0 else start_time-datetime.timedelta(minutes=2))  if start_time else today
        if not session_case.get("succed",False) and start_time<today:
            start_time=today

        self.save_session(session,rule["case_id"],last_run_time=now,succed=False)
        try:
            self.run_rule(RuleItem(rule,start_time,time))
            self.save_session(session,rule["case_id"],last_succed_time=time,succed=True)
        except:
            log.error("case rule error: %s",traceback.format_exc())
        finally:
            cache.lock()
            rule_cache=cache[rule["case_id"]]
            rule_cache['running']=False
            cache[rule["case_id"]]=rule_cache
            cache.unlock()

    def run_rule(self,rule):
        log.info("%s case start" % rule._name)
        for factor in rule:
            self.run_factor(factor)
        log.info("%s case end" % rule._name)

    def run_factor(self,factor):
        c=factor.get_instance()
        c.run()

    def get_cases(self,start,end):
        db=Driver(settings.db.risk2)
        sql="select id,userid,casetype from case_cases where jointime>='%s' and jointime<'%s'" % (start.strftime("%Y-%m-%d %H:%M:%S"),end.strftime("%Y-%m-%d %H:%M:%S"))
        return db.query(sql,master=True)

    def get_users(self,cases):
        history_cases=settings.score.history_cases
        users,history_users={},{}
        for case in cases:
            if case["casetype"] in history_cases:
                history_users[case["id"]]=case["userid"]
            else:
                users[case["id"]]=case["userid"]
        return users,history_users

    def update_case_score(self, time):
        pass

    def update_rule(self,time):
        cache=Cache("registered_rule_cache")
        rules=Rule()
        cache.lock()
        try:
            rule_caches=cache.get()
            for rule in rules:
                rule_cache=rule_caches.get(rule["case_id"])
                if rule_cache:
                    if rule["modifytime"]>rule_cache["rule"]["modifytime"]:
                        unregister(rule_cache["plan_id"])
                        plan=self.make_rule_plan(rule)
                        plan_id=register(plan)
                        rule_cache["plan_id"]=plan_id
                        rule_cache["rule"]=rule
                        cache[rule["case_id"]]=rule_cache
                        log.info("refresh register case rule:%s,%s" % (rule["case_id"],rule["name"]))
                    del rule_caches[rule["case_id"]]
                else:
                    plan=self.make_rule_plan(rule)
                    plan_id=register(plan)
                    cache[rule["case_id"]]={"running":False,"rule":rule,"plan_id":plan_id}
                    log.info("register case rule:%s,%s" % (rule["case_id"],rule["name"]))
            for rule_cache in rule_caches:
                unregister(rule_caches[rule_cache]["plan_id"])
                cache[rule_cache]=None
                log.info("unregister case rule:%s,%s" % (rule_caches[rule_cache]['rule']["case_id"],rule_caches[rule_cache]['rule']["name"]))
        finally:
            cache.unlock()

    def make_rule_plan(self,rule):
        rule["interval"]=self.parse_interval(rule["interval"])
        if rule["interval"][0]:
            plan=Plan.make_interval_plan(self.run,(rule,),**rule["interval"][1])
        else:
            plan=Plan.make_plan(self.run,(rule,),**rule["interval"][1])
        return plan

    def register(self):
        rules=Rule()
        rule_caches=Cache("registered_rule_cache")
        for rule in rules:
            plan=self.make_rule_plan(rule)
            plan_id=register(plan)
            rule_caches[rule["case_id"]]={"running":False,"rule":rule,"plan_id":plan_id}
            log.info("register case rule:%s,%s" % (rule["case_id"],rule["name"]))

        if settings.case.case_scope==2:
            #plan=Plan.make_interval_plan(self.update_case_score,seconds=60)
            #register(plan)
            pass

        plan=Plan.make_interval_plan(self.update_rule, seconds=30)
        register(plan)
