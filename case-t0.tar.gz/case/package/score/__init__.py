# -*- coding: utf-8 -*-

from core.schprocessor import Plan,register
from today import Today
from score import Score
import settings

def run(time):
    today=Today()
    today.run()
    score=Score()
    score.run()

try:
    disable=settings.score.disable
except:pass

def start():
    pass
