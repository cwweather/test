# -*- coding: utf-8 -*-
#13-12-16

from today import Today
from score import Score

class UserToday(Today):
    def __init__(self,users,*args,**kwargs):
        super(UserToday,self).__init__(*args,**kwargs)

        self._today_users=users

    def get_users(self):
        return self._today_users

    def run(self):
        if self._init:
            self.init_today()
        self.init_datas()
        self.get_weights()
        return self._weights

class UserScore(Score):
    def __init__(self,weights,*args,**kwargs):
        super(UserScore,self).__init__(*args,**kwargs)

        self._weights=weights

    def get_updates(self):
        if not self._weights:return []
        sql="select userid,y_history,y_today from merchant_score where userid in (%s) order by userid" % ",".join([str(user) for user in self._weights.keys()])
        updates={update["userid"]:update["y_history"] for update in self._risk2_db.query(sql,master=True)}
        return [{"userid":weight,"y_history":updates.get(weight,-2.9134),"y_today":self._weights[weight]} for weight in self._weights]

    def run(self):
        updates=self.get_updates()
        scores=self.get_scores(updates)
        return scores

def get_score(users,start_time=None,end_time=None):
    if not users:return {}
    today=UserToday(users,start_time,end_time,False)
    weights=today.run()
    score=UserScore(weights)
    return score.run()