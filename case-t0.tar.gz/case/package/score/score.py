# -*- coding: utf-8 -*-
#13-11-27

import sys
import datetime
import math
from core.oceandriver import Driver
from logger import log
import settings

class Score(object):
    def __init__(self):
        self._now=datetime.datetime.now()
        self._risk2_db=Driver(settings.db.risk2)

    def get_today(self):
        return self._now.strftime("%Y-%m-%d 00:00:00")

    def get_time(self):
        return self._now.strftime("%Y-%m-%d %H:%M:%S")

    def get_start_time(self):
        time=self._now-datetime.timedelta(minutes=10)
        return time.strftime("%Y-%m-%d %H:%M:00")

    def get_updates(self):
        sql="select userid,y_history,y_today from merchant_score where `time`<=updatetime order by userid"
        return self._risk2_db.query(sql,master=True)

    def Calculate_score(self,update):
        return round(1000*1/(1+math.exp(float(update["y_history"])+float(update["y_today"]))))

    def get_scores(self,updates):
        scores={}
        for update in updates:
            scores[update["userid"]]=self.Calculate_score(update)
        return scores

    def update_scores(self,scores):
        if not scores:return
        now=self.get_time()
        datas=[(scores[score],now,score) for score in scores]
        sql="update merchant_score set score_real=%s,`time`=%s where userid=%s"
        for i in range(int(len(datas)/5000)+1):
            ds=datas[i*5000:(i+1)*5000]
            if ds:
                self._risk2_db.update(sql,ds)
        log.info("score score update count: %s" % len(datas))

    def run(self):
        updates=self.get_updates()
        scores=self.get_scores(updates)
        self.update_scores(scores)

if __name__=="__main__":
    try:
        score=Score()
        score.run()
    except:
        from base import vtraceback as traceback
        log.error("score score error: %s" % traceback.format_exc())
