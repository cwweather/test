# -*- coding: utf-8 -*-
#13-11-27
from base import vtraceback as traceback
import sys
import datetime
from core.oceandriver import Driver
from logger import log
import settings
from session import Session

class Today(object):
    def __init__(self,start_time=None,end_time=None,init=None):
        self._now=datetime.datetime.now()
        self._session=Session("score")

        self._risk2_db=Driver(settings.db.risk2)
        self._trade_db=Driver(settings.db.trade)

        self._rules=settings.score.today_rules
        self._rules_datas={}
        self._weights={}
        self._users=[]

        self._start_time=start_time if start_time else self.get_start_time()
        self._end_time=end_time if end_time else self.get_time()
        self._init=init if init is not None else True if (self._now.hour==0 and self._now.minute==0) or (self._now.hour==6 and self._now.minute==20) else False

    def get_today(self):
        return self._start_time.split(" ")[0]

    def get_time(self):
        return self._now.strftime("%Y-%m-%d %H:%M:%S")

    def get_start_time(self):
        time=self._session["last_run_time"]
        if time:
            return (time-datetime.timedelta(minutes=3)).strftime("%Y-%m-%d %H:%M:%S")
        return self._now.strftime("%Y-%m-%d 00:00:00")

    def get_all_users(self):
        sql="select userid from merchant_score group by userid order by userid"
        return [user["userid"] for user in self._risk2_db.query(sql)]

    def get_users(self):
        sql="select userid  from record_@1 where sysdtm>='%s' and sysdtm<'%s' and busicd='000000' and retcd='0000' and cancel=0 and cardtp='02' and txamt>2000 group by userid order by userid" % (self._start_time,self._end_time)
        return [user["userid"] for user in self._trade_db.query(sql)]

    def get_credit_sumamt(self,users):
        if not users:return {}
        sumamts={}
        for i in range(len(users)/1000+1):
            sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>='%s' and sysdtm<='%s' and busicd='000000' and retcd='0000' and cancel=0 and cardtp='02' and txamt>2000 and userid in (%s) group by userid order by userid" % (self.get_today()+" 00:00:00",self.get_today()+" 23:59:59",",".join([str(userid) for userid in users[i*1000:(i+1)*1000]]))
            sumamts.update({user["userid"]:user["sumamt"] for user in self._trade_db.query(sql)})
        return sumamts

    def init_datas(self):
        self._users=self.get_users()
        for rule in self._rules:
            self._rules_datas[rule["name"]]=getattr(self,"get_"+rule["name"])(self._users)

    def get_rule_weight(self,rule,userid):
        data=self._rules_datas[rule["name"]][userid] if userid in self._rules_datas[rule["name"]] else 0
        for weight in rule["weights"]:
            if weight["start"] and int(data)<weight["start"]:
                continue
            if weight["end"] and int(data)>=weight["end"]:
                continue
            return weight["weight"]
        return 0

    def get_user_weight(self,userid):
        weight=0
        for rule in self._rules:
            weight+=self.get_rule_weight(rule,userid)
        return weight

    def get_weights(self):
        for user in self._users:
            self._weights[user]=self.get_user_weight(user)

    def update_y_today(self):
        if not self._weights:return
        now=self.get_time()
        datas=[(weight,self._weights[weight],now,now) for weight in self._weights]
        sql="insert into merchant_score (userid,score,score_real,y_history,y_today,time,updatetime) values(%s,1000,1000,-2.9134,%s,%s,%s) ON DUPLICATE KEY UPDATE y_today=values(y_today),updatetime=values(updatetime)"
        for i in range(int(len(datas)/5000)+1):
            ds=datas[i*5000:(i+1)*5000]
            if ds:
                self._risk2_db.update(sql,ds)
        log.info("score today update count: %s" % len(datas))

    def init_today(self):
        self._users=[0]
        for rule in self._rules:
            self._rules_datas[rule["name"]]={}
        self.get_weights()
        init_value=self._weights[0]
        self._rules_datas={}
        self._users=[]
        self._weights={}

        sql="update merchant_score set y_today=%s,updatetime='%s'" % (init_value,self.get_time())
        self._risk2_db.update(sql)
        log.info("score today inited")

    def run(self):
        try:
            if self._init:
                self.init_today()
            self.init_datas()
            self.get_weights()
            self.update_y_today()
            self._session["last_run_time"]=self._now
        except:
            log.error(traceback.format_exc())

if __name__=="__main__":
    try:
        start_time,end_time,init=None,None,None
        if len(sys.argv)==2:
            start_time=sys.argv[1]
        elif len(sys.argv)==3:
            start_time,end_time=sys.argv[1],sys.argv[2]
        elif len(sys.argv)==4:
            start_time,end_time,init=sys.argv[1],sys.argv[2],True if sys.argv[3].strip()=='True' else False
        today=Today(start_time,end_time,init)
        today.run()
    except:
        log.error("score today error: %s" % traceback.format_exc())
