# -*- coding: utf-8 -*-
#13-12-17

import re
from base import vtraceback as traceback
import math
import datetime
import settings
from core.oceandriver import Driver
from cache.user import Profile

class RiskAmt:
    def __init__(self,user_id, date):
        self.user_id = user_id
        self.date = date
        self.trade_db=Driver(settings.db.trade)

        self.user_info=self.get_user_info()
        self.mon_trade=self.get_trade_mon()
        self.day_trade=self.get_trade_day()
        self.cri_sum=self.get_cri_sum()
        self.deb_sum=self.get_deb_sum()
        self.user_sum ,self.hun_sum = self.get_user_sum()
        self.three_mon_trade=self.get_trade_three_mon()
        self.three_mon_ago_trade=self.get_trade_three_mon_ago()

    def str_to_datetime(self,str):
        return datetime.datetime.strptime(str,"%Y-%m-%d %H:%M:%S")

    def get_user_info(self):
        profile=Profile()
        return profile[self.user_id] or {}

    def if_new_user(self):
        jointime=self.user_info.get("jointime",None)
        if jointime and self.str_to_datetime(jointime)-datetime.datetime(year=self.date.year,month=self.date.month,day=self.date.day)<=datetime.timedelta(days=15):
            return 1
        return 0


    def get_average_amt(self):
        l = len(self.three_mon_trade)
        if not l:
            return 0
        else:
            return self.get_sum_amt(self.three_mon_trade) * 1.0 / l


    def get_day_expect(self):
        l = len(self.three_mon_trade)
        if not l:
            return 0
        else:
            return self.get_sum_amt(self.three_mon_trade) * 1.0 / len(set([ i['sysdtm'] for i in self.three_mon_trade]))


    def get_standard_dev(self, day_expect):
        l = len(self.three_mon_trade)
        if (not l) or (not day_expect):
            return 0

        sum_dev = 0
        for sysdtm in set([ i['sysdtm'] for i in self.three_mon_trade]):

            day_list = []
            for t in self.three_mon_trade:
                if t.get('sysdtm') == sysdtm:
                    day_list.append(t)

            day_dev = self.get_sum_amt(day_list) - day_expect
            sum_dev += day_dev * day_dev

        return math.sqrt(sum_dev)


    def mybin(self, n):
        if n == 0:
            return 1
        else:
            return n


    def get_amt_ratio_three_mon(self):
        today = datetime.date.today() - datetime.timedelta(days=1)
        yest_month_begin = datetime.date(today.year, today.month, 1)

        amt_ratio = {}
        for n in range(3):
            b = self.mybin(n)
            month_ago = yest_month_begin - datetime.timedelta(days=31*n + 2*int(b))
            month_begin = datetime.date(month_ago.year, month_ago.month, 1).strftime('%Y-%m-%d  00:00:00')
            month_end = re.sub("01 00:00:00", "31 23:59:59", month_begin)

            month_trades = []
            for t in self.three_mon_ago_trade:
                if t.get('sysdtm') >= month_begin and t.get('sysdtm') <= month_end:
                    month_trades.append(t)

            if month_trades:
                credit_trades = []
                for t in month_trades:
                    c = t.get('cardtp')
                    if c == '02' or c == '03' or c == '05' or c is None:
                        credit_trades.append(t)

                sum_trades = self.get_sum_amt(month_trades)
                sum_credit = self.get_sum_amt(credit_trades)
                sum_hun = self.get_sum_hun(month_trades)

                amt_ratio['cre_%s' % n] = sum_credit * 100.0 / sum_trades
                amt_ratio['hun_%s' % n] = sum_hun * 100.0 / sum_trades

            else:
                amt_ratio['cre_%s' % n] = 9999.99
                amt_ratio['hun_%s' % n] = 9999.99

        return amt_ratio


    def get_trade_three_mon_ago(self):
        today = datetime.date.today()
        month_begin = datetime.date(today.year, today.month, 1)
        month_ago = month_begin - datetime.timedelta(days=64)
        four_month_begin = datetime.date(month_ago.year, month_ago.month, 1).strftime('%Y-%m-%d 00:00:00')
        time_end = month_begin.strftime('%Y-%m-%d 00:00:00')

        sql = "select txamt,cardcd,cardtp,sysdtm from record_@1 where userid=%s and busicd='000000' and retcd='0000' and cancel=0 and sysdtm>='%s' and sysdtm<='%s'" % (self.user_id, four_month_begin, time_end)
        return self.trade_db.query(sql)


    def get_trade_three_mon(self):
        today = datetime.date.today()
        month_begin = datetime.date(today.year, today.month, 1)
        month_ago = month_begin - datetime.timedelta(days=32)
        three_month_begin = datetime.date(month_ago.year, month_ago.month, 1).strftime('%Y-%m-%d 00:00:00')
        time_end = today.strftime('%Y-%m-%d 23:59:59')

        sql = "select txamt,cardcd,cardtp,sysdtm from record_@1 where userid=%s and txamt>=1000 and busicd='000000' and retcd='0000' and cancel=0 and sysdtm>='%s' and sysdtm<='%s'" % (self.user_id, three_month_begin, time_end)
        return self.trade_db.query(sql)


    @classmethod
    def get_day_cri_sum(cls, db, uid):
        sql = "select sum(txamt) as sumamt from record_@1 where userid=%s and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null) and sysdtm>='%s'" % (uid, datetime.date.today().strftime('%Y-%m-%d 00:00:00'))
        return float((db.query(sql)[0]["sumamt"]) or 0)/100.0

    def get_untime(self):
        start_time = "00:00:00"
        end_time = "06:00:00"

        unnorm_trade = 0
        for trade in self.mon_trade:
            ttime = trade.get('sysdtm').split(" ")[1]
            if ttime > start_time and ttime < end_time:
                unnorm_trade += 1

        if not self.mon_trade:
            return u'该月无交易'
        else:
            return u'%.2f' % (unnorm_trade * 100.0 / len(self.mon_trade))


    def get_day_accum(self):
        card_dic = {}
        for trade in self.day_trade:
            if trade.get('cardcd') not in card_dic.keys():
                card_dic[trade.get('cardcd')] = 1
            else:
                card_dic[trade.get('cardcd')] += 1

        return len(self.day_trade) - len(card_dic)


    def get_skip_receipt(self):
        skip = 0
        for trade in self.mon_trade:
            if trade.get('contact') is None:
                skip += 1

        if self.mon_trade:
            return skip * 100.0 / len(self.mon_trade)
        else:
            return 9999.99


    def get_unusual_receipt(self):
        recive = 0
        problem = 0
        for trade in self.mon_trade:
            if trade.get('contact') is not None and '@' not in trade.get('contact'):
                recive += 1
                if self.if_problem_num(trade.get('contact')):
                    problem += 1

        if recive:
            return problem * 100.0 / recive
        else:
            return 9999.99


    def if_problem_num(self, mobile):
        try:
            user_mobile = self.user_info.get('mobile')
            if mobile == user_mobile:
                return 1
        except:
            traceback.print_exc()

        for n in range(10):
            if ('%s' % n) * 5 in mobile:
                return 1

        for temp in ['01234567890', '09876543210']:
            for n in range(7):
                if temp[n:n+5] in mobile:
                    return 1
        return 0


    def get_amt_concentration(self):
        amt_concentration = {}
        sum_amt = self.get_sum_amt(self.three_mon_trade)

        card_cd = []
        card_amt = []
        for card in set([i.get('cardcd') for i in self.three_mon_trade]):
            card_trade = []
            for c in self.three_mon_trade:
                if c.get('cardcd') == card:
                    card_trade.append(c)

            card_cd.append(card)
            card_amt.append(self.get_sum_amt(card_trade))

        for n in range(1,4):
            try:
                i = card_amt.index(max(card_amt))
                amt_concentration['amt_concent_%s' % n] = "%.2f %s" % (card_amt.pop(i)*100.0/sum_amt, card_cd.pop(i))
            except:
                amt_concentration['amt_concent_%s' % n] = "0.00 0"

        return amt_concentration


    def get_card_ch(self):
        card_dic = {}
        for trade in self.mon_trade:
            if trade.get('contact') is not None:

                if trade.get('contact') not in card_dic.keys():
                    card_dic[trade.get('contact')] = [trade.get('cardcd'),]
                else:
                    if trade.get('cardcd') not in card_dic[trade.get('contact')]:
                        card_dic[trade.get('contact')].append(trade.get('cardcd'))

        if card_dic:
            new_card = {}
            for each in card_dic.keys():
                if len(card_dic[each]) > 1:
                    new_card[each] = len(card_dic[each]) - 1
            if not len(new_card):
                return {'cardch': 0, 'ch_num':0}

            return {'cardch':max([new_card[i] for i in new_card.keys()]), 'ch_num':len(new_card)}
        else:
            return {'cardch': 0, 'ch_num':0}


    def get_per_deb_cre(self):
        if not (self.cri_sum + self.deb_sum):
            return u'该月无交易'
        else:
            return u'%.2f' % (self.cri_sum * 100.0 / (self.deb_sum + self.cri_sum))


    def get_per_hun(self):
        if not self.user_sum:
            return u'该月没有交易'
        else:
            return u'%.2f' % (self.hun_sum * 100.0 / self.user_sum)


    def get_user_sum(self):
        return self.get_sum_amt(self.mon_trade),self.get_sum_hun(self.mon_trade)


    def get_trade_day(self):
        sql = "select userid,sysdtm,cardcd,txamt from record_@1 where userid=%s and busicd='000000' and retcd='0000' and cancel=0 and sysdtm>='%s'" % (self.user_id,self.date.strftime("%Y-%m-%d 00:00:00"))
        return self.trade_db.query(sql)


    def get_trade_mon(self):
        sql = "select userid,sysdtm,cardcd,contact,txamt from record_%s where userid=%s and busicd='000000' and retcd='0000' and cancel=0" % (self.date.strftime("%Y%m"),self.user_id)
        return self.trade_db.query(sql)


    def get_ten_exp(self):
        if not self.day_trade:
            return {'ten_per': 0, 'ten_num': 0}
        step = 10
        len_trade = len(self.day_trade)

        n = 0
        exp_list = [0,]
        while(n < len_trade):
            if_ex = self.if_explode(step, self.day_trade, n)
            if if_ex.get('res'):
                exp_list.append(int(if_ex.get('leng')) / 3.0)
            n += int(if_ex.get('leng'))

        return {'ten_per': max(exp_list), 'ten_num': len(exp_list) - 1}


    def if_explode(self, step, trade_list, n):
        time_later = (self.str_to_datetime(trade_list[n].get('sysdtm'))+datetime.timedelta(seconds=60*step)).strftime("%Y-%m-%d %H:%M:%S")

        ex_list = []
        ex_list.append(trade_list[n])
        for t in trade_list[n+1:]:
            if t.get('sysdtm') <= time_later:
                ex_list.append(t)

        if len(ex_list) >= 3:
            return {'res':True, 'leng':len(ex_list)}
        else:
            return {'res':False, 'leng':1}


    def get_cri_sum(self):
        sql = "select sum(txamt) as sumamt from record_%s where userid=%s and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '02' or cardtp = '03' or cardtp = '05' or cardtp is null)" % (self.date.strftime("%Y%m"),self.user_id)
        return float((self.trade_db.query(sql)[0]["sumamt"]) or 0)/100.0


    def get_deb_sum(self):
        sql = "select sum(txamt) as sumamt from record_%s where userid=%s and busicd='000000' and retcd='0000' and cancel=0 and (cardtp = '01' or cardtp = '04')" % (self.date.strftime("%Y%m"),self.user_id)
        return float((self.trade_db.query(sql)[0]["sumamt"]) or 0)/100.0

    def get_sum_amt(self, trades):
        sum_amt = 0
        for t in trades:
            sum_amt = t.get('txamt', 0)
        return sum_amt/100.0


    def get_sum_hun(self, trades):
        sum_amt = 0
        for t in trades:
            amt = t.get('txamt', 0)
            if self.ifhun(amt):
                sum_amt += amt

        return sum_amt/100.0

    def ifhun(self, n):
        if n == 0:
            return False
        else:
            return n/10000 == int(math.ceil(n/10000.0))