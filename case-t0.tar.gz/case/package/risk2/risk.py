# -*- coding: utf-8 -*-
#13-12-17

import logging
from base import vtraceback as traceback
import json
import datetime
import settings
from core.oceandriver import Driver
from session import Session
from amt import RiskAmt

log=logging.getLogger()

class Risk:
    def __init__(self):
        self.trade_db = Driver(settings.db.trade)
        self.risk2_db = Driver(settings.db.risk2)
        self.used_user = []
        self.risk_data = []
        self.risk_model_list = []

        self._today=datetime.date.today()
        self._now=datetime.datetime.now()
        self._session=Session("risk2")

    def get_start_time(self):
        return (self._session["last_run_time"] or self._today).strftime("%Y-%m-%d %H:%M:%S")

    def get_used_user(self):
        sql = "select userid from record_@1 where sysdtm>='%s' and busicd='000000' and retcd='0000' and cancel=0 group by userid" % self.get_start_time()
        users=self.trade_db.query(sql)
        sql = "select userid from case_cases where jointime>='%s' and casetype='RISK001'" % self._now.strftime('%Y-%m-%d 00:00:00')
        case_users =[user["userid"] for user in self.risk2_db.query(sql,master=True)]
        self.used_user = [user["userid"] for user in users if user["userid"] not in case_users]

    def handle(self):
        for user in self.used_user:
            day_cri_sum_model = int(settings.risk2.model_check_1.get('argv1'))

            day_cri_sum = RiskAmt.get_day_cri_sum(self.trade_db, user)
            if day_cri_sum >= day_cri_sum_model:
                data = {}
                data['user_id'] = user
                data['day_cri_sum'] = day_cri_sum

                risk_amt = RiskAmt(user,self._today)
                data['per_deb_cri'] = risk_amt.get_per_deb_cre()
                data['per_hun'] = risk_amt.get_per_hun()

                ten_explode = risk_amt.get_ten_exp()
                data['ten_min_per'] = ten_explode.get('ten_per')
                data['ten_min_num'] = ten_explode.get('ten_num')
                data['day_accum'] = risk_amt.get_day_accum()
                card_ch = risk_amt.get_card_ch()
                data['mon_cardch'] = card_ch.get('cardch')
                data['mon_ch_num'] = card_ch.get('ch_num')
                data['per_untime'] = risk_amt.get_untime()
                data['average_amt'] = risk_amt.get_average_amt()
                data['day_expect'] = risk_amt.get_day_expect()
                data['standard_dev'] = risk_amt.get_standard_dev(data['day_expect'])
                data['if_new_user'] = risk_amt.if_new_user()
                data['skip_receipt'] = risk_amt.get_skip_receipt()
                data['unusual_receipt'] = risk_amt.get_unusual_receipt()
                amt_concentration = risk_amt.get_amt_concentration()
                data['amt_concent_1'] = amt_concentration.get('amt_concent_1')
                data['amt_concent_2'] = amt_concentration.get('amt_concent_2')
                data['amt_concent_3'] = amt_concentration.get('amt_concent_3')
                three_ratio = risk_amt.get_amt_ratio_three_mon()
                data['ratio_credit_0'] = three_ratio.get('cre_0')
                data['ratio_hun_0'] = three_ratio.get('hun_0')
                data['ratio_credit_1'] = three_ratio.get('cre_1')
                data['ratio_hun_1'] = three_ratio.get('hun_1')
                data['ratio_credit_2'] = three_ratio.get('cre_2')
                data['ratio_hun_2'] = three_ratio.get('hun_2')

                three_mon = self.three_mon_format(three_ratio)
                risk_model = {}

                risk_model['user_id'] = user
                risk_model['condition_1'] = self.get_condition_1(data['per_deb_cri'], data['per_hun'])
                additional_condition_1 = self.get_condition_1_3(data['per_deb_cri'])
                risk_model['condition_2'] = self.get_condition_2(data['ten_min_per'], data['ten_min_num'])
                risk_model['condition_3'] = self.get_condition_3(data['day_accum'])
                risk_model['condition_4'] = self.get_condition_4(data['mon_cardch'], data['mon_ch_num'])
                risk_model['condition_5'] = self.get_condition_5(data['per_untime'])
                risk_model['condition_6_1'] = self.get_condition_6_1(three_mon)
                risk_model['condition_6_2'] = self.get_condition_6_2(three_mon)
                risk_model['condition_6_3'] = self.get_condition_6_3(three_mon)
                risk_model['condition_7'] = self.get_condition_7(data['if_new_user'], risk_amt.get_sum_amt(risk_amt.day_trade), risk_amt.three_mon_trade)
                risk_model['condition_8'] = self.get_condition_8(data['unusual_receipt'], data['skip_receipt'])
                risk_model['condition_9'] = self.get_condition_9(amt_concentration )
                risk_model['condition_10'] = self.get_condition_10(amt_concentration )
                risk_model['condition_12'] = self.get_condition_12(data['average_amt'])
                risk_model['risk_index'] = risk_model['condition_1'] + risk_model['condition_2'] + risk_model['condition_3'] + risk_model['condition_4'] + risk_model['condition_5'] + risk_model['condition_6_1'] + risk_model['condition_6_2'] + risk_model['condition_6_3'] + risk_model['condition_7'] + risk_model['condition_8'] + risk_model['condition_9'] + additional_condition_1 + risk_model['condition_10'] + risk_model['condition_12']

                risk_index_model = float(settings.risk2.model_check_1.get('argv2'))
                if risk_model['risk_index'] >= risk_index_model:
                    self.risk_model_list.append(risk_model)

    def three_mon_format(self, oradata):
        if not isinstance(oradata,dict):
            return {}
        newdata = {}
        for k in oradata.keys():
            if oradata[k] < 200:
                newdata[k] = oradata[k]
            else:
                newdata[k] = 'incessant'
        return newdata


    def get_condition_1(self, per_deb_cri, per_hun):
        try:
            per_deb_cri = float(per_deb_cri)
            per_hun = float(per_hun)
            argv1 = float(settings.risk2.model_1_condition_1.get('argv1'))
            argv2 = float(settings.risk2.model_1_condition_1.get('argv2'))

            if per_deb_cri >= argv1 and per_hun >= argv2:
                return 2
            else:
                return 0
        except:
            return 0


    def get_condition_1_3(self, per_deb_cri):
        try:
            per_deb_cri = float(per_deb_cri)
            argv1 = float(settings.risk2.model_1_condition_1_3.get('argv1'))

            if per_deb_cri <= argv1:
                return -3
            else:
                return 0
        except:
            return 0


    def get_condition_2(self, ten_min_per, ten_min_num):
        try:
            ten_min_per = float(ten_min_per)
            ten_min_num = float(ten_min_num)
            argv1 = float(settings.risk2.model_1_condition_2.get('argv1'))
            argv2 = float(settings.risk2.model_1_condition_2.get('argv2'))

            if ten_min_per >= argv1 or ten_min_num >= argv2:
                return 1
            else:
                return 0
        except:
            return 0


    def get_condition_3(self, day_accum):
        try:
            day_accum = int(day_accum)
            argv1 = int(settings.risk2.model_1_condition_3.get('argv1'))

            if day_accum >= argv1:
                return 0.5
            else:
                return 0
        except:
            return 0


    def get_condition_4(self, mon_cardch, mon_ch_num):
        try:
            mon_cardch = int(mon_cardch)
            mon_ch_num = int(mon_ch_num)
            argv1 = float(settings.risk2.model_1_condition_4.get('argv1'))
            argv2 = float(settings.risk2.model_1_condition_4.get('argv2'))

            if mon_cardch >= argv1 or mon_ch_num >= argv2:
                return 1
            else:
                return 0
        except:
            return 0


    def get_condition_5(self, per_untime):
        try:
            per_untime = float(per_untime)
            argv1 = float(settings.risk2.model_1_condition_5.get('argv1'))

            if per_untime >= argv1:
                return 0.5
            else:
                return 0
        except:
            return 0


    def get_condition_6_1(self, three_mon_data):
        try:
            a1 = float(settings.risk2.model_1_condition_6_1.get('argv1'))
            a2 = float(settings.risk2.model_1_condition_6_1.get('argv2'))
            a3 = float(settings.risk2.model_1_condition_6_1.get('argv3'))

            c = 0
            for n in range(3):
                try:
                    c += int(float(three_mon_data.get('cre_%s' % n)) >= a1 and float(three_mon_data.get('hun_%s' % n)) >= a2)
                except:
                    pass

            if c >= a3:
                return 1
            else:
                return 0
        except:
            return 0


    def get_condition_6_2(self, three_mon_data):
        try:
            a1 = float(settings.risk2.model_1_condition_6_2.get('argv1'))
            a2 = float(settings.risk2.model_1_condition_6_2.get('argv2'))
            a3 = float(settings.risk2.model_1_condition_6_2.get('argv3'))

            c = 0
            for n in range(3):
                try:
                    c += int(float(three_mon_data.get('cre_%s' % n)) >= a1 and float(three_mon_data.get('hun_%s' % n)) >= a2)
                except:
                    pass

            if c == a3:
                return 0.5
            else:
                return 0
        except:
            return 0


    def get_condition_6_3(self, three_mon_data):
        try:
            a1 = float(settings.risk2.model_1_condition_6_3.get('argv1'))
            a2 = float(settings.risk2.model_1_condition_6_3.get('argv2'))
            a3 = float(settings.risk2.model_1_condition_6_3.get('argv3'))

            c = 0
            for n in range(3):
                try:c += int(float(three_mon_data.get('cre_%s' % n)) <= a1 )
                except:pass

            if c >= a3:
                return -2
            else:
                return 0
        except:
            return 0


    def get_condition_7(self,ifnew, day_trade_sum, all_trades):
        try:
            a1 = float(settings.risk2.model_1_condition_7.get('argv1'))
            a2 = float(settings.risk2.model_1_condition_7.get('argv2'))

            if ifnew and day_trade_sum >= a1:
                for t in all_trades:
                    if t.get('sysdtm').split(" ")[0]!=self._today.strftime("%Y-%m-%d") and t.get('txamt')/100 > a2:
                        return 0
                return 0.5
            else:
                return 0
        except:
            return 0


    def get_condition_8(self,unusual, skip):
        try:
            a1 = float(settings.risk2.model_1_condition_8.get('argv1'))
            a2 = float(settings.risk2.model_1_condition_8.get('argv2'))

            if unusual < 9999 and unusual >= a1:
                return 1

            if skip < 9999 and skip >= a2:
                return 1

            return 0
        except:
            return 0


    def get_condition_9(self, amt_concentration):
        try:
            a1 = float(settings.risk2.model_1_condition_9.get('argv1'))
            sum_concentration = 0
            for n in range(1,4):
                sum_concentration += float(amt_concentration.get('amt_concent_%s' % n).split()[0])

            if sum_concentration >= a1:
                return 1
            else:
                return 0
        except:
            return 0


    def get_condition_10(self, amt_concentration):
        try:
            a1 = float(settings.risk2.model_1_condition_10.get('argv1'))
            sum_concentration = 0
            for n in range(1,4):
                sum_concentration += float(amt_concentration.get('amt_concent_%s' % n).split()[0])

            if sum_concentration <= a1:
                return -2
            else:
                return 0
        except:
            return 0


    def get_condition_12(self, average_amt):
        try:
            a1 = float(settings.risk2.model_1_condition_12.get('argv1'))
            if float(average_amt) <= a1:
                return -2
            else:
                return 0
        except:
            return 0

    def get_day_sumamts(self,users):
        if not users:return {}
        sumamts={}
        for i in range(len(users)/1000+1):
            sql="select userid,sum(txamt) as sumamt from record_@1 where sysdtm>'%s' and userid in (%s) and busicd='000000' and retcd='0000' and cancel=0 GROUP BY userid" % (self._today.strftime("%Y-%m-%d 00:00:00"),",".join([str(user) for user in users[i*1000:(i+1)*1000]]))
            sumamts.update({sumamt["userid"]:sumamt["sumamt"] for sumamt in self.trade_db.query(sql)})
        return sumamts


    def insert_to_case(self):
        def get_rules(d):
            rules = ''
            rules_desc = {
                'condition_1': u'金额异常',
                'condition_2': u'爆发交易',
                'condition_3': u'分单交易',
                'condition_4': u'换卡交易',
                'condition_5': u'时间异常',
                'condition_6_1': u'金比异常1',
                'condition_6_2': u'金比异常2',
                'condition_6_3': u'金比异常3',
                'condition_7': u'新商户大额',
                'condition_8': u'收据异常',
                'condition_9': u'卡集中',
                'condition_10': u'卡集中低',
                'condition_12': u'单比金额',
            }
            for r in rules_desc:
                if d[r] > 0:
                    rules += rules_desc[r]
                    rules += ', '
            return rules[0:-2]

        cases = []
        sumamts=self.get_day_sumamts([_d["user_id"] for _d in self.risk_model_list])
        for _d in self.risk_model_list:
            if _d["user_id"] not in sumamts or sumamts[_d["user_id"]]<3000000:continue
            data = json.dumps({'data': {
                    'risk_index': _d['risk_index'],
                    'risk_rule': get_rules(_d),
                    'sumamt':sumamts[_d["user_id"]]
                }})
            case = (_d['user_id'], 'RISK001', 5, self._now.strftime("%Y-%m-%d %H:%M:%S"), self._now.strftime("%Y-%m-%d %H:%M:%S"), self._now.strftime("%Y-%m-%d %H:%M:%S"), 2, 1, data)
            cases.append(case)
        sql = "insert into case_cases (userid, casetype, priority, `time`, jointime, modifytime, method, state, info) values(%s, %s, %s, %s, %s, %s, %s, %s, %s)"
        if cases:
            self.risk2_db.insert(sql, cases)
        log.info("risk2 finish:%s,%s" % (len(cases),cases))

    def run(self):
        try:
            self.get_used_user()
            self.handle()
            if self.risk_model_list:
                self.insert_to_case()
            self._session["last_run_time"]=self._now
        except:
            log.error(traceback.format_exc())