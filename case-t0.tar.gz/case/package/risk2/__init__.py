# -*- coding: utf-8 -*-
#13-12-17

from core.schprocessor import register,Plan
from processor import Task,add_task
from risk import Risk
import settings

def run_risk():
    risk=Risk()
    risk.run()

def run(time):
    run_risk()

try:
    disable=settings.risk2.disable
except:pass

def start():
    plan=Plan.make_interval_plan(run,minutes=10)
    register(plan)

    task=Task(run_risk)
    add_task(task)

