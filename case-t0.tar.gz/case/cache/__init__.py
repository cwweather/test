# -*- coding: utf-8 -*-
#13-12-6

import datetime
from ocean.cache import Cache as BaseCache,CacheData as BaseCacheData

class CacheData(BaseCacheData):
    def get_item(self,key):
        return self._data.get(key,None)

    def set_item(self,key,data):
        if data is None:
            if key in self._data:del self._data[key]
        else:
            self._data[key]=data

class Cache(BaseCache):
    Data = CacheData
    def __init__(self,id):
        super(Cache,self).__init__()
        self._id=id

        self.init()

    def init(self):
        if not self.request("init",None):
            cd,args,kwargs=self.get_cache_data()
            ret=self.request("init",cd,*args,**kwargs)
            self.set({})
            return ret

    def __getitem__(self, key):
        return self.request("get_item",key)

    def __setitem__(self, key, value):
        self.request("set_item",key,value)

class ExpiredCacheData(BaseCacheData):
    expired_time=datetime.timedelta(minutes=10)
    def __init__(self):
        super(ExpiredCacheData,self).__init__()

        self._time=None

    def check(self):
        if not self._time or datetime.datetime.now()-self._time>=self.expired_time:
            self.load()
            self._time=datetime.datetime.now()

    def get(self):
        self.check()
        return super(ExpiredCacheData,self).get()

class ExpiredCache(BaseCache):
    Data = ExpiredCacheData

class IncrementalCacheData(BaseCacheData):
    expired_time=datetime.timedelta(seconds=10)
    def __init__(self):
        super(IncrementalCacheData,self).__init__()

        self._time=None
        self._incremental=None

    def load(self):
        if self._time:
            if datetime.datetime.now()-self._incremental>=self.expired_time:
                self.incremental(self._time)
                self._incremental=datetime.datetime.now()
        else:
            self.load_all()
            self._incremental=datetime.datetime.now()
        self._time=datetime.datetime.now()

    def load_all(self):
        self._data=[]

    def incremental(self,time):
        self._data=[]

    def get(self):
        self.load()
        return super(IncrementalCacheData,self).get()

class IncrementalCache(BaseCache):
    Data = IncrementalCacheData
