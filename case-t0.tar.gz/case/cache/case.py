# -*- coding: utf-8 -*-
#13-12-6

import datetime
from driver import Driver
from cache import ExpiredCache,ExpiredCacheData
import settings


class RuleData(ExpiredCacheData):
    expired_time = datetime.timedelta(minutes=3)
    def load(self):
        db=Driver(settings.db.risk2)
        rule_type = settings.case.rule_type
        if rule_type:
            rulelist = "and type in (" + ",".join(rule_type) + ")"
        else:
            rulelist = ""
        sql = "select case_id,name,`type`,`interval`,start_time,end_time,params,out_type,modifytime from case_rule " \
            "where state=1 and scope=%s %s" % (settings.case.case_scope, rulelist)
        self._data=db.query(sql)


class Rule(ExpiredCache):
    Data = RuleData
    def __init__(self):
        super(Rule,self).__init__()
        self._rules=self.get()

    def __iter__(self):
        for rule in self._rules:
            yield rule
        raise StopIteration


class FactorData(ExpiredCacheData):
    expired_time = datetime.timedelta(minutes=3)
    def load(self):
        db=Driver(settings.db.risk2)
        sql="select factorid,name from qf_rule_factor where scope=10"
        self._data={factor["factorid"]:factor for factor in db.query(sql)}


class Factor(ExpiredCache):
    Data = FactorData
    def __init__(self):
        super(Factor,self).__init__()
        self._factors=self.get()

    def __getitem__(self, id):
        return self._factors[id]

    def __contains__(self, id):
        return id in self._factors

