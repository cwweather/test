# -*- coding: utf-8 -*-
#14-1-7

import datetime
from driver import Driver
from cache import ExpiredCache,ExpiredCacheData
import settings

class RiskRestrictData(ExpiredCacheData):
    def load(self):
        db=Driver(settings.db.risk2)
        sql="select userid,rcv_credit_month_amt,amt_per_credit from risk_restrict"
        self._data={r["userid"]:r for r in db.query(sql)}

    def get_restrict(self,userid):
        self.check()
        if userid not in self._data:
            self.load()
            self._time=datetime.datetime.now()
        return self._data.get(userid)

class RiskRestrict(ExpiredCache):
    Data = RiskRestrictData
    def __iter__(self):
        restricts=self.get()
        for user in restricts:
            yield restricts[user]
        raise StopIteration

    def __getitem__(self, userid):
        return self.request("get_restrict",userid)