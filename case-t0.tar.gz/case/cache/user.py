# -*- coding: utf-8 -*-
#13-12-16
import datetime
from driver import Driver
from cache import IncrementalCache,IncrementalCacheData
import settings

class ProfileData(IncrementalCacheData):
    expired_time=datetime.timedelta(minutes=10)
    cache_fields=("userid","groupid","latitude","longitude","mobile","jointime")
    def load_all(self):
        db=Driver(settings.db.core)
        sql="SELECT %s FROM profile" % ",".join(self.cache_fields)
        self._data={user["userid"]:user for user in db.query(sql)}

    def incremental(self,time):
        db=Driver(settings.db.core)
        sql="SELECT %s FROM profile where last_modify>='%s'" % (",".join(self.cache_fields),time.strftime("%Y-%m-%d %H:%M:%S"))
        self._data.update({user["userid"]:user for user in db.query(sql)})

    def get_user(self,userid):
        self.load()
        if userid not in self._data:
            self.incremental(self._time)
            self._incremental=datetime.datetime.now()
            self._time=datetime.datetime.now()
        return self._data.get(userid)

class Profile(IncrementalCache):
    Data = ProfileData
    def __iter__(self):
        users=self.get()
        for user in users:
            yield users[user]
        raise StopIteration

    def __getitem__(self, userid):
        return self.request("get_user",userid)