# -*- coding: utf-8 -*-

import datetime
from driver import Driver
from cache import ExpiredCache,ExpiredCacheData
import settings

class StaffData(ExpiredCacheData):
    expired_time = datetime.timedelta(hours=2)
    def load(self):
        db=Driver(settings.db.core)
        sql="select userid from profile where groupid=10016"
        self._data=[user["userid"] for user in db.query(sql)]

class Staff(ExpiredCache):
    Data = StaffData
    def __init__(self):
        super(Staff,self).__init__()
        self._staffs=self.get()

    def __iter__(self):
        for staff in self._staffs:
            yield staff
        raise StopIteration

    def __contains__(self, user):
        return user in self._staffs

