# -*- coding: utf-8 -*-
#14-1-16

import copy
import threading
import multiprocessing
from base.pipe import Pipe
import core

class Option(object):
    def __init__(self):
        self._pp,self._sp=Pipe()
        self._thread=None
        self._lock=multiprocessing.Lock()
        self._stop=multiprocessing.Event()
        self._process=None

    def server(self):
        self._process=multiprocessing.current_process()

        while not self._stop.is_set():
            cmd,args,kwargs=self._pp.recv()
            if hasattr(self,cmd):
                try:
                    result=getattr(self,cmd)(*args,**kwargs)
                except:
                    result=None
            else:
                result=None
            self._pp.send(result)

    def start_server(self):
        self._thread=threading.Thread(target=self.server)
        self._thread.setDaemon(True)
        self._thread.start()

    def server_cmd(self,cmd,*args,**kwargs):
        with self._lock:
            self._sp.send((cmd,args,kwargs))
            return self._sp.recv()

    def state(self):
        if self._process and multiprocessing.current_process().pid==self._process.pid:
            return {
                "space_count":len(core.space_manager._spaces),
                "plan_count":str(core.space_manager._space_times),
                "current_queue_count":str(core.current_queue),
            }
        else:
            return self.server_cmd("state")