import multiprocessing
import core
from space import SpaceManager
from plan import Plan
from option import Option
import config
from config import log

class Scheduler(object):
    def __init__(self):
        self._process=None
        self._space_manager=SpaceManager()
        self._space=None
        self._option=Option()

    def init(self):
        core.init(self._space_manager)

    def _start(self):
        self._option.start_server()
        core.start()

    def load(self):
        self._process=multiprocessing.Process(target=self._start)

    def start(self):
        self._process.start()

    def stop(self):
        self._process.terminate()

    def register(self,plan):
        if not self._space:return None
        plan_time=self._space.register(plan)
        core.add_plan(self._space.get_id(),plan_time)
        return plan_time.id

    def unregister(self,plan_id):
        if not self._space:return None
        plan_time_id=self._space.unregister(plan_id)
        if plan_time_id:
            core.remove_plan(self._space.get_id(),plan_time_id)

    def register_space(self):
        return self._space_manager.add()

    def open_space(self,space):
        space.open()
        self._space=space

    def option(self):
        return self._option

_scheduler=Scheduler()

def init():
    _scheduler.init()

def load():
    _scheduler.load()

def start():
    space=register_space()
    _scheduler.start()
    open_space(space)

def stop():
    state=get_state()
    _scheduler.stop()
    log.info("scheduler state:%s",state)

def register_space():
    return _scheduler.register_space()

def open_space(space):
    _scheduler.open_space(space)

def register(plan):
    return _scheduler.register(plan)

def unregister(plan):
    return _scheduler.unregister(plan)

def get_scheduler():
    return _scheduler

def set_config(c):
    config.update(c)

def get_state():
    return _scheduler.option().state()
