# -*- coding: utf-8 -*-
#13-11-29

import hashlib
import threading
import multiprocessing
from plan import PlanTimeQueue,PlanQueue
from config import log
from base.pipe import Pipe

class Service(object):
    def __init__(self,space):
        self._space=space
        self._thread=None

    def run(self):
        try:
            self._space.loop()
        except:
            from base import vtraceback as traceback
            traceback.print_exc()

    def start(self):
        self._thread=threading.Thread(target=self.run)
        self._thread.setDaemon(True)
        self._thread.start()

class SpaceTime(object):
    def __init__(self,space):
        self._sp=space._sp
        self._plan_times=PlanTimeQueue()
        self._id=space._id

    def register(self,plan_time):
        self._plan_times.add(plan_time)
        log.debug("scheduler register plan_time:plan_time=%s",plan_time)

    def unregister(self,plan_time_id):
        self._plan_times.remove(plan_time_id)
        log.debug("scheduler unregister plan_time:plan_time_id=%s",plan_time_id)

    def get_id(self):
        return self._id

    def active(self,time,plan_times):
        self._sp.send((time,plan_times))

    def get_plan_times(self):
        return self._plan_times

    def __str__(self):
        return str(self._plan_times)

    def __repr__(self):
        return self.__str__()

class Space(object):
    def __init__(self):
        self._pp,self._sp=Pipe()
        self._service=Service(self)
        self._id=str(id(self))
        self._space_time=SpaceTime(self)
        self._plans=PlanQueue()
        self._id_index=0
        self._id_lock=multiprocessing.Lock()

    def get_new_id(self):
        with self._id_lock:
            if self._id_index>99999999:
                self._id_index=0
            self._id_index+=1
            return hashlib.md5(self._id+"@"+("%032d" % self._id_index)).hexdigest()

    def open(self):
        self._service.start()

    def loop(self):
        while True:
            time,plan_times=self._pp.recv()
            for id in plan_times:
                for plan in self._plans:
                    if id==plan.id():
                        try:
                            plan.run(time)
                        except:
                            from base import vtraceback as traceback
                            log.error(traceback.format_exc())

    def register(self,plan):
        plan.plan_time.id=self.get_new_id()
        self._plans.add(plan)
        log.debug("scheduler register plan:plan=%s",plan)
        return plan.plan_time

    def unregister(self,plan_id):
        plan=self._plans.remove(plan_id)
        if not plan:
            log.error("scheduler unregister plan error:plan_id=%s",plan_id)
        else:
            log.debug("scheduler unregister plan:plan_id=%s",plan_id)
            return plan.id()
        return None

    def get_space_time(self):
        return self._space_time

    def get_id(self):
        return self._id

class SpaceManager(object):
    def __init__(self):
        self._spaces={}
        self._space_times={}

    def add(self):
        space=Space()
        self._spaces[space.get_id()]=space
        space_time=space.get_space_time()
        self._space_times[space_time.get_id()]=space_time
        return space

    def get_space_times(self):
        return self._space_times

