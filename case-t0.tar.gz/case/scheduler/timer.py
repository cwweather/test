
import time
import datetime
import signal

time_out=None
is_stop=None

def handler(signum,frame):
    time=datetime.datetime.now()
    if time_out:
        time_out(time)

def start_timer(to):
    global time_out
    time_out=to

def loop():
    signal.signal(signal.SIGALRM,handler)
    signal.setitimer(signal.ITIMER_REAL,1,1)
    while not is_stop:
        time.sleep(1)


