#coding=utf-8
#测试的风控服务器地址
RISK_SERVER = {
    #'address':'172.100.110.195',
    #'address':'172.100.101.171',
    #'address':'172.100.101.172',
    #'address':'172.100.101.15',
    #'address':'127.0.0.1',
    #'address':'192.168.30.5',
    'address':'192.10.2.166',
    #'port': 4511
    'port': 4510
}
