﻿#coding=utf-8
import datetime
import time

from colorprint import *

class TestSuite(object):
    def  __init__(self, times=1, check=True, update=True):
        self.times = times
        self.check, self.update = check, update
        #self.trade = {
            #"cardcd":"6227003769000146431",
            #"cardcd":"6227003769000146431",
        #    "cardcd":"6221550483814731",
        #    "cardtp":"02",
        #    "lnglat":["116.407413","39.904214"],
        #    "sysdtm":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        #    "syssn":"20120702000001",
        #    "terminalid":"12020001000100100084",
        #    "txamt":"310000",
        #    "userid":"10215"}
        self.trade = {
            "appid":"1304000200020010000200000000000000010519",
            "authid":"",
            "busicd":"000000",
            "cardcd":"6005210692708624",
            "cardtp":"02",
            "clientip":"172.100.110.159",
            "clisn":"037952",
            "debitacntbank":"",
            "debitacntcd":"",
            "debitacntname":"",
            "haspw":"0",
            "inbank":"",
            "inbankid":"",
            "incardcd":"",
            "incardtp":"",
            "lnglat":["116.461","39.955"],
            #"lnglat":["0.0","0.0"],
            "mchntnm":"bbb",
            "origbusicd":"",
            "origclisn":"",
            "origdtm":"",
            "psamid":"3330343030303032",
            "respcd":"",
            "sysdtm":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "syssn":"20130705005194",
            "txamt":"50500",
            "terminalid":"13040002000200100002",
            "txcurrcd":"156",
            "txdtm":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "txzone":"+0800",
            "udid":"866959011896172",
            "usercd":"4",
            #"userid":"10519"
            #"userid":"10961"
            #"userid":"11394"
            "userid":"11399"
            #"userid":"10991"
            }
        '''
        self.trade = {"appid":"1205000100010010323200000000000000013143",
            "authid":"",
            "busicd":"000000",
            "cardcd":"6229210800190776",
            "cardtp":"02",
            "clientip":"221.131.128.213",
            "clisn":"034472",
            "debitacntbank":"",
            "debitacntcd":"",
            "debitacntname":"",
            "haspw":"1",
            "inbank":"",
            "inbankid":"",
            "incardcd":"",
            "incardtp":"",
            "lnglat":["120.5365583476649","31.26844360086629"],
            "mchntnm":"完美中国 刘春生",
            "origbusicd":"",
            "origclisn":"",
            "origdtm":"",
            "psamid":"3130303030323534",
            "respcd":"",
            "riskret":"",
            "sysdtm":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "syssn":"20130605682339",
            "terminalid":"12050001000100103232",
            "txamt":"6000000",
            "txcurrcd":"156",
            "txdtm":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "txzone":"+0800",
            "udid":"7cc3a1445854",
            "usercd":"4",
            "userid":"10963",
            "groupid": "1",
            "chnlid": "0001"}
        '''
    def set_trade(self, trade):
        self.trade = trade

    def set_data(self, **kwargs):
        for k,v in kwargs.items():
            self.trade[k] = v       

    def run(self, client, payresp=None):
        import json
        strTrade = json.dumps(self.trade)
        res = {}
        for i in range(0, self.times):
            res_check = ''
            if self.check==True:
                #colorprint(RED, 'check:'+str(self.trade))
                res_check = client.check_trade(strTrade)
            if self.update==True:
                res = json.loads(res_check)
                trade = dict(res , **self.trade)
                if trade['riskret'] == '0':
                    trade['respcd'] = '0000'
                else:
                    trade['respcd'] = '1118'
                if payresp is not None:
                    trade['respcd'] = payresp
                #colorprint(BLUE, 'update: '+str(trade))
                #colorprint(BLUE, 'riskdesc: '+trade['riskdesc'])
                client.update_trade(json.dumps(trade))
            
        return res

class PaymentSuite(TestSuite):
    '''
    消费测试
    '''
    def __init__(self, times,check,update):
        super(PaymentSuite, self).__init__(times,check,update)
        self.trade['busicd']='000000'
        self.trade['txamt']='500'

    def run(self, client):
        super(PaymentSuite, self).run(client)

class PaymentReversalSuite(TestSuite):
    '''
       消费冲正测试
    '''
    def __init__(self, times,check,update):
        super(PaymentReversalSuite, self).__init__(times,check,update)
        self.trade['busicd']='040000'
        self.trade['syssn'] = '20120702000002'
        self.trade['origsn'] ='20120702000001' 

    def run(self, client):
        super(PaymentReversalSuite, self).run(client)


class CancelSuite(TestSuite):
    '''
        消费撤销测试
    '''
    def __init__(self, times,check,update):
        super(CancelSuite, self).__init__(times,check,update)
        self.trade['busicd']='201000'
        self.trade['syssn'] = '20120702000003'

    def run(self,client):
        super(CancelSuite, self).run(client)


class CancelReversalSuite(TestSuite):
    '''
        消费撤销冲正测试
    '''
    def __init__(self, times,check,update):
        super(CancelReversalSuite, self).__init__(times,check,update)
        self.trade['busicd']='041000'
        self.trade['syssn'] = '20120702000004'
        self.trade['origsn'] ='20120702000003' 

    def run(self, client):
        super(CancelReversalSuite, self).run(client)


class BalanceSuite(TestSuite):
    '''
        余额查询测试
    '''
    def __init__(self, times,check,update):
        super(BalanceSuite, self).__init__(times,check,update)
        self.trade['busicd']='300000'

    def run(self, client):
        super(BalanceSuite, self).run(client)

class CreditCardPaymentSuite(TestSuite):
    '''
    信用卡还款测试
    '''
    def __init__(self, times,check,update):
        super(CreditCardPaymentSuite, self).__init__(times,check,update)
        self.trade['busicd']='401000'

    def run(self, client):
        super(CreditCardPaymentSuite, self).run(client)
		
class Card2CardSuite(TestSuite):
    '''
    卡卡转账测试
    '''
    def __init__(self, times,check,update):
        super(Card2CardSuite, self).__init__(times,check,update)
        self.trade['busicd']='420000'

    def run(self, client):
        super(Card2CardSuite, self).run(client)
