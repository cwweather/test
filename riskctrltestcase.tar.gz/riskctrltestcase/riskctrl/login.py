#coding=utf-8
import datetime

from suite import TestSuite
from colorprint import *


class LoginSuite(TestSuite):
    def __init__(self, times,check,update):
        super(LoginSuite, self).__init__(times,check,update)

        self.login={
             "appid":"1304000200020010087900000000000000010964",
             "lnglat":["116.454055","39.95292"],
             "psamid":"3330343030383739",
             "respcd":"",
             "riskret":"",
             "sysdtm":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
             "terminalid":"13040002000200100879",
             "txdtm":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
             "txzone":"+0800",
             "udid":"867747010620670",
             "userid":"10964"
        }

    def set_data(self, **kwargs):
        for k,v in kwargs.items():
            self.login[k] = v

    def run(self, client):
        import json
        strLogin= json.dumps(self.login)
        for i in range(0, self.times):
            res_check = ''
            if self.check==True:
                colorprint(RED,'check: '+str(self.login))
                res_check = client.check_login(strLogin)
                colorprint(GREEN, 'result: '+res_check)
            if self.update==True:
                login = dict(json.loads(res_check), **self.login)
                login['respcd'] = '1116'
                colorprint(BLUE, 'update: '+str(login))
                client.update_login(json.dumps(login))
