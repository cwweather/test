#code=utf-8

import random

#30 Black text
#31 Red text
#32 Green text
#33 Yellow text
#34 Blue text
#35 Purple text
#36 Cyan text
#37 White text
#40 Black background
#41 Red background
#42 Green background
#43 Yellow background
#44 Blue background
#45 Purple background
#46 Cyan background
#47 White background


RED = 31
GREEN = 32
BLUE = 34

def randomcolorprint(s):
    seq = random.randrange(0,6)
    print "\x1b[%d;2m%s\x1b[0m"%(31+seq, s)

def colorprint(color, s):
    print "\x1b[%d;2m%s\x1b[0m"%(color, s)
