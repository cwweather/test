#coding=utf-8

import os,sys

from thrift import Thrift
from thrift.transport import TSocket, TTransport
from thrift.protocol import TBinaryProtocol

from client import RiskServer

import settings
import json

sys.path.append(os.path.dirname(__file__))

if __name__ == '__main__':
    transport = TSocket.TSocket(settings.RISK_SERVER['address'], settings.RISK_SERVER['port'])
    transport.open()
    protocal = TBinaryProtocol.TBinaryProtocol(transport)
    client = RiskServer.Client(protocal)

    configstr = {
        "reLoadRule": ""
    }
    res = client.config_set(json.dumps(configstr))
    configstr = {
        "reLoadGlobal":""
    }
    
    #res = client.config_set(json.dumps(configstr))