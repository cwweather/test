#coding=utf-8

class GetRemainSuite(object):
    '''
          额度查询
    '''

    def  __init__(self, times=1, check=True):
        self.times = times
        self.check = check
            
        self.key = {
           "type": "user", 
           "key": "43646"
        }

    def set_trade(self, key):
        self.key = key

    def set_data(self, **kwargs):
        for k,v in kwargs.items():
            self.key[k] = v       

    def run(self, client, payresp=None):
        import json
        strTrade = json.dumps(self.key)
        res = {}
        for i in range(0, self.times):
            res_check = ''
            if self.check==True:
                res_check = client.get_remain(strTrade)
        return res
