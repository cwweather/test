#coding=utf-8

import os,sys

from thrift import Thrift
from thrift.transport import TSocket, TTransport
from thrift.protocol import TBinaryProtocol

from client import RiskServer
from suite import PaymentSuite, PaymentReversalSuite
from suite import CancelSuite, CancelReversalSuite
from suite import BalanceSuite, CreditCardPaymentSuite, Card2CardSuite
from login import LoginSuite
from getremainsuite import GetRemainSuite

import settings

sys.path.append(os.path.dirname(__file__))

class RiskClient(object):
	def __init__(self):
		self.client = None
		self.suites = []

	def create_client(self, server, port):
		transport = TSocket.TSocket(server, port)
		transport.open()
		protocal = TBinaryProtocol.TBinaryProtocol(transport)
		self.client = RiskServer.Client(protocal)

    
	def add_suite(self, suite):
		self.suites.append(suite)
	
	def run_all_test(self):
		for test in self.suites:
			test.run(self.client)

	def close(self):
		self.sock.close()

if __name__ == '__main__':
    client = RiskClient()
    client.create_client(settings.RISK_SERVER['address'], settings.RISK_SERVER['port'])

    client.add_suite(PaymentSuite(times=1,check=True,update=False))
    #client.add_suite(Card2CardSuite(times=1,check=True,update=True))
    #client.add_suite(CreditCardPaymentSuite(times=1,check=True,update=True))
    #client.add_suite(PaymentReversalSuite(times=1,check=True,update=True)) 
    #client.add_suite(CancelSuite(times=1,check=True,update=True)) 
    #client.add_suite(CancelReversalSuite(times=1,check=True,update=True)) 
    #client.add_suite(BalanceSuite(times=10,check=True,update=True)) 
    #client.add_suite(LoginSuite(times=1,check=True,update=True))
    #client.add_suite(GetRemainSuite(times=1))

    client.run_all_test()
