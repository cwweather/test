#coding=utf-8

import os,sys

from thrift import Thrift
from thrift.transport import TSocket, TTransport
from thrift.protocol import TBinaryProtocol

from client import RiskServer

import settings
import json

sys.path.append(os.path.dirname(__file__))

class CheckRules(object):
    def __init__(self, host, port):
        self.host = host
        self.port = port

    def check_rules(self):
        transport = TSocket.TSocket(self.host, self.port)
        transport.open()
        protocal = TBinaryProtocol.TBinaryProtocol(transport)
        client = RiskServer.Client(protocal)

        str = {
            "ruleid":[]
        }
        #res = client.check_rule(json.dumps(str))
        #print res
        str = {
            "ruleid":["83", "2"]
        }
        res = client.check_rule(json.dumps(str))
        print res

if __name__ == '__main__':
    #client = CheckRules('127.0.0.1', 4510)
    #client.check_rules()
    #client = CheckRules('172.100.101.171', 4510)
    client = CheckRules('192.168.30.4', 4511)
    client.check_rules()
