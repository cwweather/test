__author__ = 'hcp000'

class ReadTradesSuit(object):
    def __init__(self):
        print(1)

    def run(self, client):
        records = client.get_trades(36563,"6225210692708624")
        print(records.userparam)
