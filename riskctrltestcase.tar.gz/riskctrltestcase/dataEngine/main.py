#coding=utf-8

import os,sys

from thrift import Thrift
from thrift.transport import TSocket, TTransport
from thrift.protocol import TBinaryProtocol

from dataengineclient import DataEngine

from suit import ReadTradesSuit
sys.path.append(os.path.dirname(__file__))

class DataEngineClient(object):
    def __init__(self):
        self.client = None
        self.suites = []

    def create_client(self, server, port):
        transport = TSocket.TSocket(server, port)
        transport.open()
        protocal = TBinaryProtocol.TBinaryProtocol(transport)
        self.client = DataEngine.Client(protocal)

    def add_suite(self, suite):
        self.suites.append(suite)

    def run_all_test(self):
        for test in self.suites:
            test.run(self.client)

    def close(self):
        self.sock.close()


if __name__ == '__main__':
    client = DataEngineClient()
    client.create_client("172.100.110.224", "11110")

    client.add_suite(ReadTradesSuit())
    client.run_all_test()